export type Bilingual = { en: string; kn: string };

export interface QuizQuestion {
  question: Bilingual;
  options: Bilingual[];
  answerIndex: number;
}

export interface StoryPage {
  text: Bilingual;
  emoji: string; // simple illustration placeholder
  bg: string; // tailwind gradient class
}

export interface Hero {
  id: string;
  name: Bilingual;
  title: Bilingual;
  era: string;
  emoji: string;
  pages: StoryPage[];
  quiz: QuizQuestion[];
  memorial: {
    name: Bilingual;
    place: Bilingual;
    description: Bilingual;
    mapsQuery: string;
  };
}

export interface District {
  id: string;
  name: Bilingual;
  emoji: string;
  heroes: Hero[];
}

// Helper to keep the long district list compact. Cycles page backgrounds.
const PAGE_BGS = ["bg-gradient-warm", "bg-gradient-sunset"];
type MkHeroInput = {
  id: string;
  emoji: string;
  name: [string, string];
  title: [string, string];
  era: string;
  pages: Array<[string, string, string]>; // [en, kn, emoji]
  quiz: Array<[string, string, [string, string, string], [string, string, string], number]>; // [qEn,qKn,enOpts,knOpts,answerIdx]
  memorial: [string, string, string, string, string, string, string]; // nameEn,nameKn,placeEn,placeKn,descEn,descKn,mapsQuery
};
function mkHero(h: MkHeroInput): Hero {
  const nameEn = h.name[0];
  const nameKn = h.name[1];
  const titleEn = h.title[0].toLowerCase();
  // Auto-pad story to a minimum of 5 pages with personalised closing pages.
  const paddedPages: Array<[string, string, string]> = [...h.pages];
  const fillers: Array<[string, string, string]> = [
    [
      `${nameEn} faced many challenges with courage, wisdom and a kind heart.`,
      `${nameKn} ಅವರು ಎಲ್ಲ ಸವಾಲುಗಳನ್ನು ಧೈರ್ಯ, ಜಾಣ್ಮೆ ಮತ್ತು ಕರುಣೆಯಿಂದ ಎದುರಿಸಿದರು.`,
      "💪",
    ],
    [
      `Children, families and elders loved ${nameEn} for being a true ${titleEn}.`,
      `ಮಕ್ಕಳು, ಕುಟುಂಬಗಳು, ಹಿರಿಯರು — ಎಲ್ಲರೂ ${nameKn} ಅವರನ್ನು ಪ್ರೀತಿಸಿದರು.`,
      "💖",
    ],
    [
      `Today, ${nameEn} inspires every child of Karnataka to dream big and do good.`,
      `ಇಂದು ${nameKn} ಕರ್ನಾಟಕದ ಪ್ರತಿ ಮಗುವಿಗೆ ದೊಡ್ಡ ಕನಸು ಕಾಣಲು ಸ್ಫೂರ್ತಿ.`,
      "🌟",
    ],
  ];
  let fi = 0;
  while (paddedPages.length < 5 && fi < fillers.length) {
    paddedPages.push(fillers[fi++]);
  }
  return {
    id: h.id,
    emoji: h.emoji,
    name: { en: nameEn, kn: nameKn },
    title: { en: h.title[0], kn: h.title[1] },
    era: h.era,
    pages: paddedPages.map(([en, kn, emoji], i) => ({
      text: { en, kn },
      emoji,
      bg: PAGE_BGS[i % PAGE_BGS.length],
    })),
    quiz: h.quiz.map(([qEn, qKn, enOpts, knOpts, answerIndex]) => ({
      question: { en: qEn, kn: qKn },
      options: enOpts.map((en, i) => ({ en, kn: knOpts[i] })),
      answerIndex,
    })),
    memorial: {
      name: { en: h.memorial[0], kn: h.memorial[1] },
      place: { en: h.memorial[2], kn: h.memorial[3] },
      description: { en: h.memorial[4], kn: h.memorial[5] },
      mapsQuery: h.memorial[6],
    },
  };
}

export const DISTRICTS: District[] = [
  {
    id: "belagavi",
    name: { en: "Belagavi", kn: "ಬೆಳಗಾವಿ" },
    emoji: "🏰",
    heroes: [
      {
        id: "kittur-chennamma",
        name: { en: "Kittur Rani Chennamma", kn: "ಕಿತ್ತೂರು ರಾಣಿ ಚೆನ್ನಮ್ಮ" },
        title: { en: "The Warrior Queen of Kittur", kn: "ಕಿತ್ತೂರಿನ ವೀರ ರಾಣಿ" },
        era: "1778 – 1829",
        emoji: "👸",
        pages: [
          {
            emoji: "⚔️",
            bg: "bg-gradient-warm",
            text: {
              en: "In the small village of Kakati, within the Belagavi district of Karnataka, a brave girl named Chennamma was born in 1778. From a very young age, she was unlike other children of her time. Instead of just playing games, she was fascinated by the art of war. Chennamma spent her days learning how to ride horses across the fields, practicing the precise art of archery, and mastering the swift movements of sword-fighting. Her strength and determination grew with every passing year, preparing her for a destiny that would change the history of India. Little did the people know that this young girl from Kakati would one day become a legendary queen who would stand tall against the mightiest empire in the world.",
              kn: "ಬೆಳಗಾವಿ ಜಿಲ್ಲೆಯ ಕಾಕತಿ ಎಂಬ ಗ್ರಾಮದಲ್ಲಿ ೧೭೭೮ ರಲ್ಲಿ ಚೆನ್ನಮ್ಮ ಎಂಬ ವೀರ ಬಾಲಕಿ ಜನಿಸಿದಳು. ಆ ಕಾಲದ ಉಳಿದ ಮಕ್ಕಳಿಗಿಂತ ಅವಳು ವಿಭಿನ್ನವಾಗಿದ್ದಳು. ಕೇವಲ ಆಟವಾಡದೆ, ಯುದ್ಧಕಲೆಯಲ್ಲಿ ಅವಳು ಆಸಕ್ತಿ ಹೊಂದಿದ್ದಳು. ಕುದುರೆ ಸವಾರಿ ಮಾಡುವುದು, ನಿಖರವಾಗಿ ಬಿಲ್ಲುಗಾರಿಕೆ ಮಾಡುವುದು ಮತ್ತು ಕತ್ತಿವರಸೆಯನ್ನು ಕಲಿಯುವುದರಲ್ಲಿ ಅವಳು ದಿನಗಳನ್ನು ಕಳೆದಳು. ವರ್ಷಗಳು ಕಳೆದಂತೆ ಅವಳ ಧೈರ್ಯ ಮತ್ತು ಸಂಕಲ್ಪ ಬೆಳೆಯುತ್ತಾ ಹೋದವು. ಕಾಕತಿಯ ಈ ಚಿಕ್ಕ ಹುಡುಗಿ ಮುಂದೊಂದು ದಿನ ವಿಶ್ವದ ಬಲಿಷ್ಠ ಸಾಮ್ರಾಜ್ಯದ ವಿರುದ್ಧ ಎದೆಯುಬ್ಬಿಸಿ ನಿಲ್ಲುವ ಪೌರಾಣಿಕ ರಾಣಿಯಾಗುತ್ತಾಳೆ ಎಂದು ಯಾರೂ ಊಹಿಸಿರಲಿಲ್ಲ.",
            },
          },
          {
            emoji: "👑",
            bg: "bg-gradient-sunset",
            text: {
              en: "As she grew into a wise and powerful woman, Chennamma became the Queen of Kittur. She ruled her kingdom with great care and justice, earning the love and respect of all her people. They called her Kittur Rani Chennamma. However, dark clouds soon gathered over the peaceful land. The British East India Company wanted to take control of her kingdom using a rule called the Doctrine of Lapse. They claimed that because the kingdom did not have a natural heir, it must belong to them. But the Queen was not one to surrender easily. She knew that her land belonged to her people, and she was ready to protect their freedom at any cost.",
              kn: "ಚೆನ್ನಮ್ಮ ಬೆಳೆದು ಬುದ್ಧಿವಂತ ಮತ್ತು ಶಕ್ತಿಯುತ ಮಹಿಳೆಯಾದ ಮೇಲೆ ಕಿತ್ತೂರಿನ ರಾಣಿಯಾದಳು. ಅವಳು ತನ್ನ ರಾಜ್ಯವನ್ನು ಬಹಳ ಕಾಳಜಿ ಮತ್ತು ನ್ಯಾಯದಿಂದ ಆಳಿದಳು, ಇದರಿಂದಾಗಿ ಪ್ರಜೆಗಳ ಪ್ರೀತಿ ಮತ್ತು ಗೌರವವನ್ನು ಸಂಪಾದಿಸಿದಳು. ಎಲ್ಲರೂ ಅವಳನ್ನು ಕಿತ್ತೂರು ರಾಣಿ ಚೆನ್ನಮ್ಮ ಎಂದು ಕರೆದರು. ಆದರೆ ಶೀಘ್ರದಲ್ಲೇ ಶಾಂತಿಯುತ ಭೂಮಿಯ ಮೇಲೆ ಕತ್ತಲೆ ಆವರಿಸಿತು. ಬ್ರಿಟಿಷ್ ಈಸ್ಟ್ ಇಂಡಿಯಾ ಕಂಪನಿಯು 'ದತ್ತು ಪುತ್ರನಿಗೆ ಹಕ್ಕಿಲ್ಲ' ಎಂಬ ನಿಯಮವನ್ನು ಬಳಸಿ ಕಿತ್ತೂರನ್ನು ವಶಪಡಿಸಿಕೊಳ್ಳಲು ಸಂಚು ಹೂಡಿತು. ರಾಜ್ಯಕ್ಕೆ ನೈಸರ್ಗಿಕ ಉತ್ತರಾಧಿಕಾರಿ ಇಲ್ಲದ ಕಾರಣ ಅದು ತಮಗೆ ಸೇರಬೇಕು ಎಂದು ಅವರು ವಾದಿಸಿದರು. ಆದರೆ ರಾಣಿ ಸುಲಭವಾಗಿ ಶರಣಾಗುವವಳಲ್ಲ. ತನ್ನ ಭೂಮಿ ತನ್ನ ಜನರಿಗೆ ಸೇರಿದ್ದು ಎಂದು ಅವಳಿಗೆ ತಿಳಿದಿತ್ತು.",
            },
          },
          {
            emoji: "🐎",
            bg: "bg-gradient-warm",
            text: {
              en: "In 1824, when the British tried to seize Kittur, Rani Chennamma did something extraordinary. She led an armed revolt against the powerful invaders, becoming one of the earliest Indian rulers to fight against British colonialism. Dressed in her warrior attire and riding her horse, she inspired her soldiers to fight for their dignity. In a fierce first battle, the brave warriors of Kittur faced the British army. The Queen's leadership was so effective that they defeated the British forces moving toward their gates. During this historic encounter, the British collector St John Thackeray was killed. It was a moment of great pride for the people of Kittur, proving that courage could overcome even the strongest enemies.",
              kn: "೧೮೨೪ ರಲ್ಲಿ ಬ್ರಿಟಿಷರು ಕಿತ್ತೂರನ್ನು ವಶಪಡಿಸಿಕೊಳ್ಳಲು ಪ್ರಯತ್ನಿಸಿದಾಗ, ರಾಣಿ ಚೆನ್ನಮ್ಮ ಅಸಾಧಾರಣವಾದ ಕೆಲಸವನ್ನು ಮಾಡಿದಳು. ಅವಳು ಬ್ರಿಟಿಷ್ ವಸಾಹತುಶಾಹಿಯ ವಿರುದ್ಧ ಸಶಸ್ತ್ರ ದಂಗೆಯನ್ನು ಮುನ್ನಡೆಸಿದ ಭಾರತದ ಮೊದಲ ಆಡಳಿತಗಾರರಲ್ಲಿ ಒಬ್ಬಳಾದಳು. ಯುದ್ಧದ ಉಡುಪನ್ನು ಧರಿಸಿ ಕುದುರೆಯನ್ನೇರಿ ತನ್ನ ಸೈನಿಕರಿಗೆ ಸ್ಫೂರ್ತಿ ನೀಡಿದಳು. ಮೊದಲ ಭೀಕರ ಯುದ್ಧದಲ್ಲಿ, ಕಿತ್ತೂರಿನ ವೀರ ಸೈನಿಕರು ಬ್ರಿಟಿಷ್ ಸೈನ್ಯವನ್ನು ಎದುರಿಸಿದರು. ರಾಣಿಯ ನಾಯಕತ್ವವು ಎಷ್ಟೊಂದು ಪರಿಣಾಮಕಾರಿಯಾಗಿತ್ತೆಂದರೆ, ಕಿತ್ತೂರಿನ ಸೈನ್ಯವು ಬ್ರಿಟಿಷ್ ಪಡೆಗಳನ್ನು ಸೋಲಿಸಿತು. ಈ ಐತಿಹಾಸಿಕ ಹೋರಾಟದಲ್ಲಿ ಬ್ರಿಟಿಷ್ ಕಲೆಕ್ಟರ್ ಸ್ಟಾಕ್ ಥ್ಯಾಕ್ರೆ ಕೊಲ್ಲಲ್ಪಟ್ಟನು. ಇದು ಕಿತ್ತೂರಿನ ಜನರಿಗೆ ಹೆಚ್ಚಿನ ಹೆಮ್ಮೆಯ ಕ್ಷಣವಾಗಿತ್ತು.",
            },
          },
          {
            emoji: "🏰",
            bg: "bg-gradient-sunset",
            text: {
              en: "Though she won the first battle, the British returned with a much larger army to crush the rebellion. Despite fighting with incredible bravery and defending her fort with everything she had, the Queen was eventually captured by the enemy. Even in captivity, her spirit remained unbroken. She was taken to Bailhongal jail, where she spent her final days. In 1829, while still in prison, the legendary warrior queen passed away. Although she was physically confined, her message of freedom and resistance reached every corner of the land. She had shown that no empire was too big to challenge and that the love for one's motherland was the greatest strength of all.",
              kn: "ಮೊದಲ ಯುದ್ಧದಲ್ಲಿ ಗೆದ್ದಿದ್ದರೂ, ಬ್ರಿಟಿಷರು ದಂಗೆಯನ್ನು ಹತ್ತಿಕ್ಕಲು ದೊಡ್ಡ ಸೈನ್ಯದೊಂದಿಗೆ ಮರಳಿದರು. ಅದ್ಭುತ ಶೌರ್ಯದಿಂದ ಹೋರಾಡಿ ತನ್ನ ಕೋಟೆಯನ್ನು ರಕ್ಷಿಸಿದರೂ, ರಾಣಿಯು ಅಂತಿಮವಾಗಿ ಶತ್ರುಗಳ ಕೈಗೆ ಸೆರೆಯಾದಳು. ಸೆರೆಯಲ್ಲಿದ್ದಾಗಲೂ ಅವಳ ಛಲ ಕುಗ್ಗಲಿಲ್ಲ. ಅವಳನ್ನು ಬೈಲಹೊಂಗಲ ಜೈಲಿಗೆ ಕರೆದೊಯ್ಯಲಾಯಿತು, ಅಲ್ಲಿ ಅವಳು ತನ್ನ ಕೊನೆಯ ದಿನಗಳನ್ನು ಕಳೆದಳು. ೧೮೨೯ ರಲ್ಲಿ ಜೈಲಿನಲ್ಲಿದ್ದಾಗಲೇ ಈ ಪೌರಾಣಿಕ ವೀರ ರಾಣಿ ಮರಣ ಹೊಂದಿದಳು. ಅವಳನ್ನು ಬಂಧಿಸಲಾಗಿದ್ದರೂ, ಅವಳ ಸ್ವಾತಂತ್ರ್ಯ ಮತ್ತು ಪ್ರತಿರೋಧದ ಸಂದೇಶವು ದೇಶದ ಮೂಲೆ ಮೂಲೆಗೂ ತಲುಪಿತು. ಯಾವುದೇ ಸಾಮ್ರಾಜ್ಯವು ಸವಾಲು ಹಾಕಲು ಅಸಾಧ್ಯವಾದುದಲ್ಲ ಮತ್ತು ಮಾತೃಭೂಮಿಯ ಮೇಲಿನ ಪ್ರೀತಿಯೇ ಶ್ರೇಷ್ಠ ಶಕ್ತಿ ಎಂದು ಅವಳು ತೋರಿಸಿಕೊಟ್ಟಿದ್ದಳು.",
            },
          },
          {
            emoji: "🇮🇳",
            bg: "bg-gradient-warm",
            text: {
              en: "Today, Kittur Rani Chennamma is remembered as a shining symbol of courage and female empowerment across India. Her statue stands tall in many places, and her bravery is celebrated in folk songs and stories told to children every day. She taught us that one should never stay silent against injustice and that true leaders fight for the rights of their people until the very end. Every year, people gather to honor her memory and the sacrifice she made for the freedom of her kingdom. As the brave Queen of Kittur, her legacy continues to inspire millions of young girls and boys to be brave, stand for the truth, and love their country unconditionally.",
              kn: "ಇಂದು, ಕಿತ್ತೂರು ರಾಣಿ ಚೆನ್ನಮ್ಮ ಭಾರತದಾದ್ಯಂತ ಶೌರ್ಯ ಮತ್ತು ಮಹಿಳಾ ಸಬಲೀಕರಣದ ಬೆಳಗುವ ಸಂಕೇತವಾಗಿ ನೆನಪಿಸಲ್ಪಡುತ್ತಾಳೆ. ಅವಳ ಪ್ರತಿಮೆಗಳು ಅನೇಕ ಸ್ಥಳಗಳಲ್ಲಿ ಎತ್ತರವಾಗಿ ನಿಂತಿವೆ ಮತ್ತು ಅವಳ ಶೌರ್ಯವನ್ನು ಇಂದಿಗೂ ಜಾನಪದ ಹಾಡುಗಳು ಮತ್ತು ಕಥೆಗಳಲ್ಲಿ ಆಚರಿಸಲಾಗುತ್ತದೆ. ಅನ್ಯಾಯದ ವಿರುದ್ಧ ಎಂದಿಗೂ ಸುಮ್ಮನಿರಬಾರದು ಮತ್ತು ನಿಜವಾದ ನಾಯಕರು ತಮ್ಮ ಜನರ ಹಕ್ಕುಗಳಿಗಾಗಿ ಕೊನೆಯವರೆಗೂ ಹೋರಾಡುತ್ತಾರೆ ಎಂದು ಅವಳು ನಮಗೆ ಕಲಿಸಿದಳು. ಪ್ರತಿ ವರ್ಷ ಜನರು ಅವಳ ನೆನಪಿಗಾಗಿ ಮತ್ತು ಅವಳ ತ್ಯಾಗವನ್ನು ಗೌರವಿಸಲು ಸೇರುತ್ತಾರೆ. ಕಿತ್ತೂರಿನ ವೀರ ರಾಣಿಯಾಗಿ ಅವಳ ಪರಂಪರೆಯು ಲಕ್ಷಾಂತರ ಯುವಕ-ಯುವತಿಯರಿಗೆ ಧೈರ್ಯಶಾಲಿಯಾಗಿರಲು ಮತ್ತು ಸತ್ಯಕ್ಕಾಗಿ ನಿಲ್ಲಲು ಇಂದಿಗೂ ಸ್ಫೂರ್ತಿ ನೀಡುತ್ತಿದೆ.",
            },
          }
        ],
        quiz: [
          {
            question: { en: "Which kingdom did Chennamma rule?", kn: "ಚೆನ್ನಮ್ಮ ಯಾವ ರಾಜ್ಯವನ್ನು ಆಳಿದಳು?" },
            options: [
              { en: "Mysuru", kn: "ಮೈಸೂರು" },
              { en: "Kittur", kn: "ಕಿತ್ತೂರು" },
              { en: "Hampi", kn: "ಹಂಪಿ" },
            ],
            answerIndex: 1,
          },
          {
            question: { en: "Whom did she fight against?", kn: "ಅವಳು ಯಾರ ವಿರುದ್ಧ ಹೋರಾಡಿದಳು?" },
            options: [
              { en: "The British", kn: "ಬ್ರಿಟಿಷರು" },
              { en: "The Mughals", kn: "ಮೊಘಲರು" },
              { en: "The Marathas", kn: "ಮರಾಠರು" },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "What did she love as a child?", kn: "ಬಾಲ್ಯದಲ್ಲಿ ಅವಳಿಗೆ ಏನು ಪ್ರಿಯವಾಗಿತ್ತು?" },
            options: [
              { en: "Painting", kn: "ಚಿತ್ರಕಲೆ" },
              { en: "Singing", kn: "ಹಾಡುಗಾರಿಕೆ" },
              { en: "Sword fighting & riding", kn: "ಕತ್ತಿವರಸೆ ಮತ್ತು ಸವಾರಿ" },
            ],
            answerIndex: 2,
          },
        
          {
            question: { en: 'In which year was Chennamma born?', kn: 'ಚೆನ್ನಮ್ಮ ಯಾವ ವರ್ಷ ಜನಿಸಿದರು?' },
            options: [
              { en: '1778', kn: '೧೭೭೮' },
              { en: '1857', kn: '೧೮೫೭' },
              { en: '1900', kn: '೧೯೦೦' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'Her birth village was…', kn: 'ಜನ್ಮಸ್ಥಳ?' },
            options: [
              { en: 'Kakati', kn: 'ಕಾಕತಿ' },
              { en: 'Kittur', kn: 'ಕಿತ್ತೂರು' },
              { en: 'Hampi', kn: 'ಹಂಪಿ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'In which year did she revolt?', kn: 'ಯಾವಾಗ ದಂಗೆ?' },
            options: [
              { en: '1824', kn: '೧೮೨೪' },
              { en: '1757', kn: '೧೭೫೭' },
              { en: '1947', kn: '೧೯೪೭' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'Which British officer was killed?', kn: 'ಕೊಲ್ಲಲ್ಪಟ್ಟ ಅಧಿಕಾರಿ?' },
            options: [
              { en: 'Thackeray', kn: 'ಥ್ಯಾಕ್ರೆ' },
              { en: 'Clive', kn: 'ಕ್ಲೈವ್' },
              { en: 'Dalhousie', kn: 'ಡಲ್ಹೌಸಿ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'She was jailed at…', kn: 'ಎಲ್ಲಿ ಸೆರೆವಾಸ?' },
            options: [
              { en: 'Bailhongal', kn: 'ಬೈಲಹೊಂಗಲ' },
              { en: 'Bidar', kn: 'ಬೀದರ್' },
              { en: 'Mysuru', kn: 'ಮೈಸೂರು' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'Rule used by British to seize Kittur?', kn: 'ಬ್ರಿಟಿಷರ ನಿಯಮ?' },
            options: [
              { en: 'Doctrine of Lapse', kn: 'ದತ್ತು ಪುತ್ರನಿಗೆ ಹಕ್ಕಿಲ್ಲ' },
              { en: 'Salt Tax', kn: 'ಉಪ್ಪು ತೆರಿಗೆ' },
              { en: 'Rowlatt', kn: 'ರೌಲತ್' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'She is a symbol of…', kn: 'ಸಂಕೇತ?' },
            options: [
              { en: "Women's courage", kn: 'ಮಹಿಳಾ ಶೌರ್ಯ' },
              { en: 'Trade', kn: 'ವ್ಯಾಪಾರ' },
              { en: 'Music', kn: 'ಸಂಗೀತ' },
            ],
            answerIndex: 0,
          },
        ],
        memorial: {
          name: { en: "Kittur Fort & Chennamma Statue", kn: "ಕಿತ್ತೂರು ಕೋಟೆ ಮತ್ತು ಚೆನ್ನಮ್ಮ ಪ್ರತಿಮೆ" },
          place: { en: "Kittur, Belagavi District", kn: "ಕಿತ್ತೂರು, ಬೆಳಗಾವಿ ಜಿಲ್ಲೆ" },
          description: {
            en: "The historic Kittur Fort and museum preserves Rani Chennamma's legacy. A grand statue stands at the entrance.",
            kn: "ಐತಿಹಾಸಿಕ ಕಿತ್ತೂರು ಕೋಟೆ ಮತ್ತು ವಸ್ತುಸಂಗ್ರಹಾಲಯವು ರಾಣಿ ಚೆನ್ನಮ್ಮನ ಪರಂಪರೆಯನ್ನು ಕಾಪಾಡಿಕೊಂಡಿದೆ.",
          },
          mapsQuery: "Kittur Fort Belagavi Karnataka",
        },
      },
    ],
  },
  {
    id: "shivamogga",
    name: { en: "Shivamogga", kn: "ಶಿವಮೊಗ್ಗ" },
    emoji: "🌳",
    heroes: [
      {
        id: "kuvempu",
        name: { en: "Kuvempu", kn: "ಕುವೆಂಪು" },
        title: { en: "The Poet of Karnataka", kn: "ಕರ್ನಾಟಕದ ಕವಿ" },
        era: "1904 – 1994",
        emoji: "📜",
        pages: [
          {
            emoji: "🌳",
            bg: "bg-gradient-warm",
            text: {
              en: "Long ago, in a beautiful village called Hirekodige in Shivamogga, a boy named Kuppali Venkatappa Puttappa was born. Everyone called him Kuvempu. He grew up in the misty green hills of Kuppalli, surrounded by the giant trees and singing birds of the Western Ghats. These forests were his first teachers, and he spent his childhood marveling at the wonders of nature. The rustling leaves and flowing streams filled his heart with music and magic. Even as a small boy, Kuvempu felt a deep connection to the Earth. He promised himself that one day, he would share the beauty of his homeland with the whole world through the power of his words and stories.",
              kn: "ಹಲವು ವರ್ಷಗಳ ಹಿಂದೆ, ಶಿವಮೊಗ್ಗ ಜಿಲ್ಲೆಯ ಹಿರೇಕೊಡಿಗೆ ಎಂಬ ಸುಂದರ ಗ್ರಾಮದಲ್ಲಿ ಕುಪ್ಪಳಿ ವೆಂಕಟಪ್ಪ ಪುಟ್ಟಪ್ಪ ಎಂಬ ಬಾಲಕ ಜನಿಸಿದನು. ಎಲ್ಲರೂ ಅವನನ್ನು ಕುವೆಂಪು ಎಂದು ಕರೆಯುತ್ತಿದ್ದರು. ಇವರು ಮಲೆನಾಡಿನ ಹಸಿರು ಬೆಟ್ಟಗಳ ನಡುವೆ, ಪಶ್ಚಿಮ ಘಟ್ಟಗಳ ದಟ್ಟ ಅರಣ್ಯಗಳಲ್ಲಿ ಬೆಳೆದರು. ಈ ಕಾಡುಗಳೇ ಅವರ ಮೊದಲ ಗುರುಗಳಾಗಿದ್ದವು. ಎಲೆಗಳ ಮರ್ಮರ ಮತ್ತು ಹರಿಯುವ ತೊರೆಗಳ ಶಬ್ದವು ಅವರಲ್ಲಿ ಕುತೂಹಲ ಮೂಡಿಸಿತು. ಬಾಲ್ಯದಲ್ಲಿಯೇ ಕುವೆಂಪು ಅವರು ಪ್ರಕೃತಿಯೊಂದಿಗೆ ಗಾಢವಾದ ಸಂಬಂಧವನ್ನು ಹೊಂದಿದ್ದರು. ಒಂದು ದಿನ ತಮ್ಮ ಮಾತು ಮತ್ತು ಕಥೆಗಳ ಮೂಲಕ ಕನ್ನಡ ನಾಡಿನ ಸೌಂದರ್ಯವನ್ನು ಜಗತ್ತಿಗೆ ಪರಿಚಯಿಸಬೇಕೆಂದು ಅವರು ಅಂದುಕೊಂಡರು.",
            },
          },
          {
            emoji: "✍️",
            bg: "bg-gradient-sunset",
            text: {
              en: "As Kuvempu grew older, his love for the Kannada language blossomed like a wildflower. He studied hard and started writing poems that captured the spirit of Karnataka. He believed that learning should happen in one's own mother tongue so that every child could understand and dream big. Kuvempu moved to Mysuru to continue his journey of learning and eventually became the Vice-Chancellor of Mysore University. He worked tirelessly to make Kannada the heart of education. He taught everyone that our language is not just a way to speak, but a way to celebrate our unique culture and the land where we were born.",
              kn: "ಕುವೆಂಪು ಬೆಳೆಯುತ್ತಿದ್ದಂತೆ, ಕನ್ನಡ ಭಾಷೆಯ ಮೇಲಿನ ಅವರ ಪ್ರೀತಿ ಹೆಚ್ಚಾಯಿತು. ಅವರು ಶ್ರದ್ಧೆಯಿಂದ ವ್ಯಾಸಂಗ ಮಾಡಿ ಕರ್ನಾಟಕದ ಸಂಸ್ಕೃತಿಯನ್ನು ಪ್ರತಿಬಿಂಬಿಸುವ ಕವಿತೆಗಳನ್ನು ಬರೆಯಲು ಪ್ರಾರಂಭಿಸಿದರು. ಪ್ರತಿಯೊಂದು ಮಗುವೂ ದೊಡ್ಡ ಕನಸು ಕಾಣಬೇಕಾದರೆ ಶಿಕ್ಷಣವು ಮಾತೃಭಾಷೆಯಲ್ಲಿಯೇ ಇರಬೇಕೆಂದು ಅವರು ನಂಬಿದ್ದರು. ತಮ್ಮ ಕಲಿಕೆಯ ಪ್ರಯಾಣವನ್ನು ಮುಂದುವರಿಸಲು ಕುವೆಂಪು ಮೈಸೂರಿಗೆ ತೆರಳಿದರು ಮತ್ತು ಮೈಸೂರು ವಿಶ್ವವಿದ್ಯಾಲಯದ ಕುಲಪತಿಗಳಾದರು. ಕನ್ನಡವನ್ನು ಶಿಕ್ಷಣದ ಕೇಂದ್ರಬಿಂದುವನ್ನಾಗಿ ಮಾಡಲು ಅವರು ದಣಿವರಿಯಿಲ್ಲದೆ ಶ್ರಮಿಸಿದರು. ಭಾಷೆಯು ಕೇವಲ ಸಂವಹನವಲ್ಲ, ಅದು ನಮ್ಮ ಸಂಸ್ಕೃತಿಯನ್ನು ಆಚರಿಸುವ ಹಾದಿ ಎಂದು ಅವರು ತಿಳಿಸಿಕೊಟ್ಟರು.",
            },
          },
          {
            emoji: "📜",
            bg: "bg-gradient-warm",
            text: {
              en: "Kuvempu’s greatest masterpiece was a grand book titled 'Sri Ramayana Darshanam'. In this epic work, he retold an ancient story with a fresh vision and beautiful Kannada verses. It was so magnificent that in 1967, he became the very first Kannada writer to receive the prestigious Jnanpith Award. This was a moment of great pride for every person in Karnataka. He didn’t just write about kings and queens; he wrote about the values of truth, kindness, and courage. His words showed that Kannada literature was as deep and vast as an ocean, earning him the title of the National Poet of Karnataka.",
              kn: "ಕುವೆಂಪು ಅವರ ಶ್ರೇಷ್ಠ ಕೃತಿ 'ಶ್ರೀ ರಾಮಾಯಣ ದರ್ಶನಂ'. ಈ ಮಹಾಕಾವ್ಯದಲ್ಲಿ ಅವರು ಪ್ರಾಚೀನ ಕಥೆಯನ್ನು ಹೊಸ ದೃಷ್ಟಿಕೋನದಿಂದ ಮತ್ತು ಸುಂದರವಾದ ಕನ್ನಡ ಪದ್ಯಗಳಲ್ಲಿ ಮರುಸೃಷ್ಟಿಸಿದರು. ಈ ಕೃತಿಯು ಎಷ್ಟು ಅದ್ಭುತವಾಗಿತ್ತೆಂದರೆ, 1967 ರಲ್ಲಿ ಪ್ರತಿಷ್ಠಿತ ಜ್ಞಾನಪೀಠ ಪ್ರಶಸ್ತಿಯನ್ನು ಪಡೆದ ಮೊದಲ ಕನ್ನಡಿಗ ಎಂಬ ಗೌರವಕ್ಕೆ ಇವರು ಪಾತ್ರರಾದರು. ಇದು ಪ್ರತಿಯೊಬ್ಬ ಕನ್ನಡಿಗೂ ಹೆಮ್ಮೆಯ ವಿಷಯವಾಗಿತ್ತು. ಅವರು ಕೇವಲ ರಾಜರು ಮತ್ತು ರಾಣಿಯರ ಬಗ್ಗೆ ಬರೆಯಲಿಲ್ಲ; ಅವರು ಸತ್ಯ, ದಯೆ ಮತ್ತು ಧೈರ್ಯದ ಮೌಲ್ಯಗಳ ಬಗ್ಗೆ ಬರೆದರು. ಅವರ ಮಾತುಗಳು ಕನ್ನಡ ಸಾಹಿತ್ಯವು ಸಮುದ್ರದಷ್ಟೇ ಆಳ ಮತ್ತು ವಿಶಾಲವಾಗಿದೆ ಎಂದು ತೋರಿಸಿಕೊಟ್ಟವು.",
            },
          },
          {
            emoji: "🌏",
            bg: "bg-gradient-sunset",
            text: {
              en: "Beyond books, Kuvempu had a dream for all of humanity. He introduced a wonderful idea called 'Vishwa Manava' or the Universal Human. He wanted people to break down the walls of caste and religion that separate us. He taught children that we are all citizens of the world first. He received many honors for his wisdom, including the Padma Vibhushan and the Karnataka Ratna, which is the highest civilian award in the state. Even with all this fame, he remained a humble person who loved the simple life of the mountains. He showed us that being a great human is just as important as being a great writer.",
              kn: "ಪುಸ್ತಕಗಳ ಆಚೆಗೆ, ಕುವೆಂಪು ಅವರು ಮಾನವೀಯತೆಗಾಗಿ ಒಂದು ದೊಡ್ಡ ಕನಸನ್ನು ಹೊಂದಿದ್ದರು. ಅವರು 'ವಿಶ್ವ ಮಾನವ' ಎಂಬ ಅದ್ಭುತ ಪರಿಕಲ್ಪನೆಯನ್ನು ಪರಿಚಯಿಸಿದರು. ಜನರನ್ನು ವಿಭಜಿಸುವ ಜಾತಿ ಮತ್ತು ಧರ್ಮದ ಗೋಡೆಗಳನ್ನು ಕೆಡವಬೇಕೆಂದು ಅವರು ಬಯಸಿದ್ದರು. ನಾವೆಲ್ಲರೂ ಮೊದಲು ವಿಶ್ವದ ಪ್ರಜೆಗಳು ಎಂದು ಅವರು ಮಕ್ಕಳಿಗೆ ಕಲಿಸಿದರು. ಅವರ ಜ್ಞಾನಕ್ಕಾಗಿ ಪದ್ಮವಿಭೂಷಣ ಮತ್ತು ರಾಜ್ಯದ ಅತ್ಯುನ್ನತ ನಾಗರಿಕ ಪ್ರಶಸ್ತಿಯಾದ ಕರ್ನಾಟಕ ರತ್ನ ಸೇರಿದಂತೆ ಅನೇಕ ಗೌರವಗಳು ಲಭಿಸಿದವು. ಇಷ್ಟೆಲ್ಲಾ ಖ್ಯಾತಿಯ ನಡುವೆಯೂ, ಅವರು ಮಲೆನಾಡಿನ ಸರಳ ಜೀವನವನ್ನು ಪ್ರೀತಿಸುವ ವಿನಮ್ರ ವ್ಯಕ್ತಿಯಾಗಿ ಉಳಿದರು. ಉತ್ತಮ ಬರಹಗಾರರಾಗುವುದರ ಜೊತೆಗೆ ಉತ್ತಮ ಮಾನವರಾಗುವುದು ಮುಖ್ಯ ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು.",
            },
          },
          {
            emoji: "🎶",
            bg: "bg-gradient-warm",
            text: {
              en: "Today, every time we sing 'Jaya Bharata Jananiya Tanujate', we are singing the words written by Kuvempu. This beautiful song is the official anthem of Karnataka, celebrating our state as the daughter of Mother India. Although he passed away in 1994, his spirit lives on in every schoolroom and library. His home in Kuppalli is now a beautiful museum where children can visit to see where the magic began. Kuvempu’s life teaches us to love our nature, respect our language, and treat every person in the world as our brother or sister. He remains a shining star guiding the hearts of all Kannadigas forever.",
              kn: "ಇಂದು ನಾವು 'ಜಯ ಭಾರತ ಜನನಿಯ ತನುಜಾತೆ' ಗೀತೆಯನ್ನು ಹಾಡುವಾಗಲೆಲ್ಲಾ ಕುವೆಂಪು ಅವರು ಬರೆದ ಪದಗಳನ್ನು ಸ್ಮರಿಸುತ್ತೇವೆ. ಇದು ನಮ್ಮ ಕರ್ನಾಟಕದ ನಾಡಗೀತೆಯಾಗಿದೆ. ಅವರು 1994 ರಲ್ಲಿ ನಿಧನರಾದರು, ಆದರೆ ಅವರ ವಿಚಾರಗಳು ಪ್ರತಿ ಶಾಲೆಯಲ್ಲಿ ಮತ್ತು ಗ್ರಂಥಾಲಯದಲ್ಲಿ ಇಂದಿಗೂ ಜೀವಂತವಾಗಿವೆ. ಕುಪ್ಪಳ್ಳಿಯಲ್ಲಿರುವ ಅವರ ಮನೆಯು ಈಗ ಸುಂದರವಾದ ವಸ್ತುಸಂಗ್ರಹಾಲಯವಾಗಿದ್ದು, ಮಕ್ಕಳು ಅಲ್ಲಿಗೆ ಭೇಟಿ ನೀಡಿ ಸ್ಪೂರ್ತಿ ಪಡೆಯಬಹುದು. ಪ್ರಕೃತಿಯನ್ನು ಪ್ರೀತಿಸುವುದು, ನಮ್ಮ ಭಾಷೆಯನ್ನು ಗೌರವಿಸುವುದು ಮತ್ತು ಪ್ರತಿಯೊಬ್ಬ ವ್ಯಕ್ತಿಯನ್ನು ಸಮಾನವಾಗಿ ಕಾಣುವುದನ್ನು ಕುವೆಂಪು ಅವರ ಜೀವನ ನಮಗೆ ಕಲಿಸುತ್ತದೆ. ಅವರು ಎಂದೆಂದಿಗೂ ಕನ್ನಡಿಗರ ಹೃದಯದಲ್ಲಿ ಮಿನುಗುವ ನಕ್ಷತ್ರವಾಗಿ ಉಳಿಯುತ್ತಾರೆ.",
            },
          }
        ],
        quiz: [
          {
            question: { en: "What is Kuvempu's real name?", kn: "ಕುವೆಂಪು ಅವರ ನಿಜವಾದ ಹೆಸರು ಏನು?" },
            options: [
              { en: "Puttappa", kn: "ಪುಟ್ಟಪ್ಪ" },
              { en: "Basavappa", kn: "ಬಸವಪ್ಪ" },
              { en: "Shivappa", kn: "ಶಿವಪ್ಪ" },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "Which great award did he win?", kn: "ಅವರು ಯಾವ ಮಹಾನ್ ಪ್ರಶಸ್ತಿಯನ್ನು ಗೆದ್ದರು?" },
            options: [
              { en: "Oscar", kn: "ಆಸ್ಕರ್" },
              { en: "Jnanpith", kn: "ಜ್ಞಾನಪೀಠ" },
              { en: "Nobel", kn: "ನೊಬೆಲ್" },
            ],
            answerIndex: 1,
          },
          {
            question: { en: "He wrote Karnataka's…", kn: "ಅವರು ಕರ್ನಾಟಕದ ... ಬರೆದರು" },
            options: [
              { en: "Map", kn: "ನಕ್ಷೆ" },
              { en: "State anthem", kn: "ನಾಡಗೀತೆ" },
              { en: "Constitution", kn: "ಸಂವಿಧಾನ" },
            ],
            answerIndex: 1,
          },
        
          {
            question: { en: 'Kuvempu was born in…', kn: 'ಜನ್ಮಸ್ಥಳ?' },
            options: [
              { en: 'Kuppalli', kn: 'ಕುಪ್ಪಳಿ' },
              { en: 'Mysuru', kn: 'ಮೈಸೂರು' },
              { en: 'Hampi', kn: 'ಹಂಪಿ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'In which year was he born?', kn: 'ಜನ್ಮ ವರ್ಷ?' },
            options: [
              { en: '1904', kn: '೧೯೦೪' },
              { en: '1850', kn: '೧೮೫೦' },
              { en: '1947', kn: '೧೯೪೭' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'His epic on Ramayana is…', kn: 'ರಾಮಾಯಣ ಮಹಾಕಾವ್ಯ?' },
            options: [
              { en: 'Sri Ramayana Darshanam', kn: 'ಶ್ರೀ ರಾಮಾಯಣ ದರ್ಶನಂ' },
              { en: 'Mahabharata', kn: 'ಮಹಾಭಾರತ' },
              { en: 'Vachana', kn: 'ವಚನ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "Karnataka's state anthem starts with…", kn: 'ನಾಡಗೀತೆ?' },
            options: [
              { en: 'Jaya Bharata Jananiya', kn: 'ಜಯ ಭಾರತ ಜನನಿಯ' },
              { en: 'Vande Mataram', kn: 'ವಂದೇ ಮಾತರಂ' },
              { en: 'Sare Jahan', kn: 'ಸಾರೆ ಜಹಾ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He passed away in…', kn: 'ಮರಣ ವರ್ಷ?' },
            options: [
              { en: '1994', kn: '೧೯೯೪' },
              { en: '1947', kn: '೧೯೪೭' },
              { en: '1850', kn: '೧೮೫೦' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "His message is 'Vishwa…'", kn: 'ಸಂದೇಶ?' },
            options: [
              { en: 'Manava', kn: 'ಮಾನವ' },
              { en: 'Yuddha', kn: 'ಯುದ್ಧ' },
              { en: 'Dhana', kn: 'ಧನ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'His memorial rock is called…', kn: 'ಸ್ಮಾರಕ?' },
            options: [
              { en: 'Kavishaila', kn: 'ಕವಿಶೈಲ' },
              { en: 'Hampi', kn: 'ಹಂಪಿ' },
              { en: 'Gol Gumbaz', kn: 'ಗೋಲ್ ಗುಂಬಜ್' },
            ],
            answerIndex: 0,
          },
        ],
        memorial: {
          name: { en: "Kavishaila & Kuppalli Memorial", kn: "ಕವಿಶೈಲ ಮತ್ತು ಕುಪ್ಪಳಿ ಸ್ಮಾರಕ" },
          place: { en: "Kuppalli, Shivamogga District", kn: "ಕುಪ್ಪಳಿ, ಶಿವಮೊಗ್ಗ ಜಿಲ್ಲೆ" },
          description: {
            en: "Kuvempu's birthplace turned museum, with the famous Kavishaila rock memorial set in the Western Ghats.",
            kn: "ಕುವೆಂಪು ಅವರ ಜನ್ಮಸ್ಥಳ ಇಂದು ವಸ್ತುಸಂಗ್ರಹಾಲಯವಾಗಿದೆ, ಪಶ್ಚಿಮ ಘಟ್ಟಗಳಲ್ಲಿ ಪ್ರಸಿದ್ಧ ಕವಿಶೈಲ ಸ್ಮಾರಕ ಇದೆ.",
          },
          mapsQuery: "Kavishaila Kuppalli Shivamogga",
        },
      },
    ],
  },
  {
    id: "bagalkot",
    name: { en: "Bagalkot", kn: "ಬಾಗಲಕೋಟೆ" },
    emoji: "🪔",
    heroes: [
      {
        id: "basavanna",
        name: { en: "Basavanna", kn: "ಬಸವಣ್ಣ" },
        title: { en: "The Social Reformer & Vachana Poet", kn: "ಸಮಾಜ ಸುಧಾರಕ ಮತ್ತು ವಚನಕಾರ" },
        era: "12th Century",
        emoji: "🪔",
        pages: [
          {
            emoji: "☀️",
            bg: "bg-gradient-warm",
            text: {
              en: "Long ago, in the year 1131, a brilliant boy named Basavanna was born in Basavana Bagewadi, located in the modern Bagalkot district of Karnataka. From a young age, he was a deep thinker who questioned the world around him. While others followed old rituals without knowing why, Basavanna sought a deeper truth that included everyone. He grew up with a heart full of kindness and a mind sharp with wisdom, eventually leaving his home to seek knowledge at Kudalasangama. There, among the rivers, he realized that God lives within every human heart, not just in stone temples. This spark of understanding would eventually lead him to change the lives of thousands of people across the land, teaching them that all human beings are born equal and deserving of love.",
              kn: "ಬಹಳ ಹಿಂದೆಯೇ, 1131 ಸಂವತ್ಸರದಲ್ಲಿ, ಕರ್ನಾಟಕದ ಈಗಿನ ಬಾಗಲಕೋಟೆ ಜಿಲ್ಲೆಯ ಬಸವನ ಬಾಗೇವಾಡಿಯಲ್ಲಿ ಬಸವಣ್ಣ ಎಂಬ ಪ್ರಕಾಶಮಾನವಾದ ಬಾಲಕನು ಜನಿಸಿದನು. ಚಿಕ್ಕ ವಯಸ್ಸಿನಿಂದಲೇ ಅವರು ತಮ್ಮ ಸುತ್ತಲಿನ ಪ್ರಪಂಚವನ್ನು ಪ್ರಶ್ನಿಸುವ ಆಳವಾದ ಚಿಂತಕರಾಗಿದ್ದರು. ಇತರರು ಹಳೆಯ ಆಚರಣೆಗಳನ್ನು ಕಾರಣವಿಲ್ಲದೆ ಅನುಸರಿಸುತ್ತಿರುವಾಗ, ಬಸವಣ್ಣನವರು ಎಲ್ಲರನ್ನು ಒಳಗೊಳ್ಳುವ ಆಳವಾದ ಸತ್ಯವನ್ನು ಹುಡುಕಿದರು. ಅವರು ದಯೆ ತುಂಬಿದ ಹೃದಯ ಮತ್ತು ಬುದ್ಧಿವಂತಿಕೆಯಿಂದ ಬೆಳೆದು, ಜ್ಞಾನವನ್ನು ಹುಡುಕುತ್ತಾ ಕೂಡಲಸಂಗಮಕ್ಕೆ ತೆರಳಿದರು. ಅಲ್ಲಿ ನದಿಗಳ ಸಂಗಮದಲ್ಲಿ, ದೇವರು ಕೇವಲ ಕಲ್ಲಿನ ಗುಡಿಗಳಲ್ಲಿ ಮಾತ್ರವಲ್ಲದೆ ಪ್ರತಿಯೊಬ್ಬ ಮನುಷ್ಯನ ಹೃದಯದಲ್ಲೂ ನೆಲೆಸಿದ್ದಾನೆ ಎಂದು ಅವರು ಅರಿತುಕೊಂಡರು. ಈ ತಿಳುವಳಿಕೆಯ ಕಿಡಿಯು ಅಂತಿಮವಾಗಿ ನಾಡಿನ ಸಾವಿರಾರು ಜನರ ಜೀವನವನ್ನು ಬದಲಾಯಿಸಲು ಕಾರಣವಾಯಿತು.",
            },
          },
          {
            emoji: "📜",
            bg: "bg-gradient-sunset",
            text: {
              en: "As Basavanna grew older, his brilliance and honesty led him to a very important job. He became the Prime Minister for the King Bijjala II in the kingdom of Kalyani. Even though he lived in a grand palace and held great power, he never forgot the common people. He spent his days working for the welfare of the poor and ensuring justice for everyone. During this time, he began writing beautiful free-verse poems called Vachanas. These were simple yet powerful messages written in the Kannada language so that everyone, from farmers to scholars, could understand them. He taught that rituals and status did not matter; what truly mattered was a person's character and the goodness in their soul.",
              kn: "ಬಸವಣ್ಣನವರು ಬೆಳೆಯುತ್ತಾ ಹೋದಂತೆ, ಅವರ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ಪ್ರಾಮಾಣಿಕತೆಯು ಅವರಿಗೆ ಅತ್ಯಂತ ಪ್ರಮುಖವಾದ ಕೆಲಸವನ್ನು ತಂದುಕೊಟ್ಟಿತು. ಅವರು ಕಲ್ಯಾಣಿ ಸಾಮ್ರಾಜ್ಯದ ರಾಜ ಬಿಜ್ಜಳನ ಆಸ್ಥಾನದಲ್ಲಿ ಪ್ರಧಾನ ಮಂತ್ರಿಯಾದರು. ಅವರು ಭವ್ಯವಾದ ಅರಮನೆಯಲ್ಲಿ ವಾಸಿಸುತ್ತಿದ್ದರೂ ಮತ್ತು ಹೆಚ್ಚಿನ ಅಧಿಕಾರವನ್ನು ಹೊಂದಿದ್ದರೂ, ಅವರು ಸಾಮಾನ್ಯ ಜನರನ್ನು ಎಂದಿಗೂ ಮರೆಯಲಿಲ್ಲ. ಅವರು ಬಡವರ ಕಲ್ಯಾಣಕ್ಕಾಗಿ ಮತ್ತು ಎಲ್ಲರಿಗೂ ನ್ಯಾಯವನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು ತಮ್ಮ ದಿನಗಳನ್ನು ಕಳೆದರು. ಈ ಸಮಯದಲ್ಲಿ, ಅವರು 'ವಚನಗಳು' ಎಂದು ಕರೆಯಲ್ಪಡುವ ಸುಂದರವಾದ ಕವಿತೆಗಳನ್ನು ಬರೆಯಲು ಪ್ರಾರಂಭಿಸಿದರು. ರೈತರಿಂದ ಹಿಡಿದು ವಿದ್ವಾಂಸರವರೆಗೆ ಎಲ್ಲರಿಗೂ ಅರ್ಥವಾಗುವಂತೆ ಕನ್ನಡ ಭಾಷೆಯಲ್ಲಿ ಸರಳ ಮತ್ತು ಶಕ್ತಿಯುತ ಸಂದೇಶಗಳನ್ನು ನೀಡಿದರು. ಆಚರಣೆಗಳು ಮತ್ತು ಅಂತಸ್ತು ಮುಖ್ಯವಲ್ಲ, ಮನುಷ್ಯನ ಚಾರಿತ್ರ್ಯ ಮತ್ತು ಆತ್ಮದ ಒಳ್ಳೆಯತನವೇ ಮುಖ್ಯ ಎಂದು ಅವರು ಬೋಧಿಸಿದರು.",
            },
          },
          {
            emoji: "🛠️",
            bg: "bg-gradient-warm",
            text: {
              en: "One of the most famous lessons Basavanna taught was 'Kayakave Kailasa,' which means that honest work is itself heaven. He wanted everyone to understand that no job was too small and that every person should earn their living through hard work. Whether someone was a cobbler, a weaver, or a king, Basavanna believed they were all equal in the eyes of the Divine. He encouraged people to take pride in their daily tasks and to treat their work as a form of worship. This revolutionary idea gave dignity to thousands of workers who had been looked down upon for centuries. By celebrating the dignity of labour, Basavanna helped build a society where everyone felt valued and respected for their contributions.",
              kn: "ಬಸವಣ್ಣನವರು ನೀಡಿದ ಅತ್ಯಂತ ಪ್ರಸಿದ್ಧ ಬೋಧನೆಗಳಲ್ಲಿ ಒಂದು 'ಕಾಯಕವೇ ಕೈಲಾಸ'. ಅಂದರೆ ಪ್ರಾಮಾಣಿಕವಾಗಿ ಮಾಡುವ ಕೆಲಸವೇ ಸ್ವರ್ಗ ಎಂದರ್ಥ. ಯಾವುದೇ ಕೆಲಸವು ಚಿಕ್ಕದಲ್ಲ ಮತ್ತು ಪ್ರತಿಯೊಬ್ಬ ವ್ಯಕ್ತಿಯು ಕಠಿಣ ಪರಿಶ್ರಮದ ಮೂಲಕ ತಮ್ಮ ಜೀವನವನ್ನು ನಡೆಸಬೇಕು ಎಂದು ಅವರು ಬಯಸಿದ್ದರು. ಯಾರೇ ಆಗಿರಲಿ, ಅವರು ದೈವದ ದೃಷ್ಟಿಯಲ್ಲಿ ಸಮಾನರು ಎಂದು ಬಸವಣ್ಣನವರು ನಂಬಿದ್ದರು. ಜನರು ತಮ್ಮ ದೈನಂದಿನ ಕೆಲಸಗಳಲ್ಲಿ ಹೆಮ್ಮೆ ಪಡಲು ಮತ್ತು ತಮ್ಮ ಕೆಲಸವನ್ನು ಆರಾಧನೆಯಂತೆ ಪರಿಗಣಿಸಲು ಅವರು ಪ್ರೋತ್ಸಾಹಿಸಿದರು. ಈ ಕ್ರಾಂತಿಕಾರಿ ಕಲ್ಪನೆಯು ಶತಮಾನಗಳಿಂದ ಕೀಳಾಗಿ ಕಾಣಲ್ಪಟ್ಟ ಸಾವಿರಾರು ಕಾರ್ಮಿಕರಿಗೆ ಗೌರವವನ್ನು ನೀಡಿತು. ಶ್ರಮದ ಗೌರವವನ್ನು ಎತ್ತಿಹಿಡಿಯುವ ಮೂಲಕ, ಪ್ರತಿಯೊಬ್ಬರೂ ತಮ್ಮ ಕೊಡುಗೆಗಾಗಿ ಮೌಲ್ಯಯುತವಾಗಿ ಮತ್ತು ಗೌರವಾನ್ವಿತವಾಗಿ ಕಾಣುವ ಸಮಾಜವನ್ನು ನಿರ್ಮಿಸಲು ಬಸವಣ್ಣನವರು ಸಹಾಯ ಮಾಡಿದರು.",
            },
          },
          {
            emoji: "🏛️",
            bg: "bg-gradient-sunset",
            text: {
              en: "To bring people together, Basavanna established a wonderful place called the Anubhava Mantapa. This was the world's first democratic parliament of mystics and philosophers. He opened its doors to everyone, regardless of their caste, gender, or background. Men and women sat together to discuss life, God, and how to live a good life. This was a place where even the poorest person could stand up and share their wisdom with the Prime Minister. Through these discussions, Basavanna founded the Lingayat tradition, focusing on a direct connection with God. It was a time of great social change where the barriers that divided people began to crumble, replaced by a sense of brotherhood and shared purpose among all followers.",
              kn: "ಜನರನ್ನು ಒಗ್ಗೂಡಿಸಲು, ಬಸವಣ್ಣನವರು 'ಅನುಭವ ಮಂಟಪ' ಎಂಬ ಅದ್ಭುತವಾದ ಸ್ಥಳವನ್ನು ಸ್ಥಾಪಿಸಿದರು. ಇದು ಜಗತ್ತಿನ ಮೊದಲ ಪ್ರಜಾಪ್ರಭುತ್ವದ ಸಂಸತ್ತಿನಂತಿತ್ತು. ಜಾತಿ, ಲಿಂಗ ಅಥವಾ ಹಿನ್ನೆಲೆಯ ಭೇದವಿಲ್ಲದೆ ಅವರು ಇದರ ಬಾಗಿಲುಗಳನ್ನು ಎಲ್ಲರಿಗೂ ತೆರೆದರು. ಪುರುಷರು ಮತ್ತು ಮಹಿಳೆಯರು ಒಟ್ಟಾಗಿ ಕುಳಿತು ಜೀವನ, ದೇವರು ಮತ್ತು ಸನ್ಮಾರ್ಗದಲ್ಲಿ ಬದುಕುವುದು ಹೇಗೆ ಎಂದು ಚರ್ಚಿಸುತ್ತಿದ್ದರು. ಅತ್ಯಂತ ಬಡ ವ್ಯಕ್ತಿಯೂ ಸಹ ಎದ್ದು ನಿಂತು ಪ್ರಧಾನ ಮಂತ್ರಿಯೊಂದಿಗೆ ತನ್ನ ಜ್ಞಾನವನ್ನು ಹಂಚಿಕೊಳ್ಳಬಹುದಾದ ಸ್ಥಳ ಇದಾಗಿತ್ತು. ಈ ಚರ್ಚೆಗಳ ಮೂಲಕ, ಬಸವಣ್ಣನವರು ಲಿಂಗಾಯತ ಸಂಪ್ರದಾಯವನ್ನು ಸ್ಥಾಪಿಸಿದರು. ಇದು ಜನರ ನಡುವಿನ ಅಡೆತಡೆಗಳನ್ನು ತೆಗೆದುಹಾಕಿ, ಸಹೋದರತ್ವ ಮತ್ತು ಹಂಚಿಕೆಯ ಉದ್ದೇಶದ ಭಾವನೆಯನ್ನು ಮೂಡಿಸಿದ ಸಾಮಾಜಿಕ ಬದಲಾವಣೆಯ ಕಾಲವಾಗಿತ್ತು.",
            },
          },
          {
            emoji: "🕯️",
            bg: "bg-gradient-warm",
            text: {
              en: "Today, Basavanna is remembered as a great light who showed us the path of equality and kindness. His Vachanas are still sung and recited by millions of people who find peace and guidance in his words. He taught us that the greatest temple is the human body and the purest worship is treating others with love. His legacy lives on in Karnataka and beyond, inspiring people to fight against unfair treatment and to work hard with a happy heart. Every time we help someone in need or treat a stranger as a friend, we are following the path Basavanna walked long ago. He remains a true hero whose message of 'equal rights for all' continues to shine brightly, guiding generations toward a better world.",
              kn: "ಇಂದು ಬಸವಣ್ಣನವರನ್ನು ನಮಗೆ ಸಮಾನತೆ ಮತ್ತು ದಯೆಯ ಹಾದಿಯನ್ನು ತೋರಿಸಿದ ಮಹಾನ್ ಜ್ಯೋತಿಯಾಗಿ ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ಅವರ ವಚನಗಳನ್ನು ಇಂದಿಗೂ ಲಕ್ಷಾಂತರ ಜನರು ಹಾಡುತ್ತಾರೆ ಮತ್ತು ಸ್ಮರಿಸುತ್ತಾರೆ. ಮಾನವ ದೇಹವೇ ದೇಗುಲ ಮತ್ತು ಇತರರನ್ನು ಪ್ರೀತಿಯಿಂದ ಕಾಣುವುದೇ ನಿಜವಾದ ಪೂಜೆ ಎಂದು ಅವರು ನಮಗೆ ಕಲಿಸಿದರು. ಅವರ ಪರಂಪರೆಯು ಕರ್ನಾಟಕದಲ್ಲಿ ಮತ್ತು ಅದರಾಚೆಗೂ ಜೀವಂತವಾಗಿದೆ, ಅನ್ಯಾಯದ ವಿರುದ್ಧ ಹೋರಾಡಲು ಮತ್ತು ಸಂತೋಷದ ಹೃದಯದಿಂದ ಕಠಿಣ ಪರಿಶ್ರಮ ಪಡಲು ಜನರನ್ನು ಪ್ರೇರೇಪಿಸುತ್ತದೆ. ನಾವು ಅಗತ್ಯವಿರುವ ಯಾರಿಗಾದರೂ ಸಹಾಯ ಮಾಡಿದಾಗ ಅಥವಾ ಅಪರಿಚಿತರನ್ನ ಸ್ನೇಹಿತರಂತೆ ನಡೆಸಿಕೊಂಡಾಗ, ನಾವು ಬಸವಣ್ಣನವರು ನಡೆದ ಹಾದಿಯಲ್ಲಿ ಸಾಗುತ್ತಿದ್ದೇವೆ ಎಂದರ್ಥ. 'ಎಲ್ಲರಿಗೂ ಸಮಾನ ಹಕ್ಕು' ಎಂಬ ಅವರ ಸಂದೇಶವು ಮುಂದಿನ ಪೀಳಿಗೆಗೆ ದಾರಿದೀಪವಾಗಿ ಪ್ರಕಾಶಮಾನವಾಗಿ ಬೆಳಗುತ್ತಲೇ ಇರುತ್ತದೆ.",
            },
          }
        ],
        quiz: [
          {
            question: { en: "What did Basavanna call his poems?", kn: "ಬಸವಣ್ಣ ತಮ್ಮ ಕವಿತೆಗಳನ್ನು ಏನು ಕರೆದರು?" },
            options: [
              { en: "Vachanas", kn: "ವಚನಗಳು" },
              { en: "Shlokas", kn: "ಶ್ಲೋಕಗಳು" },
              { en: "Ragas", kn: "ರಾಗಗಳು" },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "What hall did he start?", kn: "ಅವರು ಯಾವ ಮಂಟಪವನ್ನು ಸ್ಥಾಪಿಸಿದರು?" },
            options: [
              { en: "Anubhava Mantapa", kn: "ಅನುಭವ ಮಂಟಪ" },
              { en: "Vidhana Soudha", kn: "ವಿಧಾನ ಸೌಧ" },
              { en: "Raja Sabha", kn: "ರಾಜ ಸಭೆ" },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "His main message was…", kn: "ಅವರ ಮುಖ್ಯ ಸಂದೇಶ..." },
            options: [
              { en: "War", kn: "ಯುದ್ಧ" },
              { en: "Equality", kn: "ಸಮಾನತೆ" },
              { en: "Wealth", kn: "ಸಂಪತ್ತು" },
            ],
            answerIndex: 1,
          },
        
          {
            question: { en: 'Basavanna was born in…', kn: 'ಜನ್ಮಸ್ಥಳ?' },
            options: [
              { en: 'Basavana Bagewadi', kn: 'ಬಸವನ ಬಾಗೇವಾಡಿ' },
              { en: 'Hampi', kn: 'ಹಂಪಿ' },
              { en: 'Mysuru', kn: 'ಮೈಸೂರು' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He lived in which century?', kn: 'ಶತಮಾನ?' },
            options: [
              { en: '12th', kn: '೧೨ನೇ' },
              { en: '18th', kn: '೧೮ನೇ' },
              { en: '20th', kn: '೨೦ನೇ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "Famous saying 'Kayakave…'", kn: "'ಕಾಯಕವೇ...'" },
            options: [
              { en: 'Kailasa', kn: 'ಕೈಲಾಸ' },
              { en: 'Yuddha', kn: 'ಯುದ್ಧ' },
              { en: 'Dhana', kn: 'ಧನ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He served which king?', kn: 'ಯಾವ ರಾಜ?' },
            options: [
              { en: 'Bijjala II', kn: 'ಬಿಜ್ಜಳ' },
              { en: 'Tipu', kn: 'ಟಿಪ್ಪು' },
              { en: 'Krishnadevaraya', kn: 'ಕೃಷ್ಣದೇವರಾಯ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He attained enlightenment at…', kn: 'ಜ್ಞಾನೋದಯ?' },
            options: [
              { en: 'Kudalasangama', kn: 'ಕೂಡಲಸಂಗಮ' },
              { en: 'Hampi', kn: 'ಹಂಪಿ' },
              { en: 'Belur', kn: 'ಬೇಲೂರು' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He was the founder of…', kn: 'ಸ್ಥಾಪಕ?' },
            options: [
              { en: 'Lingayat tradition', kn: 'ಲಿಂಗಾಯತ' },
              { en: 'Jainism', kn: 'ಜೈನ' },
              { en: 'Sikhism', kn: 'ಸಿಖ್' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'Vachanas were written in…', kn: 'ವಚನಗಳ ಭಾಷೆ?' },
            options: [
              { en: 'Kannada', kn: 'ಕನ್ನಡ' },
              { en: 'Sanskrit', kn: 'ಸಂಸ್ಕೃತ' },
              { en: 'Tamil', kn: 'ತಮಿಳು' },
            ],
            answerIndex: 0,
          },
        ],
        memorial: {
          name: { en: "Basavanna Birthplace Temple", kn: "ಬಸವಣ್ಣ ಜನ್ಮಸ್ಥಳ ದೇವಾಲಯ" },
          place: { en: "Basavana Bagewadi, Bagalkot", kn: "ಬಸವನ ಬಾಗೇವಾಡಿ, ಬಾಗಲಕೋಟೆ" },
          description: {
            en: "The temple and museum at Basavanna's birthplace honour his life and teachings.",
            kn: "ಬಸವಣ್ಣ ಅವರ ಜನ್ಮಸ್ಥಳದಲ್ಲಿರುವ ದೇವಾಲಯ ಮತ್ತು ವಸ್ತುಸಂಗ್ರಹಾಲಯ ಅವರ ಜೀವನವನ್ನು ಗೌರವಿಸುತ್ತದೆ.",
          },
          mapsQuery: "Basavana Bagewadi Bagalkot Karnataka",
        },
      },
    ],
  },
  {
    id: "mysuru",
    name: { en: "Mysuru", kn: "ಮೈಸೂರು" },
    emoji: "🐯",
    heroes: [
      {
        id: "tipu-sultan",
        name: { en: "Tipu Sultan", kn: "ಟಿಪ್ಪು ಸುಲ್ತಾನ್" },
        title: { en: "The Tiger of Mysuru", kn: "ಮೈಸೂರಿನ ಹುಲಿ" },
        era: "1750 – 1799",
        emoji: "🐯",
        pages: [
          {
            emoji: "🐅",
            bg: "bg-gradient-warm",
            text: {
              en: "In the lush land of Devanahalli, a brave boy named Tipu Sultan was born to the powerful ruler Hyder Ali. From a young age, Tipu was fascinated by the deep forests and the strength of the tiger, which later became his famous emblem. He grew up listening to stories of courage and the beauty of his homeland, Mysore. His father ensured that the young prince learned everything about leadership and justice. Tipu was not just a prince; he was a curious child who loved his culture and people dearly. Everyone in the kingdom looked at him with great hope, knowing that this boy was destined to become the legendary 'Tiger of Mysore' who would one day change the history of Karnataka forever with his indomitable spirit and heart of gold.",
              kn: "ದೇವನಹಳ್ಳಿಯ ಸಮೃದ್ಧ ಭೂಮಿಯಲ್ಲಿ, ಶಕ್ತಿಯುತ ಆಡಳಿತಗಾರ ಹೈದರ್ ಅಲಿಯ ಮಗನಾಗಿ ಟಿಪ್ಪು ಸುಲ್ತಾನ್ ಜನಿಸಿದನು. ಚಿಕ್ಕಂದಿನಿಂದಲೂ ಟಿಪ್ಪುವಿಗೆ ದಟ್ಟ ಅರಣ್ಯಗಳು ಮತ್ತು ಹುಲಿಯ ಬಲದ ಬಗ್ಗೆ ಅಪಾರ ಆಸಕ್ತಿ ಇತ್ತು, ಅದು ಮುಂದೆ ಅವನ ಪ್ರಸಿದ್ಧ ಲಾಂಛನವಾಯಿತು. ಅವನು ಮೈಸೂರಿನ ಸೌಂದರ್ಯ ಮತ್ತು ಧೈರ್ಯದ ಕಥೆಗಳನ್ನು ಕೇಳುತ್ತಾ ಬೆಳೆದನು. ಯುವ ರಾಜನು ನಾಯಕತ್ವ ಮತ್ತು ನ್ಯಾಯದ ಬಗ್ಗೆ ಎಲ್ಲವನ್ನೂ ಕಲಿಯುವಂತೆ ಅವನ ತಂದೆ ಕಾಳಜಿ ವಹಿಸಿದರು. ಟಿಪ್ಪು ಕೇವಲ ಒಬ್ಬ ರಾಜಕುಮಾರನಾಗಿರಲಿಲ್ಲ; ಅವನು ತನ್ನ ಸಂಸ್ಕೃತಿ ಮತ್ತು ಜನರನ್ನು ಪ್ರೀತಿಸುವ ಕುತೂಹಲಿ ಬಾಲಕನಾಗಿದ್ದನು. ರಾಜ್ಯದ ಪ್ರತಿಯೊಬ್ಬರೂ ಅವನನ್ನು ಬಹಳ ಭರವಸೆಯಿಂದ ನೋಡುತ್ತಿದ್ದರು, ಈ ಹುಡುಗ ಒಂದು ದಿನ ತನ್ನ ಅಪ್ರತಿಮ ಚೈತನ್ಯದಿಂದ ಕರ್ನಾಟಕದ ಇತಿಹಾಸವನ್ನು ಶಾಶ್ವತವಾಗಿ ಬದಲಾಯಿಸುವ 'ಮೈಸೂರು ಹುಲಿ'ಯಾಗುತ್ತಾನೆ ಎಂದು ಅವರಿಗೆ ತಿಳಿದಿತ್ತು.",
            },
          },
          {
            emoji: "📚",
            bg: "bg-gradient-sunset",
            text: {
              en: "As he grew, Tipu Sultan became a brilliant student of many subjects. He was not satisfied with just learning how to use a sword; he wanted to modernize his kingdom. He studied science, languages, and new technologies from across the world. His mind was always working on ways to help his people prosper. Tipu realized that for Mysore to be strong, it needed more than just a brave army; it needed education and industry. He began to envision a future where his land would be a center of knowledge and innovation. This period of his life was filled with learning and preparing for the huge responsibilities that were soon to come his way as the future Sultan of Mysore.",
              kn: "ಬೆಳೆಯುತ್ತಾ ಹೋದಂತೆ, ಟಿಪ್ಪು ಸುಲ್ತಾನ್ ಅನೇಕ ವಿಷಯಗಳ ಅದ್ಭುತ ವಿದ್ಯಾರ್ಥಿಯಾದನು. ಕೇವಲ ಕತ್ತಿವರಸೆಯನ್ನು ಕಲಿಯುವುದರಿಂದ ಅವನು ತೃಪ್ತನಾಗಲಿಲ್ಲ; ಅವನು ತನ್ನ ರಾಜ್ಯವನ್ನು ಆಧುನೀಕರಿಸಲು ಬಯಸಿದನು. ಅವನು ವಿಜ್ಞಾನ, ಭಾಷೆಗಳು ಮತ್ತು ವಿಶ್ವದಾದ್ಯಂತದ ಹೊಸ ತಂತ್ರಜ್ಞಾನಗಳನ್ನು ಅಧ್ಯಯನ ಮಾಡಿದನು. ಅವನ ಮನಸ್ಸು ಯಾವಾಗಲೂ ತನ್ನ ಜನರ ಏಳಿಗೆಗೆ ಸಹಾಯ ಮಾಡುವ ಮಾರ್ಗಗಳ ಬಗ್ಗೆ ಯೋಚಿಸುತ್ತಿತ್ತು. ಮೈಸೂರು ಬಲಗೊಳ್ಳಲು ಕೇವಲ ಕೆಚ್ಚೆದೆಯ ಸೈನ್ಯಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ ಶಿಕ್ಷಣ ಮತ್ತು ಕೈಗಾರಿಕೆಗಳ ಅಗತ್ಯವಿದೆ ಎಂದು ಟಿಪ್ಪು ಅರಿತುಕೊಂಡನು. ತನ್ನ ಭೂಮಿಯು ಜ್ಞಾನ ಮತ್ತು ನಾವೀನ್ಯತೆಯ ಕೇಂದ್ರವಾಗುವ ಭವಿಷ್ಯವನ್ನು ಅವನು ರೂಪಿಸಲು ಪ್ರಾರಂಭಿಸಿದನು. ಅವನ ಜೀವನದ ಈ ಅವಧಿಯು ಜ್ಞಾನಾರ್ಜನೆ ಮತ್ತು ಮುಂದಿನ ದಿನಗಳಲ್ಲಿ ಮೈಸೂರಿನ ಸುಲ್ತಾನನಾಗಿ ಬರಲಿರುವ ದೊಡ್ಡ ಜವಾಬ್ದಾರಿಗಳಿಗೆ ಸಿದ್ಧವಾಗುವುದರಲ್ಲೇ ಕಳೆಯಿತು.",
            },
          },
          {
            emoji: "🚀",
            bg: "bg-gradient-warm",
            text: {
              en: "When Tipu became the Sultan in 1782, he achieved something incredible that changed the world of science. He pioneered the invention of iron-cased Mysorean rockets! These were not fireworks; they were advanced machines used to defend the kingdom. These rockets were so clever that they later inspired the British to create their own Congreve rockets. Tipu was a true scientist at heart. He also introduced a brand new system of coinage, a unique calendar, and brought the silk industry, known as sericulture, to Karnataka. Because of his vision, thousands of families started making beautiful silk, a tradition that continues to make our state famous today. He wanted Mysore to be a leader in both technology and trade.",
              kn: "೧೭೮೨ ರಲ್ಲಿ ಟಿಪ್ಪು ಸುಲ್ತಾನನಾದಾಗ, ಅವನು ವಿಜ್ಞಾನ ಲೋಕವನ್ನೇ ಬದಲಿಸಿದ ಅದ್ಭುತ ಸಾಧನೆಯನ್ನು ಮಾಡಿದನು. ಅವನು ಕಬ್ಬಿಣದ ಆವರಣದ ಮೈಸೂರು ರಾಕೆಟ್‌ಗಳ ಆವಿಷ್ಕಾರಕ್ಕೆ ನಾಂದಿ ಹಾಡಿದನು! ಇವು ಕೇವಲ ಪಟಾಕಿಗಳಾಗಿರಲಿಲ್ಲ; ಇವು ರಾಜ್ಯವನ್ನು ರಕ್ಷಿಸಲು ಬಳಸುವ ಸುಧಾರಿತ ಯಂತ್ರಗಳಾಗಿದ್ದವು. ಈ ರಾಕೆಟ್‌ಗಳು ಎಷ್ಟು ಚತುರತೆಯಿಂದ ಕೂಡಿದ್ದವೆಂದರೆ, ಮುಂದೆ ಬ್ರಿಟಿಷರು ತಮ್ಮದೇ ಆದ ಕಾಂಗ್ರೀವ್ ರಾಕೆಟ್‌ಗಳನ್ನು ತಯಾರಿಸಲು ಇವು ಪ್ರೇರಣೆಯಾದವು. ಟಿಪ್ಪು ಹದಿನೆಂಟನೇ ಶತಮಾನದ ಶ್ರೇಷ್ಠ ವಿಜ್ಞಾನಿಯಾಗಿದ್ದನು. ಅವನು ಹೊಸ ನಾಣ್ಯ ಪದ್ಧತಿ, ವಿಶಿಷ್ಟ ಕ್ಯಾಲೆಂಡರ್ ಮತ್ತು ರೇಷ್ಮೆ ಉದ್ಯಮವನ್ನು ಕರ್ನಾಟಕಕ್ಕೆ ಪರಿಚಯಿಸಿದನು. ಅವನ ದೂರದೃಷ್ಟಿಯಿಂದಾಗಿ ಸಾವಿರಾರು ಕುಟುಂಬಗಳು ಸುಂದರವಾದ ರೇಷ್ಮೆಯನ್ನು ತಯಾರಿಸಲು ಪ್ರಾರಂಭಿಸಿದವು, ಈ ಸಂಪ್ರದಾಯವು ಇಂದಿಗೂ ನಮ್ಮ ರಾಜ್ಯವನ್ನು ಪ್ರಸಿದ್ಧಗೊಳಿಸಿದೆ.",
            },
          },
          {
            emoji: "⚔️",
            bg: "bg-gradient-sunset",
            text: {
              en: "Tipu’s reign was a time of great struggle as he fought four difficult Anglo-Mysore wars to protect his land from foreign rule. He was a master strategist who never gave up, earning his title as the Tiger of Mysore through his fierce bravery on the battlefield. He believed in freedom above all else and worked tirelessly to keep his kingdom independent. In 1799, the final battle reached the great Srirangapatna fort. Even when the walls were under attack, Tipu Sultan refused to fly a white flag of surrender. He chose to stand and fight with his soldiers until the very end. He died bravely defending the gates of his beloved fort, proving that he would rather give his life than lose his honor.",
              kn: "ಪರಕೀಯರ ಆಳ್ವಿಕೆಯಿಂದ ತನ್ನ ಭೂಮಿಯನ್ನು ರಕ್ಷಿಸಲು ಟಿಪ್ಪು ನಾಲ್ಕು ಕಠಿಣ ಆಂಗ್ಲೋ-ಮೈಸೂರು ಯುದ್ಧಗಳನ್ನು ಎದುರಿಸಬೇಕಾಯಿತು. ಅವನು ಎಂದಿಗೂ ಸೋಲೊಪ್ಪದ ಶ್ರೇಷ್ಠ ಯುದ್ಧತಂತ್ರಜ್ಞನಾಗಿದ್ದನು, ಯುದ್ಧಭೂಮಿಯಲ್ಲಿನ ತನ್ನ ತೀವ್ರ ಶೌರ್ಯದ ಮೂಲಕ 'ಮೈಸೂರು ಹುಲಿ' ಎಂಬ ಬಿರುದನ್ನು ಗಳಿಸಿದನು. ಅವನು ಎಲ್ಲಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ ಸ್ವಾತಂತ್ರ್ಯವನ್ನು ನಂಬಿದ್ದನು ಮತ್ತು ತನ್ನ ರಾಜ್ಯವನ್ನು ಸ್ವತಂತ್ರವಾಗಿಡಲು ದಣಿವರಿಯಿಲ್ಲದೆ ಕೆಲಸ ಮಾಡಿದನು. ೧೭೯೯ ರಲ್ಲಿ, ಅಂತಿಮ ಯುದ್ಧವು ಶ್ರೀರಂಗಪಟ್ಟಣದ ಕೋಟೆಯನ್ನು ತಲುಪಿತು. ಕೋಟೆಯ ಗೋಡೆಗಳ ಮೇಲೆ ದಾಳಿಯಾದಾಗಲೂ, ಟಿಪ್ಪು ಸುಲ್ತಾನ್ ಶರಣಾಗಲು ನಿರಾಕರಿಸಿದನು. ಅವನು ತನ್ನ ಸೈನಿಕರೊಂದಿಗೆ ಕೊನೆಯವರೆಗೂ ಹೋರಾಡಲು ನಿರ್ಧರಿಸಿದನು. ತನ್ನ ಪ್ರೀತಿಯ ಕೋಟೆಯ ಬಾಗಿಲುಗಳನ್ನು ರಕ್ಷಿಸುತ್ತಾ ಅವನು ವೀರಮರಣವನ್ನಪ್ಪಿದನು, ಗೌರವವನ್ನು ಕಳೆದುಕೊಳ್ಳುವ ಬದಲು ಪ್ರಾಣವನ್ನೇ ಅರ್ಪಿಸುವುದು ಲೇಸು ಎಂದು ಅವನು ಸಾಬೀತುಪಡಿಸಿದನು.",
            },
          },
          {
            emoji: "🌟",
            bg: "bg-gradient-warm",
            text: {
              en: "Today, Tipu Sultan is remembered as a hero who looked far into the future. From the silk sari weavers in Mysore to the modern scientists studying space rockets, his influence is still alive in Karnataka. Children visit the remains of the Srirangapatna fort to learn about his courage and clever inventions. He showed everyone that a leader should be brave, innovative, and dedicated to the progress of his people. His story reminds us to be proud of our history and to always keep learning and exploring new ideas. The legacy of the Tiger of Mysore continues to roar in our hearts, inspiring us to be brave and brilliant in everything we do for our wonderful nation.",
              kn: "ಇಂದು, ಟಿಪ್ಪು ಸುಲ್ತಾನನನ್ನು ಭವಿಷ್ಯವನ್ನು ಮೊದಲೇ ಊಹಿಸಿದ ನಾಯಕನೆಂದು ನೆನಪಿಸಿಕೊಳ್ಳಲಾಗುತ್ತದೆ. ಮೈಸೂರಿನ ರೇಷ್ಮೆ ಸೀರೆ ನೇಯುವವರಿಂದ ಹಿಡಿದು ಬಾಹ್ಯಾಕಾಶ ರಾಕೆಟ್‌ಗಳನ್ನು ಅಧ್ಯಯನ ಮಾಡುವ ಆಧುನಿಕ ವಿಜ್ಞಾನಿಗಳವರೆಗೆ, ಅವನ ಪ್ರಭಾವವು ಕರ್ನಾಟಕದಲ್ಲಿ ಇಂದಿಗೂ ಜೀವಂತವಾಗಿದೆ. ಮಕ್ಕಳು ಅವನ ಧೈರ್ಯ ಮತ್ತು ಚತುರ ಆವಿಷ್ಕಾರಗಳ ಬಗ್ಗೆ ತಿಳಿಯಲು ಶ್ರೀರಂಗಪಟ್ಟಣ ಕೋಟೆಯ ಸ್ಮಾರಕಗಳಿಗೆ ಭೇಟಿ ನೀಡುತ್ತಾರೆ. ಒಬ್ಬ ನಾಯಕನು ಧೈರ್ಯಶಾಲಿ, ನವೀನ ಮತ್ತು ತನ್ನ ಜನರ ಪ್ರಗತಿಗೆ ಬದ್ಧನಾಗಿರಬೇಕು ಎಂದು ಅವನು ತೋರಿಸಿಕೊಟ್ಟನು. ಅವನ ಕಥೆಯು ನಮ್ಮ ಇತಿಹಾಸದ ಬಗ್ಗೆ ಹೆಮ್ಮೆ ಪಡಲು ಮತ್ತು ಯಾವಾಗಲೂ ಹೊಸ ಆಲೋಚನೆಗಳನ್ನು ಕಲಿಯಲು ನಮಗೆ ಸ್ಫೂರ್ತಿ ನೀಡುತ್ತದೆ. ಮೈಸೂರು ಹುಲಿಯ ಪರಂಪರೆಯು ನಮ್ಮ ಹೃದಯದಲ್ಲಿ ಇಂದಿಗೂ ಮೊಳಗುತ್ತಿದೆ, ಪ್ರತಿ ಕೆಲಸದಲ್ಲಿಯೂ ಧೈರ್ಯ ಮತ್ತು ಜಾಣ್ಮೆಯನ್ನು ಪ್ರದರ್ಶಿಸಲು ನಮಗೆ ಪ್ರೇರಣೆಯಾಗಿದೆ.",
            },
          }
        ],
        quiz: [
          {
            question: { en: "What is Tipu Sultan's nickname?", kn: "ಟಿಪ್ಪು ಸುಲ್ತಾನನ ಅಡ್ಡಹೆಸರು ಏನು?" },
            options: [
              { en: "Lion of Mysuru", kn: "ಮೈಸೂರಿನ ಸಿಂಹ" },
              { en: "Tiger of Mysuru", kn: "ಮೈಸೂರಿನ ಹುಲಿ" },
              { en: "Eagle of Mysuru", kn: "ಮೈಸೂರಿನ ಗರುಡ" },
            ],
            answerIndex: 1,
          },
          {
            question: { en: "What did he invent?", kn: "ಅವನು ಏನನ್ನು ಕಂಡುಹಿಡಿದನು?" },
            options: [
              { en: "War rockets", kn: "ಯುದ್ಧ ರಾಕೆಟ್‌ಗಳು" },
              { en: "Telephone", kn: "ದೂರವಾಣಿ" },
              { en: "Bicycle", kn: "ಸೈಕಲ್" },
            ],
            answerIndex: 0,
          },
          {
            question: { en: "Which city did he rule?", kn: "ಅವನು ಯಾವ ನಗರವನ್ನು ಆಳಿದನು?" },
            options: [
              { en: "Mysuru", kn: "ಮೈಸೂರು" },
              { en: "Mangaluru", kn: "ಮಂಗಳೂರು" },
              { en: "Hubballi", kn: "ಹುಬ್ಬಳ್ಳಿ" },
            ],
            answerIndex: 0,
          },
        
          {
            question: { en: "Tipu's father was…", kn: 'ತಂದೆ?' },
            options: [
              { en: 'Hyder Ali', kn: 'ಹೈದರ್ ಅಲಿ' },
              { en: 'Akbar', kn: 'ಅಕ್ಬರ್' },
              { en: 'Shivaji', kn: 'ಶಿವಾಜಿ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He was born in…', kn: 'ಜನ್ಮಸ್ಥಳ?' },
            options: [
              { en: 'Devanahalli', kn: 'ದೇವನಹಳ್ಳಿ' },
              { en: 'Mysuru', kn: 'ಮೈಸೂರು' },
              { en: 'Bidar', kn: 'ಬೀದರ್' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'His capital fort was…', kn: 'ಕೋಟೆ?' },
            options: [
              { en: 'Srirangapatna', kn: 'ಶ್ರೀರಂಗಪಟ್ಟಣ' },
              { en: 'Bidar', kn: 'ಬೀದರ್' },
              { en: 'Hampi', kn: 'ಹಂಪಿ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He died in the year…', kn: 'ಮರಣ ವರ್ಷ?' },
            options: [
              { en: '1799', kn: '೧೭೯೯' },
              { en: '1857', kn: '೧೮೫೭' },
              { en: '1947', kn: '೧೯೪೭' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He fought how many Anglo-Mysore wars?', kn: 'ಎಷ್ಟು ಯುದ್ಧ?' },
            options: [
              { en: 'Four', kn: 'ನಾಲ್ಕು' },
              { en: 'Two', kn: 'ಎರಡು' },
              { en: 'Ten', kn: 'ಹತ್ತು' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He introduced which industry?', kn: 'ಯಾವ ಉದ್ಯಮ?' },
            options: [
              { en: 'Silk (sericulture)', kn: 'ರೇಷ್ಮೆ' },
              { en: 'Tea', kn: 'ಚಹಾ' },
              { en: 'Cotton', kn: 'ಹತ್ತಿ' },
            ],
            answerIndex: 0,
          },
          {
            question: { en: 'He became Sultan in…', kn: 'ಸುಲ್ತಾನನಾದ ವರ್ಷ?' },
            options: [
              { en: '1782', kn: '೧೭೮೨' },
              { en: '1900', kn: '೧೯೦೦' },
              { en: '1700', kn: '೧೭೦೦' },
            ],
            answerIndex: 0,
          },
        ],
        memorial: {
          name: { en: "Srirangapatna Fort & Gumbaz", kn: "ಶ್ರೀರಂಗಪಟ್ಟಣ ಕೋಟೆ ಮತ್ತು ಗುಂಬಜ್" },
          place: { en: "Srirangapatna, Mandya / Mysuru", kn: "ಶ್ರೀರಂಗಪಟ್ಟಣ" },
          description: {
            en: "Tipu Sultan's summer palace, fort and the Gumbaz mausoleum tell the story of his reign.",
            kn: "ಟಿಪ್ಪು ಸುಲ್ತಾನನ ಬೇಸಿಗೆ ಅರಮನೆ, ಕೋಟೆ ಮತ್ತು ಗುಂಬಜ್ ಸಮಾಧಿ ಅವನ ಆಡಳಿತದ ಕಥೆಯನ್ನು ಹೇಳುತ್ತವೆ.",
          },
          mapsQuery: "Srirangapatna Tipu Sultan Gumbaz",
        },
      },
    ],
  },
  {
    id: "ballari", name: { en: "Ballari", kn: "ಬಳ್ಳಾರಿ" }, emoji: "⛏️",
    heroes: [mkHero({
      id: "krishnadevaraya", emoji: "👑",
      name: ["Krishnadevaraya", "ಕೃಷ್ಣದೇವರಾಯ"],
      title: ["Emperor of Vijayanagara", "ವಿಜಯನಗರದ ಚಕ್ರವರ್ತಿ"],
      era: "1471 – 1529",
      pages: [
        ["In the golden heart of India during the 15th century, a young prince named Krishnadevaraya was born. Growing up in the Tuluva dynasty, he was raised with the wisdom of the Vedas and the discipline of a warrior. As a boy, he looked upon the rugged rocks of Ballari and the banks of the Tungabhadra River, dreaming of a kingdom where peace and prosperity would walk hand in hand. He understood early on that a true king must be both a brave protector and a gentle teacher. His education was not just about swords and bows, but also about the beauty of languages like Kannada and Sanskrit, preparing him for a destiny that would change the history of the Vijayanagara Empire forever.", "೧೫ನೇ ಶತಮಾನದಲ್ಲಿ ಭಾರತದ ಸುವರ್ಣ ಹೃದಯಭಾಗದಲ್ಲಿ ಕೃಷ್ಣದೇವರಾಯ ಎಂಬ ಯುವ ರಾಜಕುಮಾರ ಜನಿಸಿದನು. ತುಳುವ ವಂಶದಲ್ಲಿ ಬೆಳೆದ ಅವನಿಗೆ ವೇದಗಳ ಜ್ಞಾನ ಮತ್ತು ಯೋಧನ ಶಿಸ್ತನ್ನು ಕಲಿಸಲಾಯಿತು. ಬಳ್ಳಾರಿಯ ಒರಟು ಬಂಡೆಗಳು ಮತ್ತು ತುಂಗಭದ್ರಾ ನದಿಯ ತೀರವನ್ನು ನೋಡುತ್ತಾ ಬೆಳೆದ ಆ ಹುಡುಗ, ಶಾಂತಿ ಮತ್ತು ಸಮೃದ್ಧಿ ನೆಲೆಸುವ ಸಾಮ್ರಾಜ್ಯದ ಕನಸು ಕಂಡನು. ಒಬ್ಬ ನಿಜವಾದ ರಾಜನು ಧೈರ್ಯಶಾಲಿ ರಕ್ಷಕ ಮತ್ತು ಸೌಮ್ಯ ಶಿಕ್ಷಕ ಎರಡೂ ಆಗಿರಬೇಕು ಎಂದು ಅವನು ಮೊದಲೇ ಅರ್ಥಮಾಡಿಕೊಂಡಿದ್ದನು. ಅವನ ಶಿಕ್ಷಣವು ಕೇವಲ ಕತ್ತಿ ಮತ್ತು ಬಿಲ್ಲುಗಳಿಗೆ ಸೀಮಿತವಾಗಿರದೆ, ಕನ್ನಡ ಮತ್ತು ಸಂಸ್ಕೃತದಂತಹ ಭಾಷೆಗಳ ಸೌಂದರ್ಯವನ್ನು ಒಳಗೊಂಡಿತ್ತು, ಇದು ವಿಜಯನಗರ ಸಾಮ್ರಾಜ್ಯದ ಇತಿಹಾಸವನ್ನು ಶಾಶ್ವತವಾಗಿ ಬದಲಿಸುವ ಭವಿಷ್ಯಕ್ಕಾಗಿ ಅವನನ್ನು ಸಿದ್ಧಪಡಿಸಿತು.", "🏰"],
        ["In the year 1509, Krishnadevaraya was crowned the Emperor of Vijayanagara. His reign began during a time of great challenges, as neighboring rivals often threatened the peace of his borders. With great courage, he led his armies to victory against the Bahmani sultans and the Gajapatis of Odisha. He was a master of strategy, forming smart alliances with the Portuguese to strengthen his forces. Despite his power, he was known as a fair and just ruler who never fought for cruelty, but only to protect his people and restore order. Each victory brought more stability to the land, allowing the seeds of a magnificent civilization to finally sprout and grow strong under his watchful eye.", "೧೫೦೯ ರಲ್ಲಿ ಕೃಷ್ಣದೇವರಾಯನು ವಿಜಯನಗರದ ಚಕ್ರವರ್ತಿಯಾಗಿ ಪಟ್ಟಾಭಿಷೇಕಗೊಂಡನು. ನೆರೆಯ ಶತ್ರುಗಳು ಪದೇ ಪದೇ ಗಡಿಭಾಗದ ಶಾಂತಿಗೆ ಧಕ್ಕೆ ತರುತ್ತಿದ್ದ ಸವಾಲಿನ ಸಮಯದಲ್ಲಿ ಅವನ ಆಳ್ವಿಕೆ ಆರಂಭವಾಯಿತು. ಅತ್ಯಂತ ಧೈರ್ಯದಿಂದ, ಅವನು ಬಹಮನಿ ಸುಲ್ತಾನರ ಮತ್ತು ಒಡಿಶಾದ ಗಜಪತಿಗಳ ವಿರುದ್ಧ ತನ್ನ ಸೈನ್ಯವನ್ನು ವಿಜಯದತ್ತ ಮುನ್ನಡೆಸಿದನು. ಅವನು ಯುದ್ಧತಂತ್ರದ ಪಳಗಿದವನಾಗಿದ್ದು, ತನ್ನ ಸೈನ್ಯವನ್ನು ಬಲಪಡಿಸಲು ಪೋರ್ಚುಗೀಸರೊಂದಿಗೆ ಸ್ಮಾರ್ಟ್ ಮೈತ್ರಿಗಳನ್ನು ಮಾಡಿಕೊಂಡನು. ಮಹಾನ್ ಶಕ್ತಿಯನ್ನು ಹೊಂದಿದ್ದರೂ, ಅವನು ನ್ಯಾಯವಂತ ಆಡಳಿತಗಾರ ಎಂದು ಹೆಸರಾಗಿದ್ದನು; ಅವನು ಎಂದಿಗೂ ಕ್ರೌರ್ಯಕ್ಕಾಗಿ ಹೋರಾಡಲಿಲ್ಲ, ಕೇವಲ ತನ್ನ ಜನರನ್ನು ರಕ್ಷಿಸಲು ಮತ್ತು ಸುವ್ಯವಸ್ಥೆಯನ್ನು ಮರುಸ್ಥಾಪಿಸಲು ಮಾತ್ರ ಹೋರಾಡಿದನು. ಪ್ರತಿ ಜಯವು ನಾಡಿಗೆ ಹೆಚ್ಚಿನ ಸ್ಥಿರತೆಯನ್ನು ತಂದಿತು, ಅವನ ನಿಗಾ ಅಡಿಯಲ್ಲಿ ಒಂದು ಭವ್ಯ ನಾಗರಿಕತೆಯು ಬೆಳೆಯಲು ಅಡಿಪಾಯ ಹಾಕಿತು.", "⚔️"],
        ["Under his brilliant leadership, the capital city of Hampi transformed into one of the richest and most beautiful cities in the entire world. Foreign travelers were amazed to see diamonds and precious gems being sold openly in the bustling markets. Krishnadevaraya was not just focused on wealth; he cared deeply for the well-being of his farmers. He built massive irrigation tanks and canals to ensure that the fields remained green and the people never went hungry. The empire flourished like a magnificent garden. From the towering stone temples to the intricate carvings on every wall, the progress of the Vijayanagara Empire during his reign remains a testament to what a visionary leader can achieve through hard work and care.", "ಅವನ ಅದ್ಭುತ ನಾಯಕತ್ವದಲ್ಲಿ, ರಾಜಧಾನಿ ಹಂಪಿಯು ಇಡೀ ವಿಶ್ವದ ಅತ್ಯಂತ ಶ್ರೀಮಂತ ಮತ್ತು ಸುಂದರ ನಗರಗಳಲ್ಲಿ ಒಂದಾಗಿ ಮಾರ್ಪಟ್ಟಿತು. ಗಿಜಿಗುಡುವ ಮಾರುಕಟ್ಟೆಗಳಲ್ಲಿ ವಜ್ರ ಮತ್ತು ಅಮೂಲ್ಯ ರತ್ನಗಳನ್ನು ಬಹಿರಂಗವಾಗಿ ಮಾರಾಟ ಮಾಡುವುದನ್ನು ಕಂಡು ವಿದೇಶಿ ಪ್ರವಾಸಿಗರು ಆಶ್ಚರ್ಯಚಕಿತರಾದರು. ಕೃಷ್ಣದೇವರಾಯನು ಕೇವಲ ಸಂಪತ್ತಿನ ಮೇಲೆ ಗಮನ ಹರಿಸಲಿಲ್ಲ; ಅವನು ತನ್ನ ರೈತರ ಕಲ್ಯಾಣಕ್ಕಾಗಿ ಬಹಳ ಕಾಳಜಿ ವಹಿಸಿದನು. ಹೊಲಗಳು ಹಸಿರಾಗಿರುವಂತೆ ಮತ್ತು ಜನರು ಹಸಿವಿನಿಂದ ಬಳಲದಂತೆ ನೋಡಿಕೊಳ್ಳಲು ಅವನು ಬೃಹತ್ ನೀರಾವರಿ ಕೆರೆಗಳನ್ನು ಮತ್ತು ಕಾಲುವೆಗಳನ್ನು ನಿರ್ಮಿಸಿದನು. ಸಾಮ್ರಾಜ್ಯವು ಭವ್ಯವಾದ ಉದ್ಯಾನದಂತೆ ಅಭಿವೃದ್ಧಿ ಹೊಂದಿತು. ಎತ್ತರದ ಕಲ್ಲಿನ ದೇವಾಲಯಗಳಿಂದ ಹಿಡಿದು ಪ್ರತಿಯೊಂದು ಗೋಡೆಯ ಮೇಲಿನ ಸಂಕೀರ್ಣ ಕೆತ್ತನೆಗಳವರೆಗೆ, ಅವನ ಆಳ್ವಿಕೆಯ ವಿಜಯನಗರದ ಪ್ರಗತಿಯು ಒಬ್ಬ ದೂರದೃಷ್ಟಿಯ ನಾಯಕನು ಶ್ರಮ ಮತ್ತು ಕಾಳಜಿಯಿಂದ ಏನನ್ನು ಸಾಧಿಸಬಹುದು ಎಂಬುದಕ್ಕೆ ಸಾಕ್ಷಿಯಾಗಿದೆ.", "💎"],
        ["While he was a fearless warrior, Krishnadevaraya’s heart beats for art and literature. He was a great scholar who believed that a king’s pen was as mighty as his sword. In his court sat the 'Ashtadiggajas', the eight legendary poets who filled the halls with music and wisdom. The Emperor himself was a gifted writer, composing the famous work 'Amuktamalyada' in Telugu and various other texts in Sanskrit. He patronized poets in Kannada and several other languages, turning his court into a vibrant center of learning and creativity. By celebrating different cultures and languages, he united his people through the power of stories and verses, ensuring that the soul of India’s heritage would be preserved for many generations to come.", "ಅವನು ನಿರ್ಭೀತ ಯೋಧನಾಗಿದ್ದರೂ, ಕೃಷ್ಣದೇವರಾಯನ ಹೃದಯವು ಕಲೆ ಮತ್ತು ಸಾಹಿತ್ಯಕ್ಕಾಗಿ ಮಿಡಿಯುತ್ತಿತ್ತು. ರಾಜನ ಲೇಖನಿಯು ಅವನ ಕತ್ತಿಯಷ್ಟೇ ಶಕ್ತಿಯುತವಾದುದು ಎಂದು ನಂಬಿದ್ದ ಮಹಾನ್ ವಿದ್ವಾಂಸ ಅವನಾಗಿದ್ದನು. ಅವನ ಆಸ್ಥಾನದಲ್ಲಿ 'ಅಷ್ಟದಿಗ್ಗಜರು' ಎಂಬ ಎಂಟು ಪೌರಾಣಿಕ ಕವಿಗಳಿದ್ದರು, ಅವರು ಸಭಾಂಗಣಗಳನ್ನು ಸಂಗೀತ ಮತ್ತು ಬುದ್ಧಿವಂತಿಕೆಯಿಂದ ತುಂಬಿದ್ದರು. ಚಕ್ರವರ್ತಿಯೇ ಸ್ವತಃ ಪ್ರತಿಭಾನ್ವಿತ ಬರಹಗಾರನಾಗಿದ್ದು, ತೆಲುಗಿನಲ್ಲಿ 'ಆಮುಕ್ತಮಾಲ್ಯದ' ಎಂಬ ಪ್ರಸಿದ್ಧ ಕೃತಿಯನ್ನು ಮತ್ತು ಸಂಸ್ಕೃತದಲ್ಲಿ ವಿವಿಧ ಗ್ರಂಥಗಳನ್ನು ರಚಿಸಿದನು. ಅವರು ಕನ್ನಡ ಮತ್ತು ಇತರ ಭಾಷೆಗಳ ಕವಿಗಳನ್ನು ಪ್ರೋತ್ಸಾಹಿಸಿದರು, ತನ್ನ ಆಸ್ಥಾನವನ್ನು ಕಲಿಕೆ ಮತ್ತು ಸೃಜನಶೀಲತೆಯ ರೋಮಾಂಚಕ ಕೇಂದ್ರವಾಗಿ ಪರಿವರ್ತಿಸಿದರು. ವಿಭಿನ್ನ ಸಂಸ್ಕೃತಿಗಳು ಮತ್ತು ಭಾಷೆಗಳನ್ನು ಗೌರವಿಸುವ ಮೂಲಕ, ಕಥೆಗಳು ಮತ್ತು ಕವಿತೆಗಳ ಶಕ್ತಿಯ ಮೂಲಕ ಜನರನ್ನು ಒಗ್ಗೂಡಿಸಿದನು, ಇದರಿಂದ ಭಾರತದ ಪರಂಪರೆಯು ಮುಂದಿನ ತಲೆಮಾರುಗಳಿಗೆ ಉಳಿಯುವಂತಾಯಿತು.", "✍️"],
        ["The legacy of Emperor Krishnadevaraya lives on today in the majestic ruins of Hampi and the stories told in every household in Karnataka. Although he passed away in 1529, he is remembered as the greatest emperor of the Vijayanagara Empire. He taught us that true greatness comes from balance—the strength to defend the weak, the wisdom to build for the future, and the love for art that keeps a culture alive. Today, when children visit the stone chariot or the great temples of Ballari district, they feel the spirit of a king who turned a kingdom into a paradise. Krishnadevaraya remains a shining star in history, inspiring everyone to dream big and lead with kindness and courage.", "ಚಕ್ರವರ್ತಿ ಕೃಷ್ಣದೇವರಾಯನ ಪರಂಪರೆಯು ಇಂದು ಹಂಪಿಯ ಭವ್ಯ ಅವಶೇಷಗಳಲ್ಲಿ ಮತ್ತು ಕರ್ನಾಟಕದ ಪ್ರತಿ ಮನೆಯಲ್ಲೂ ಹೇಳಲಾಗುವ ಕಥೆಗಳಲ್ಲಿ ಜೀವಂತವಾಗಿದೆ. ಅವರು ೧೫೨೯ ರಲ್ಲಿ ನಿಧನರಾದರು, ಆದರೆ ಅವರನ್ನು ವಿಜಯನಗರ ಸಾಮ್ರಾಜ್ಯದ ಶ್ರೇಷ್ಠ ಚಕ್ರವರ್ತಿ ಎಂದು ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ನೈಜ ಶ್ರೇಷ್ಠತೆಯು ಸಮತೋಲನದಿಂದ ಬರುತ್ತದೆ ಎಂದು ಅವರು ನಮಗೆ ಕಲಿಸಿಕೊಟ್ಟರು—ದುರ್ಬಲರನ್ನು ರಕ್ಷಿಸುವ ಶಕ್ತಿ, ಭವಿಷ್ಯಕ್ಕಾಗಿ ನಿರ್ಮಿಸುವ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ಸಂಸ್ಕೃತಿಯನ್ನು ಜೀವಂತವಾಗಿಡುವ ಕಲೆಯ ಮೇಲಿನ ಪ್ರೀತಿ. ಇಂದು, ಮಕ್ಕಳು ಕಲ್ಲಿನ ರಥ ಅಥವಾ ಬಳ್ಳಾರಿ ಜಿಲ್ಲೆಯ ದೊಡ್ಡ ದೇವಾಲಯಗಳನ್ನು ಸಂದರ್ಶಿಸಿದಾಗ, ಸಾಮ್ರಾಜ್ಯವನ್ನು ಸ್ವರ್ಗವಾಗಿ ಪರಿವರ್ತಿಸಿದ ರಾಜನ ಚೈತನ್ಯವನ್ನು ಅವರು ಅನುಭವಿಸುತ್ತಾರೆ. ಕೃಷ್ಣದೇವರಾಯ ಇತಿಹಾಸದಲ್ಲಿ ಪ್ರಕಾಶಮಾನವಾದ ನಕ್ಷತ್ರವಾಗಿ ಉಳಿದಿದ್ದಾನೆ, ದೊಡ್ಡ ಕನಸು ಕಾಣಲು ಮತ್ತು ದಯೆ ಹಾಗೂ ಧೈರ್ಯದಿಂದ ಮುನ್ನಡೆಯಲು ಎಲ್ಲರಿಗೂ ಸ್ಫೂರ್ತಿ ನೀಡುತ್ತಾನೆ.", "🌟"]
      ],
      quiz: [
        ["Which empire did he rule?", "ಯಾವ ಸಾಮ್ರಾಜ್ಯ?", ["Vijayanagara", "Mauryan", "Chola"], ["ವಿಜಯನಗರ", "ಮೌರ್ಯ", "ಚೋಳ"], 0],
        ["His capital city was…", "ಅವನ ರಾಜಧಾನಿ...", ["Hampi", "Delhi", "Hubballi"], ["ಹಂಪಿ", "ದೆಹಲಿ", "ಹುಬ್ಬಳ್ಳಿ"], 0],
      
        ['He belonged to which dynasty?', 'ವಂಶ?', ['Tuluva', 'Hoysala', 'Chola'], ['ತುಳುವ', 'ಹೊಯ್ಸಳ', 'ಚೋಳ'], 0],
        ['He was crowned in…', 'ಪಟ್ಟಾಭಿಷೇಕ?', ['1509', '1300', '1700'], ['೧೫೦೯', '೧೩೦೦', '೧೭೦೦'], 0],
        ['He died in…', 'ಮರಣ ವರ್ಷ?', ['1529', '1700', '1857'], ['೧೫೨೯', '೧೭೦೦', '೧೮೫೭'], 0],
        ['Eight court poets were called…', 'ಎಂಟು ಕವಿಗಳು?', ['Ashtadiggajas', 'Vachanakaras', 'Dasaru'], ['ಅಷ್ಟದಿಗ್ಗಜರು', 'ವಚನಕಾರರು', 'ದಾಸರು'], 0],
        ['His Telugu work is…', 'ತೆಲುಗು ಕೃತಿ?', ['Amuktamalyada', 'Ramayana', 'Vachana'], ['ಆಮುಕ್ತಮಾಲ್ಯದ', 'ರಾಮಾಯಣ', 'ವಚನ'], 0],
        ['He defeated which sultans?', 'ಯಾರನ್ನು ಸೋಲಿಸಿದ?', ['Bahmani', 'Mughals', 'British'], ['ಬಹಮನಿ', 'ಮೊಘಲ್', 'ಬ್ರಿಟಿಷ್'], 0],
        ['Hampi sits on which river?', 'ಯಾವ ನದಿ?', ['Tungabhadra', 'Kaveri', 'Krishna'], ['ತುಂಗಭದ್ರಾ', 'ಕಾವೇರಿ', 'ಕೃಷ್ಣಾ'], 0],
        ['He allied with which Europeans?', 'ಯಾವ ಯುರೋಪಿಯನ್ನರು?', ['Portuguese', 'British', 'French'], ['ಪೋರ್ಚುಗೀಸರು', 'ಬ್ರಿಟಿಷ್', 'ಫ್ರೆಂಚ್'], 0],
      ],
      memorial: ["Hampi Ruins (UNESCO)", "ಹಂಪಿ ಅವಶೇಷಗಳು", "Hampi, near Ballari", "ಹಂಪಿ, ಬಳ್ಳಾರಿ ಬಳಿ", "The grand ruins of Vijayanagara stand at Hampi.", "ವಿಜಯನಗರದ ಭವ್ಯ ಅವಶೇಷಗಳು ಹಂಪಿಯಲ್ಲಿವೆ.", "Hampi Karnataka"],
    })],
  },
  {
    id: "bengaluru-rural", name: { en: "Bengaluru Rural", kn: "ಬೆಂಗಳೂರು ಗ್ರಾಮಾಂತರ" }, emoji: "🌾",
    heroes: [mkHero({
      id: "h-d-deve-gowda", emoji: "👨‍🌾",
      name: ["H. D. Deve Gowda", "ಎಚ್. ಡಿ. ದೇವೇಗೌಡ"],
      title: ["Farmer who became Prime Minister", "ಪ್ರಧಾನಿಯಾದ ರೈತ"],
      era: "1933 – present",
      pages: [
        ["In the small village of Haradanahalli in Hassan district, a young boy named H. D. Deve Gowda was born in 1933. Growing up in a humble farming family, he spent his days among the green fields and red soil of rural Karnataka. He watched his parents work hard under the sun to grow food for the country. These early years taught him the true value of hard work and the many struggles that farmers face every day. Even as he helped in the fields, he dreamed of a future where he could help his community and make life better for every person working the land. This deep connection to the earth stayed with him throughout his long journey from a small village to the biggest stages of Indian politics.", "ಹಾಸನ ಜಿಲ್ಲೆಯ ಹರದನಹಳ್ಳಿ ಎಂಬ ಸಣ್ಣ ಗ್ರಾಮದಲ್ಲಿ ೧೯೯೩ ರಲ್ಲಿ ಹೆಚ್. ಡಿ. ದೇವೇಗೌಡರು ಜನಿಸಿದರು. ಸಾಧಾರಣ ರೈತ ಕುಟುಂಬದಲ್ಲಿ ಬೆಳೆದ ಅವರು ಕರ್ನಾಟಕದ ಹಸಿರು ಗದ್ದೆಗಳು ಮತ್ತು ಕೆಂಪು ಮಣ್ಣಿನ ನಡುವೆ ತಮ್ಮ ದಿನಗಳನ್ನು ಕಳೆದರು. ದೇಶಕ್ಕೆ ಆಹಾರ ನೀಡಲು ತಮ್ಮ ಪೋಷಕರು ಬಿಸಿಲಿನಲ್ಲಿ ಕಷ್ಟಪಡುವುದನ್ನು ಅವರು ನೋಡುತ್ತಿದ್ದರು. ಈ ಆರಂಭಿಕ ದಿನಗಳು ಅವರಿಗೆ ಕಠಿಣ ಪರಿಶ್ರಮದ ಮೌಲ್ಯ ಮತ್ತು ರೈತರು ಪ್ರತಿದಿನ ಎದುರಿಸುವ ಸಂಕಷ್ಟಗಳನ್ನು ಕಲಿಸಿಕೊಟ್ಟವು. ಹೊಲಗಳಲ್ಲಿ ಕೆಲಸ ಮಾಡುತ್ತಿದ್ದರೂ, ತಮ್ಮ ಸಮುದಾಯಕ್ಕೆ ಸಹಾಯ ಮಾಡುವ ಮತ್ತು ಭೂಮಿ ನಂಬಿದ ಜನರ ಬದುಕನ್ನು ಉತ್ತಮಗೊಳಿಸುವ ಕನಸನ್ನು ಅವರು ಹೊಂದಿದ್ದರು. ಮಣ್ಣಿನೊಂದಿಗಿನ ಈ ಆಳವಾದ ಸಂಬಂಧವು ಅವರ ಸಣ್ಣ ಹಳ್ಳಿಯಿಂದ ಭಾರತೀಯ ರಾಜಕೀಯದ ದೊಡ್ಡ ವೇದಿಕೆಯವರೆಗಿನ ಸುದೀರ್ಘ ಪ್ರಯಾಣದಲ್ಲಿ ಅವರ ಜೊತೆಗೇ ಇತ್ತು.", "🌾"],
        ["Young Deve Gowda knew that education was the key to building a brighter future. He studied very hard and became a civil engineer. As an engineer, he understood how to build roads, bridges, and most importantly, irrigation systems that could bring water to thirsty crops. However, his heart was set on serving people through leadership. He decided to enter politics to represent the voices of the poor and the hardworking villagers. He started his political journey from the grassroots level, always keeping the concerns of common people in his mind. People admired his simple way of living and his deep knowledge of the land, which helped him quickly rise as a respected leader in the state of Karnataka.", "ಶಿಕ್ಷಣವು ಉಜ್ವಲ ಭವಿಷ್ಯವನ್ನು ನಿರ್ಮಿಸಲು ಪ್ರಮುಖವಾಗಿದೆ ಎಂದು ದೇವೇಗೌಡರು ತಿಳಿದಿದ್ದರು. ಅವರು ಶ್ರದ್ಧೆಯಿಂದ ಓದಿ ಸಿವಿಲ್ ಇಂಜಿನಿಯರ್ ಆದರು. ಒಬ್ಬ ಇಂಜಿನಿಯರ್ ಆಗಿ, ರಸ್ತೆಗಳು, ಸೇತುವೆಗಳು ಮತ್ತು ಮುಖ್ಯವಾಗಿ ಒಣಗುತ್ತಿರುವ ಬೆಳೆಗಳಿಗೆ ನೀರು ತರುವ ನೀರಾವರಿ ವ್ಯವಸ್ಥೆಗಳನ್ನು ಹೇಗೆ ನಿರ್ಮಿಸಬೇಕೆಂದು ಅವರು ಅರ್ಥಮಾಡಿಕೊಂಡರು. ಆದಾಗ್ಯೂ, ನಾಯಕತ್ವದ ಮೂಲಕ ಜನರ ಸೇವೆ ಮಾಡುವುದು ಅವರ ಮೂಲ ಗುರಿಯಾಗಿತ್ತು. ಬಡವರ ಮತ್ತು ಕಷ್ಟಪಟ್ಟು ದುಡಿಯುವ ಗ್ರಾಮಸ್ಥರ ಧ್ವನಿಯಾಗಲು ಅವರು ರಾಜಕೀಯಕ್ಕೆ ಪ್ರವೇಶಿಸಲು ನಿರ್ಧರಿಸಿದರು. ಸಾಮಾನ್ಯ ಜನರ ಸಮಸ್ಯೆಗಳನ್ನು ಸದಾ ನೆನಪಿನಲ್ಲಿಟ್ಟುಕೊಂಡು ಅವರು ತಳಮಟ್ಟದಿಂದಲೇ ತಮ್ಮ ರಾಜಕೀಯ ಪ್ರಯಾಣವನ್ನು ಪ್ರಾರಂಭಿಸಿದರು. ಅವರ ಸರಳ ಜೀವನಶೈಲಿ ಮತ್ತು ಮಣ್ಣಿನ ಬಗೆಗಿನ ಅವರ ಆಳವಾದ ಜ್ಞಾನವನ್ನು ಜನರು ಗೌರವಿಸಿದರು, ಇದು ಅವರು ಕರ್ನಾಟಕದ ಗೌರವಾನ್ವಿತ ನಾಯಕರಾಗಿ ಬೆಳೆಯಲು ಸಹಾಯ ಮಾಡಿತು.", "📐"],
        ["In 1994, H. D. Deve Gowda achieved a great milestone when he became the Chief Minister of Karnataka. During his time leading the state, he focused heavily on improving the lives of farmers and protecting the rich Kannada language. He worked tirelessly to ensure that water reached the remote corners of the state through better irrigation projects. He believed that if the farmers were happy, the whole state would prosper. His leadership was marked by a deep sense of duty and a focus on rural development. He was not just a politician in a suit; he was a 'son of the soil' who understood the language of the farmers and fought for their rights in the grand halls of the government building.", "೧೯೯೪ ರಲ್ಲಿ, ಹೆಚ್. ಡಿ. ದೇವೇಗೌಡರು ಕರ್ನಾಟಕದ ಮುಖ್ಯಮಂತ್ರಿಯಾದಾಗ ಒಂದು ದೊಡ್ಡ ಮೈಲಿಗಲ್ಲನ್ನು ಸಾಧಿಸಿದರು. ರಾಜ್ಯವನ್ನು ಮುನ್ನಡೆಸುವ ಕಾಲದಲ್ಲಿ, ಅವರು ರೈತರ ಜೀವನವನ್ನು ಸುಧಾರಿಸಲು ಮತ್ತು ಶ್ರೀಮಂತ ಕನ್ನಡ ಭಾಷೆಯನ್ನು ರಕ್ಷಿಸಲು ಹೆಚ್ಚು ಗಮನ ನೀಡಿದರು. ಉತ್ತಮ ನೀರಾವರಿ ಯೋಜನೆಗಳ ಮೂಲಕ ರಾಜ್ಯದ ಮೂಲೆ ಮೂಲೆಗೂ ನೀರು ತಲುಪುವಂತೆ ಅವರು ದಣಿವರಿಯಿಲ್ಲದೆ ಕೆಲಸ ಮಾಡಿದರು. ರೈತರು ಸಂತೋಷವಾಗಿದ್ದರೆ ಇಡೀ ರಾಜ್ಯವೇ ಸಮೃದ್ಧವಾಗುತ್ತದೆ ಎಂದು ಅವರು ನಂಬಿದ್ದರು. ಅವರ ನಾಯಕತ್ವವು ಕರ್ತವ್ಯ ಪ್ರಜ್ಞೆ ಮತ್ತು ಗ್ರಾಮೀಣಾಭಿವೃದ್ಧಿಯ ಮೇಲಿನ ಗಮನಕ್ಕೆ ಹೆಸರಾಗಿತ್ತು. ಅವರು ಕೇವಲ ಅಧಿಕಾರಿಯಾಗದೆ, ರೈತರ ಭಾಷೆಯನ್ನು ಅರ್ಥಮಾಡಿಕೊಂಡ 'ಮಣ್ಣಿನ ಮಗ'ನಾಗಿ ಸರ್ಕಾರಿ ಸದನಗಳಲ್ಲಿ ಅವರ ಹಕ್ಕುಗಳಿಗಾಗಿ ಹೋರಾಡಿದರು.", "🏛️"],
        ["The year 1996 brought an even bigger responsibility when he was chosen as the 11th Prime Minister of India. Leading a large group called the United Front, he moved to New Delhi to guide the entire nation. Even as the leader of one of the world's largest countries, he remained humble and never forgot his roots in Haradanahalli. He was the first person from Karnataka to reach this high position, making the entire state feel very proud. As Prime Minister, he continued to champion the causes of farmers and rural development across the whole of India. His short but impactful term showed the country that a simple farmer's son could lead the nation with wisdom, strength, and great care for the common man.", "೧೯೯೬ ರಲ್ಲಿ ಅವರು ಭಾರತದ ೧೧ ನೇ ಪ್ರಧಾನ ಮಂತ್ರಿಯಾಗಿ ಆಯ್ಕೆಯಾದಾಗ ಇನ್ನೂ ದೊಡ್ಡ ಜವಾಬ್ದಾರಿ ಅವರನ್ನು ಹುಡುಕಿ ಬಂದಿತು. ಯುನೈಟೆಡ್ ಫ್ರಂಟ್ ಎಂಬ ದೊಡ್ಡ ಒಕ್ಕೂಟವನ್ನು ಮುನ್ನಡೆಸುತ್ತಾ, ಅವರು ಇಡೀ ರಾಷ್ಟ್ರಕ್ಕೆ ಮಾರ್ಗದರ್ಶನ ನೀಡಲು ನವದೆಹಲಿಗೆ ತೆರಳಿದರು. ವಿಶ್ವದ ಅತಿದೊಡ್ಡ ದೇಶಗಳಲ್ಲಿ ಒಂದಾದ ಭಾರತದ ನಾಯಕರಾಗಿದ್ದರೂ, ಅವರು ವಿನಯವಂತರಾಗಿದ್ದರು ಮತ್ತು ಹರದನಹಳ್ಳಿಯ ತಮ್ಮ ಬೇರುಗಳನ್ನು ಎಂದಿಗೂ ಮರೆಯಲಿಲ್ಲ. ಈ ಉನ್ನತ ಸ್ಥಾನವನ್ನು ತಲುಪಿದ ಕರ್ನಾಟಕದ ಮೊದಲ ವ್ಯಕ್ತಿ ಇವರಾಗಿದ್ದು, ಇದು ಇಡೀ ರಾಜ್ಯಕ್ಕೆ ಹೆಮ್ಮೆ ತಂದಿತು. ಪ್ರಧಾನಮಂತ್ರಿಯಾಗಿ ಅವರು ಭಾರತದಾದ್ಯಂತ ರೈತರ ಮತ್ತು ಗ್ರಾಮೀಣಾಭಿವೃದ್ಧಿಯ ಪರವಾಗಿ ತಮ್ಮ ಧ್ವನಿಯನ್ನು ಮುಂದುವರಿಸಿದರು. ಅವರ ಅಲ್ಪಾವಧಿಯ ಆಡಳಿತವು ಸಾಮಾನ್ಯ ರೈತನ ಮಗ ಜ್ಞಾನ, ಶಕ್ತಿ ಮತ್ತು ಕಾಳಜಿಯಿಂದ ದೇಶವನ್ನು ಮುನ್ನಡೆಸಬಲ್ಲ ಎಂದು ತೋರಿಸಿಕೊಟ್ಟಿತು.", "🇮🇳"],
        ["Today, H. D. Deve Gowda is remembered as a legendary leader and the founder of the JD(S) party. His life story teaches children that no matter where you come from, you can achieve greatness through hard work and honesty. From the fields of Hassan to the Prime Minister's office, he remained dedicated to the welfare of the farming community and the promotion of the Kannada language. His legacy lives on in the irrigation canals that water the fields and the hearts of the people he served. He is a true hero for Karnataka, proof that a 'son of the soil' can grow to reach the stars while staying firmly connected to the earth that raised him.", "ಇಂದು, ಹೆಚ್. ಡಿ. ದೇವೇಗೌಡರನ್ನು ಸುಪ್ರಸಿದ್ಧ ನಾಯಕ ಮತ್ತು ಜೆಡಿ(ಎಸ್) ಪಕ್ಷದ ಸಂಸ್ಥಾಪಕರೆಂದು ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ಅವರ ಜೀವನಕಥೆಯು ಮಕ್ಕಳಿಗೆ ನೀವು ಎಲ್ಲಿಂದ ಬಂದಿದ್ದರೂ, ಕಠಿಣ ಪರಿಶ್ರಮ ಮತ್ತು ಪ್ರಾಮಾಣಿಕತೆಯಿಂದ ಶ್ರೇಷ್ಠತೆಯನ್ನು ಸಾಧಿಸಬಹುದು ಎಂದು ಕಲಿಸುತ್ತದೆ. ಹಾಸನದ ಹೊಲಗಳಿಂದ ಪ್ರಧಾನ ಮಂತ್ರಿಯ ಕಚೇರಿಯವರೆಗೆ, ಅವರು ರೈತ ಸಮುದಾಯದ ಕಲ್ಯಾಣ ಮತ್ತು ಕನ್ನಡ ಭಾಷೆಯ ಪ್ರಚಾರಕ್ಕಾಗಿ ಸಮರ್ಪಿತರಾಗಿದ್ದರು. ಅವರ ಪರಂಪರೆಯು ಹೊಲಗಳಿಗೆ ನೀರುಣಿಸುವ ನೀರಾವರಿ ಕಾಲುವೆಗಳಲ್ಲಿ ಮತ್ತು ಅವರು ಸೇವೆ ಸಲ್ಲಿಸಿದ ಜನರ ಹೃದಯಗಳಲ್ಲಿ ಇಂದಿಗೂ ಜೀವಂತವಾಗಿದೆ. ಅವರು ಕರ್ನಾಟಕದ ನಿಜವಾದ ನಾಯಕ ಮತ್ತು 'ಮಣ್ಣಿನ ಮಗ' ತನ್ನ ತಾಯ್ನಾಡಿನ ಬೇರುಗಳನ್ನು ಮರೆಯದೆ ಆಕಾಶದ ಎತ್ತರಕ್ಕೆ ಬೆಳೆಯಬಲ್ಲ ಎಂಬುದಕ್ಕೆ ಒಂದು ಜೀವಂತ ಸಾಕ್ಷಿಯಾಗಿದ್ದಾರೆ.", "🌟"]
      ],
      quiz: [
        ["What job did he hold in 1996?", "1996ರಲ್ಲಿ ಹುದ್ದೆ?", ["Prime Minister", "President", "Governor"], ["ಪ್ರಧಾನಿ", "ರಾಷ್ಟ್ರಪತಿ", "ರಾಜ್ಯಪಾಲ"], 0],
        ["His family came from…", "ಅವರ ಕುಟುಂಬ?", ["Farmers", "Soldiers", "Traders"], ["ರೈತರು", "ಸೈನಿಕರು", "ವ್ಯಾಪಾರಿ"], 0],
      
        ['Born in which year?', 'ಜನ್ಮ ವರ್ಷ?', ['1933', '1900', '1947'], ['೧೯೩೩', '೧೯೦೦', '೧೯೪೭'], 0],
        ['His birth village?', 'ಗ್ರಾಮ?', ['Haradanahalli', 'Hampi', 'Bidar'], ['ಹರದನಹಳ್ಳಿ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['He studied to become a…', 'ಶಿಕ್ಷಣ?', ['Civil engineer', 'Doctor', 'Lawyer'], ['ಸಿವಿಲ್ ಎಂಜಿನಿಯರ್', 'ವೈದ್ಯ', 'ವಕೀಲ'], 0],
        ['CM of Karnataka in…', 'ಕರ್ನಾಟಕ ಮುಖ್ಯಮಂತ್ರಿ?', ['1994', '1980', '2010'], ['೧೯೯೪', '೧೯೮೦', '೨೦೧೦'], 0],
        ['Which PM number was he?', 'ಎಷ್ಟನೇ ಪ್ರಧಾನಿ?', ['11th', '2nd', '20th'], ['೧೧ನೇ', '೨ನೇ', '೨೦ನೇ'], 0],
        ['His party is…', 'ಪಕ್ಷ?', ['JD(S)', 'BJP', 'Congress'], ['ಜೆಡಿ(ಎಸ್)', 'ಬಿಜೆಪಿ', 'ಕಾಂಗ್ರೆಸ್'], 0],
        ['He is from which district?', 'ಜಿಲ್ಲೆ?', ['Hassan', 'Mysuru', 'Bidar'], ['ಹಾಸನ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ["He is called 'son of…'", 'ಮಗ?', ['Soil', 'Sea', 'Sky'], ['ಮಣ್ಣಿನ', 'ಸಮುದ್ರ', 'ಆಕಾಶ'], 0],
      ],
      memorial: ["Haradanahalli Village", "ಹರದನಹಳ್ಳಿ", "Holenarasipura", "ಹೊಳೆನರಸೀಪುರ", "His birth village, a symbol of rural pride.", "ಗ್ರಾಮೀಣ ಹೆಮ್ಮೆಯ ಸಂಕೇತ.", "Haradanahalli Karnataka"],
    })],
  },
  {
    id: "bengaluru-urban", name: { en: "Bengaluru Urban", kn: "ಬೆಂಗಳೂರು ನಗರ" }, emoji: "🏙️",
    heroes: [mkHero({
      id: "kempegowda", emoji: "🏛️",
      name: ["Kempegowda", "ಕೆಂಪೇಗೌಡ"],
      title: ["Founder of Bengaluru", "ಬೆಂಗಳೂರಿನ ಸ್ಥಾಪಕ"],
      era: "1510 – 1569",
      pages: [
        ["Long ago, in the late medieval period of 1510, a visionary leader named Nadaprabhu Kempegowda was born into a family of brave chieftains. As he grew up under the mighty Vijayanagara Empire, he proved to be a clever and wise ruler who cared deeply for his people. Young Kempegowda observed how towns were built and how water was managed across the kingdom. He dreamt of creating a magnificent city that would be a center for trade, culture, and happiness for everyone. With the guidance of his mentors and the support of the emperors, he prepared himself to build something that would last for many centuries to come.", "ಬಹಳ ಹಿಂದೆಯೇ, 1510 ರ ಕಾಲದಲ್ಲಿ ನಾಡಪ್ರಭು ಕೆಂಪೇಗೌಡ ಎಂಬ ದೂರದೃಷ್ಟಿಯುಳ್ಳ ನಾಯಕನು ಶೂರ ಪಾಳೇಗಾರರ ಕುಟುಂಬದಲ್ಲಿ ಜನಿಸಿದನು. ಪ್ರಬಲ ವಿಜಯನಗರ ಸಾಮ್ರಾಜ್ಯದ ಅಡಿಯಲ್ಲಿ ಬೆಳೆದ ಅವರು, ತನ್ನ ಜನರ ಬಗ್ಗೆ ಅಪಾರ ಕಾಳಜಿ ಹೊಂದಿದ್ದ ಚತುರ ಮತ್ತು ಬುದ್ಧಿವಂತ ಆಡಳಿತಗಾರರಾಗಿದ್ದರು. ಯುವ ಕೆಂಪೇಗೌಡರು ಸಾಮ್ರಾಜ್ಯದಾದ್ಯಂತ ಪಟ್ಟಣಗಳನ್ನು ಹೇಗೆ ನಿರ್ಮಿಸಲಾಗಿದೆ ಮತ್ತು ನೀರನ್ನು ಹೇಗೆ ನಿರ್ವಹಿಸಲಾಗಿದೆ ಎಂಬುದನ್ನು ಗಮನಿಸಿದರು. ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ವ್ಯಾಪಾರ, ಸಂಸ್ಕೃತಿ ಮತ್ತು ಸಂತೋಷದ ಕೇಂದ್ರವಾಗುವ ಭವ್ಯವಾದ ನಗರವನ್ನು ನಿರ್ಮಿಸುವ ಕನಸು ಕಂಡರು. ತಮ್ಮ ಗುರುಗಳ ಮಾರ್ಗದರ್ಶನ ಮತ್ತು ಚಕ್ರವರ್ತಿಗಳ ಬೆಂಬಲದೊಂದಿಗೆ, ಅವರು ಶತಮಾನಗಳ ಕಾಲ ಉಳಿಯುವಂತಹ ನಗರವನ್ನು ನಿರ್ಮಿಸಲು ಸಿದ್ಧರಾದರು.", "🏰"],
        ["In the year 1537, Kempegowda’s dream began to take shape. Legend says that while hunting with his team, he saw a heroic scene where a small hare chased away a fierce dog. He believed this was a place of great courage and chose it as the site for his new city. He marked the area by ploughing four directions with bullocks, establishing the boundary for his grand project. He first built a strong mud fort to protect the residents and laid the foundation for a bustling market area known as the Bengaluru Pete, ensuring that merchants from all over could come and trade their goods.", "1537 ನೇ ಇಸವಿಯಲ್ಲಿ, ಕೆಂಪೇಗೌಡರ ಕನಸು ನನಸಾಗಲು ಪ್ರಾರಂಭಿಸಿತು. ಪುರಾಣಗಳ ಪ್ರಕಾರ, ಅವರು ತಮ್ಮ ತಂಡದೊಂದಿಗೆ ಬೇಟೆಯಾಡುತ್ತಿದ್ದಾಗ, ಸಣ್ಣ ಮೊಲವೊಂದು ಭೀಕರ ನಾಯಿಯನ್ನು ಓಡಿಸುವ ವೀರ ದೃಶ್ಯವನ್ನು ಕಂಡರು. ಇದು ಮಹಾನ್ ಶೌರ್ಯದ ಸ್ಥಳವೆಂದು ನಂಬಿದ ಅವರು, ತಮ್ಮ ಹೊಸ ನಗರಕ್ಕೆ ಇದನ್ನೇ ಸ್ಥಳವಾಗಿ ಆಯ್ದುಕೊಂಡರು. ಅವರು ಎತ್ತುಗಳ ಸಹಾಯದಿಂದ ನಾಲ್ಕು ದಿಕ್ಕುಗಳಲ್ಲಿ ಉಳುಮೆ ಮಾಡುವ ಮೂಲಕ ತಮ್ಮ ಬೃಹತ್ ಯೋಜನೆಗೆ ಗಡಿಯನ್ನು ಗುರುತಿಸಿದರು. ಮೊದಲು ನಿವಾಸಿಗಳನ್ನು ರಕ್ಷಿಸಲು ಬಲವಾದ ಮಣ್ಣಿನ ಕೋಟೆಯನ್ನು ನಿರ್ಮಿಸಿದರು ಮತ್ತು ಬೆಂಗಳೂರು ಪೇಟೆ ಎಂದು ಕರೆಯಲ್ಪಡುವ ಗಿಜಿಗುಟ್ಟುವ ಮಾರುಕಟ್ಟೆ ಪ್ರದೇಶಕ್ಕೆ ಅಡಿಪಾಯ ಹಾಕಿದರು.", "🏇"],
        ["As a visionary urban planner, Kempegowda knew that a growing city needed clear limits and plenty of water to survive. To guide future generations, he built four magnificent watch towers in different directions: at Lalbagh, Mekhri Circle, Ulsoor, and Kempambudhi. These towers marked the boundaries beyond which he predicted the city would one day grow. Understanding that life depends on water, he also created a remarkable network of lakes and tanks, including Kempambudhi, Dharmambudhi, and Sampangi tanks. These water bodies ensured that the citizens always had enough water for farming and daily life, making the city a green and prosperous oasis for all.", "ದೂರದೃಷ್ಟಿಯ ನಗರ ಯೋಜಕರಾಗಿ, ಬೆಳೆಯುತ್ತಿರುವ ನಗರಕ್ಕೆ ಸ್ಪಷ್ಟವಾದ ಗಡಿಗಳು ಮತ್ತು ಬದುಕಲು ಸಾಕಷ್ಟು ನೀರಿನ ಅವಶ್ಯಕತೆ ಇದೆ ಎಂದು ಕೆಂಪೇಗೌಡರಿಗೆ ತಿಳಿದಿತ್ತು. ಮುಂದಿನ ಪೀಳಿಗೆಗೆ ಮಾರ್ಗದರ್ಶನ ನೀಡಲು, ಅವರು ಲಾಲ್‌ಬಾಗ್, ಮೇಖ್ರಿ ಸರ್ಕಲ್, ಹಲಸೂರು ಮತ್ತು ಕೆಂಪಾಂಬುಧಿಯಲ್ಲಿ ನಾಲ್ಕು ಭವ್ಯವಾದ ಕಾವಲು ಗೋಪುರಗಳನ್ನು ನಿರ್ಮಿಸಿದರು. ಈ ಗೋಪುರಗಳು ಭವಿಷ್ಯದಲ್ಲಿ ನಗರವು ಬೆಳೆಯಬಹುದಾದ ಗಡಿಗಳನ್ನು ಗುರುತಿಸಿದವು. ಜೀವನವು ನೀರಿನ ಮೇಲೆ ಅವಲಂಬಿತವಾಗಿದೆ ಎಂಬುದನ್ನು ಅರಿತ ಅವರು ಕೆಂಪಾಂಬುಧಿ, ಧರ್ಮಾಂಬುಧಿ ಮತ್ತು ಸಂಪಂಗಿ ಕೆರೆಗಳು ಸೇರಿದಂತೆ ಅದ್ಭುತವಾದ ಕೆರೆಗಳ ಜಾಲವನ್ನು ನಿರ್ಮಿಸಿದರು. ಈ ಜಲಮೂಲಗಳು ಜನರಿಗೆ ಕೃಷಿ ಮತ್ತು ದೈನಂದಿನ ಜೀವನಕ್ಕೆ ಸಾಕಷ್ಟು ನೀರು ಸಿಗುವಂತೆ ಮಾಡಿದವು.", "🔭"],
        ["Throughout his rule, Kempegowda was respected as a just leader who balanced growth with kindness. He encouraged various professional communities to settle in specific streets of the Pete, which is why even today we find areas named after different trades. His planning was so advanced that it allowed the city to flourish for centuries. He remained a loyal chieftain under the Vijayanagara royalty while focusing his energy on making Bengaluru a model city. His dedication to social welfare and infrastructure made him one of the most beloved figures in Karnataka's history, earning him the title of 'Nadaprabhu' or the Lord of the Land.", "ತಮ್ಮ ಆಡಳಿತದುದ್ದಕ್ಕೂ, ಕೆಂಪೇಗೌಡರು ಅಭಿವೃದ್ಧಿ ಮತ್ತು ದಯೆಯನ್ನು ಸಮತೋಲನಗೊಳಿಸಿದ ನ್ಯಾಯಯುತ ನಾಯಕರಾಗಿ ಗೌರವಿಸಲ್ಪಟ್ಟರು. ಅವರು ವಿವಿಧ ವೃತ್ತಿಪರ ಸಮುದಾಯಗಳನ್ನು ಪೇಟೆಯ ನಿರ್ದಿಷ್ಟ ಬೀದಿಗಳಲ್ಲಿ ನೆಲೆಸಲು ಪ್ರೋತ್ಸಾಹಿಸಿದರು, ಅದಕ್ಕಾಗಿಯೇ ಇಂದು ಕೂಡ ವಿವಿಧ ವ್ಯಾಪಾರಗಳ ಹೆಸರಿನ ಪ್ರದೇಶಗಳನ್ನು ನಾವು ಕಾಣುತ್ತೇವೆ. ಅವರ ಯೋಜನೆಯು ಎಷ್ಟು ಸುಧಾರಿತವಾಗಿತ್ತೆಂದರೆ ಅದು ನಗರವು ಶತಮಾನಗಳ ಕಾಲ ಅಭಿವೃದ್ಧಿ ಹೊಂದಲು ಸಹಾಯ ಮಾಡಿತು. ಅವರು ಬೆಂಗಳೂರನ್ನು ಮಾದರಿ ನಗರವನ್ನಾಗಿ ಮಾಡುವತ್ತ ಗಮನ ಹರಿಸುತ್ತಲೇ ವಿಜಯನಗರದ ಅರಸರಿಗೆ ನಿಷ್ಠಾವಂತ ಪಾಳೇಗಾರರಾಗಿ ಉಳಿದಿದ್ದರು. ಸಮಾಜ ಕಲ್ಯಾಣ ಮತ್ತು ಮೂಲಸೌಕರ್ಯಗಳಿಗೆ ಅವರ ಸಮರ್ಪಣೆಯು ಅವರನ್ನು ಕರ್ನಾಟಕದ ಇತಿಹಾಸದಲ್ಲಿ ಅತ್ಯಂತ ಪ್ರೀತಿಯ ವ್ಯಕ್ತಿಗಳಲ್ಲಿ ಒಬ್ಬರನ್ನಾಗಿ ಮಾಡಿತು.", "🏛️"],
        ["Today, the small mud fort town has grown into a world-famous city, but we never forget the man who started it all. To honor his incredible legacy, the massive Bengaluru international airport and the city’s metro system are proudly named after Kempegowda. Travelers from around the globe are greeted by the magnificent 108-foot tall 'Statue of Prosperity' at the airport, showing him holding his sword and looking over the land he loved. Children in Bengaluru Urban and across Karnataka study his life to learn about courage, smart planning, and leadership. Nadaprabhu Kempegowda’s vision continues to live on in every bustling street and peaceful park of the city.", "ಇಂದು, ಅಂದಿನ ಸಣ್ಣ ಮಣ್ಣಿನ ಕೋಟೆಯ ಪಟ್ಟಣವು ವಿಶ್ವ ಪ್ರಸಿದ್ಧ ನಗರವಾಗಿ ಬೆಳೆದಿದೆ, ಆದರೆ ಈ ಎಲ್ಲವನ್ನೂ ಪ್ರಾರಂಭಿಸಿದ ವ್ಯಕ್ತಿಯನ್ನು ನಾವು ಎಂದಿಗೂ ಮರೆಯುವುದಿಲ್ಲ. ಅವರ ಅದ್ಭುತ ಪರಂಪರೆಯನ್ನು ಗೌರವಿಸಲು, ಬೃಹತ್ ಬೆಂಗಳೂರು ಅಂತರಾಷ್ಟ್ರೀಯ ವಿಮಾನ ನಿಲ್ದಾಣ ಮತ್ತು ನಗರದ ಮೆಟ್ರೋ ವ್ಯವಸ್ಥೆಗೆ ಕೆಂಪೇಗೌಡರ ಹೆಸರನ್ನು ಹೆಮ್ಮೆಯಿಂದ ಇಡಲಾಗಿದೆ. ವಿಮಾನ ನಿಲ್ದಾಣದಲ್ಲಿ 108 ಅಡಿ ಎತ್ತರದ ಭವ್ಯವಾದ 'ಪ್ರಗತಿಯ ಪ್ರತಿಮೆ'ಯು ಪ್ರಪಂಚದಾದ್ಯಂತದ ಪ್ರಯಾಣಿಕರನ್ನು ಸ್ವಾಗತಿಸುತ್ತದೆ. ಬೆಂಗಳೂರು ನಗರ ಮತ್ತು ಕರ್ನಾಟಕದಾದ್ಯಂತದ ಮಕ್ಕಳು ಧೈರ್ಯ, ಉತ್ತಮ ಯೋಜನೆ ಮತ್ತು ನಾಯಕತ್ವದ ಬಗ್ಗೆ ತಿಳಿಯಲು ಅವರ ಜೀವನವನ್ನು ಅಧ್ಯಯನ ಮಾಡುತ್ತಾರೆ. ನಾಡಪ್ರಭು ಕೆಂಪೇಗೌಡರ ದೃಷ್ಟಿಕೋನವು ನಗರದ ಪ್ರತಿಯೊಂದು ಬೀದಿ ಮತ್ತು ಉದ್ಯಾನವನಗಳಲ್ಲಿ ಇಂದಿಗೂ ಜೀವಂತವಾಗಿದೆ.", "✈️"]
      ],
      quiz: [
        ["Which city did he found?", "ಯಾವ ನಗರ?", ["Bengaluru", "Mysuru", "Hubballi"], ["ಬೆಂಗಳೂರು", "ಮೈಸೂರು", "ಹುಬ್ಬಳ್ಳಿ"], 0],
        ["He built four…", "ನಾಲ್ಕು ಏನು?", ["Watch towers", "Palaces", "Bridges"], ["ಗೋಪುರಗಳು", "ಅರಮನೆ", "ಸೇತುವೆ"], 0],
      
        ['Born in which year?', 'ಜನ್ಮ ವರ್ಷ?', ['1510', '1700', '1900'], ['೧೫೧೦', '೧೭೦೦', '೧೯೦೦'], 0],
        ['Bengaluru founded in…', 'ಬೆಂಗಳೂರು ಸ್ಥಾಪನೆ?', ['1537', '1700', '1900'], ['೧೫೩೭', '೧೭೦೦', '೧೯೦೦'], 0],
        ['He served which empire?', 'ಯಾವ ಸಾಮ್ರಾಜ್ಯ?', ['Vijayanagara', 'Mughal', 'British'], ['ವಿಜಯನಗರ', 'ಮೊಘಲ್', 'ಬ್ರಿಟಿಷ್'], 0],
        ["Title 'Nadaprabhu' means…", 'ನಾಡಪ್ರಭು?', ['Lord of land', 'Soldier', 'Poet'], ['ನಾಡಿನ ಒಡೆಯ', 'ಸೈನಿಕ', 'ಕವಿ'], 0],
        ['He marked city using…', 'ಗಡಿ ಗುರುತು?', ['Bullocks ploughing', 'Soldiers', 'Stones'], ['ಎತ್ತುಗಳ ನೇಗಿಲು', 'ಸೈನಿಕ', 'ಕಲ್ಲು'], 0],
        ["Bengaluru's old market is called…", 'ಹಳೆಯ ಮಾರುಕಟ್ಟೆ?', ['Pete', 'Mall', 'Chowk'], ['ಪೇಟೆ', 'ಮಾಲ್', 'ಚೌಕ'], 0],
        ['First fort was built of…', 'ಮೊದಲ ಕೋಟೆ?', ['Mud', 'Steel', 'Glass'], ['ಮಣ್ಣು', 'ಉಕ್ಕು', 'ಗಾಜು'], 0],
        ['Bengaluru airport is named after…', 'ವಿಮಾನ ನಿಲ್ದಾಣ?', ['Kempegowda', 'Tipu', 'Kuvempu'], ['ಕೆಂಪೇಗೌಡ', 'ಟಿಪ್ಪು', 'ಕುವೆಂಪು'], 0],
      ],
      memorial: ["Kempegowda Statue", "ಕೆಂಪೇಗೌಡ ಪ್ರತಿಮೆ", "KIA Airport, Bengaluru", "ಕೆಂಪೇಗೌಡ ವಿಮಾನ ನಿಲ್ದಾಣ", "A 108-foot statue greets visitors near the airport.", "108 ಅಡಿ ಎತ್ತರದ ಪ್ರತಿಮೆ.", "Statue of Prosperity Kempegowda Bengaluru"],
    })],
  },
  {
    id: "bidar", name: { en: "Bidar", kn: "ಬೀದರ್" }, emoji: "🕌",
    heroes: [mkHero({
      id: "mahmud-gawan", emoji: "📚",
      name: ["Mahmud Gawan", "ಮಹಮ್ಮದ್ ಗವಾನ್"],
      title: ["Scholar-Minister of Bidar", "ಬೀದರಿನ ವಿದ್ವಾಂಸ ಮಂತ್ರಿ"],
      era: "1411 – 1481",
      pages: [
        ["Long ago, in the year 1411, a curious boy named Mahmud Gawan was born in Persia. He was not a prince, but he had a mind as sharp as a diamond. Young Mahmud loved two things dearly: traveling across the vast seas and reading every book he could find. As a merchant and a scholar, he traveled from distant lands to the beautiful region of Karnataka. He eventually arrived in Bidar, a city of red soil and golden sunshine. The Bahmani Sultan was so impressed by Mahmud’s wisdom and honesty that he invited him to stay. Mahmud decided to make this land his home, bringing with him dreams of transforming the kingdom into a center of learning and peace for everyone.", "ಬಹಳ ಹಿಂದೆಯೇ, 1411 ರಲ್ಲಿ, ಪರ್ಷಿಯಾದಲ್ಲಿ ಮಹಮೂದ್ ಗವಾನ್ ಎಂಬ ಕುತೂಹಲಕಾರಿ ಹುಡುಗ ಜನಿಸಿದನು. ಅವನು ರಾಜಕುಮಾರನಲ್ಲದಿದ್ದರೂ, ವಜ್ರದಂತಹ ಚುರುಕಾದ ಬುದ್ಧಿವಂತಿಕೆಯನ್ನು ಹೊಂದಿದ್ದನು. ಯುವ ಮಹಮೂದ್ ಎರಡು ವಿಷಯಗಳನ್ನು ಪ್ರೀತಿಸುತ್ತಿದ್ದನು: ವಿಶಾಲವಾದ ಸಮುದ್ರಗಳಲ್ಲಿ ಪ್ರಯಾಣಿಸುವುದು ಮತ್ತು ಸಿಕ್ಕ ಪ್ರತಿಯೊಂದು ಪುಸ್ತಕವನ್ನೂ ಓದುವುದು. ವ್ಯಾಪಾರಿಯಾಗಿ ಮತ್ತು ವಿದ್ವಾಂಸನಾಗಿ, ಅವನು ದೂರದ ದೇಶಗಳಿಂದ ಕರ್ನಾಟಕದ ಸುಂದರ ಪ್ರದೇಶಕ್ಕೆ ಬಂದನು. ಕೊನೆಗೆ ಕೆಂಪು ಮಣ್ಣಿನ ಮತ್ತು ಬಂಗಾರದ ಬಿಸಿಲಿನ ಬೀದರ್ ನಗರಕ್ಕೆ ಬಂದನು. ಬಹಮನಿ ಸುಲ್ತಾನನು ಮಹಮೂದ್‌ನ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ಪ್ರಾಮಾಣಿಕತೆಯನ್ನು ಕಂಡು ಪ್ರಭಾವಿತನಾಗಿ ಅವನನ್ನು ರಾಜ್ಯದಲ್ಲಿ ಉಳಿಯಲು ಆಹ್ವಾನಿಸಿದನು. ಮಹಮೂದ್ ಈ ಭೂಮಿಯನ್ನು ತನ್ನ ಮನೆಯನ್ನಾಗಿ ಮಾಡಿಕೊಳ್ಳಲು ನಿರ್ಧರಿಸಿದನು.", "⛵"],
        ["Because of his great talent, Mahmud Gawan rose to become the Wazir, or Prime Minister, of the Bahmani Sultanate under Muhammad Shah III. He was a very fair leader who wanted to help the common people. Before his time, the kingdom was unorganized and difficult to manage. Mahmud worked tirelessly to change this. He reformed the administration by dividing the large kingdom into smaller provinces. This allowed the government to listen more closely to the needs of the villagers. He introduced better ways to collect taxes and ensured that local officers were honest. The people of Bidar began to flourish under his careful guidance, seeing him as a protector who cared about justice and hard work.", "ಅವನ ಅಪಾರ ಪ್ರತಿಭೆಯಿಂದಾಗಿ, ಮಹಮೂದ್ ಗವಾನ್ ಮೊಹಮ್ಮದ್ ಶಾ III ರ ಅಡಿಯಲ್ಲಿ ಬಹಮನಿ ಸುಲ್ತಾನರ ಮಂತ್ರಿಯಾದನು. ಸಾಮಾನ್ಯ ಜನರಿಗೆ ಸಹಾಯ ಮಾಡಲು ಬಯಸುವ ಅತ್ಯಂತ ನಿಷ್ಠಾವಂತ ನಾಯಕನಾಗಿದ್ದನು. ಅವನ ಕಾಲಕ್ಕಿಂತ ಮೊದಲು, ರಾಜ್ಯವು ಅಸ್ತವ್ಯಸ್ತವಾಗಿತ್ತು ಮತ್ತು ನಿರ್ವಹಿಸುವುದು ಕಷ್ಟಕರವಾಗಿತ್ತು. ಮಹಮೂದ್ ಇದನ್ನು ಬದಲಾಯಿಸಲು ದಣಿವರಿಯಿಲ್ಲದೆ ಶ್ರಮಿಸಿದನು. ಅವನು ದೊಡ್ಡ ರಾಜ್ಯವನ್ನು ಸಣ್ಣ ಪ್ರಾಂತ್ಯಗಳಾಗಿ ವಿಂಗಡಿಸುವ ಮೂಲಕ ಆಡಳಿತವನ್ನು ಸುಧಾರಿಸಿದನು. ಇದು ಸರ್ಕಾರಕ್ಕೆ ಹಳ್ಳಿಗರ ಅಗತ್ಯಗಳನ್ನು ಹತ್ತಿರದಿಂದ ಕೇಳಲು ಅವಕಾಶ ಮಾಡಿಕೊಟ್ಟಿತು. ಅವನು ತೆರಿಗೆ ಸಂಗ್ರಹಿಸಲು ಉತ್ತಮ ಮಾರ್ಗಗಳನ್ನು ಪರಿಚಯಿಸಿದನು ಮತ್ತು ಅಧಿಕಾರಿಗಳು ಪ್ರಾಮಾಣಿಕವಾಗಿರುವಂತೆ ನೋಡಿಕೊಂಡನು. ಅವನ ಮಾರ್ಗದರ್ಶನದಲ್ಲಿ ಬೀದರ್ ಜನರು ಅಭಿವೃದ್ಧಿ ಹೊಂದತೊಡಗಿದರು.", "📜"],
        ["Mahmud Gawan’s greatest dream was to build a magnificent home for knowledge. In 1472, he used his own money to build the famous Mahmud Gawan Madrasa in Bidar. This was not just a simple building; it was a grand three-storey college decorated with beautiful colored tiles and tall minarets. Inside, he established a massive library that held thousands of handwritten books from all over the world. Scholars and students traveled from far away to study mathematics, science, and history here. Mahmud believed that education was a lamp that could light up the entire world. He spent his evenings among the bookshelves, encouraging young minds to ask questions and learn about the wonders of the universe.", "ಮಹಮೂದ್ ಗವಾನನ ದೊಡ್ಡ ಕನಸೆಂದರೆ ಜ್ಞಾನಕ್ಕಾಗಿ ಒಂದು ಭವ್ಯವಾದ ಮನೆಯನ್ನು ನಿರ್ಮಿಸುವುದು. 1472 ರಲ್ಲಿ, ಅವನು ತನ್ನ ಸ್ವಂತ ಹಣವನ್ನು ಬಳಸಿ ಬೀದರ್‌ನಲ್ಲಿ ಪ್ರಸಿದ್ಧ ಮಹಮೂದ್ ಗವಾನ್ ಮದರಸಾವನ್ನು ನಿರ್ಮಿಸಿದನು. ಇದು ಕೇವಲ ಒಂದು ಕಟ್ಟಡವಾಗಿರಲಿಲ್ಲ; ಸುಂದರವಾದ ಬಣ್ಣದ ಟೈಲ್ಸ್‌ಗಳು ಮತ್ತು ಎತ್ತರದ ಮಿನಾರ್‌ಗಳಿಂದ ಅಲಂಕರಿಸಲ್ಪಟ್ಟ ಭವ್ಯವಾದ ಮೂರು ಅಂತಸ್ತಿನ ಕಾಲೇಜು ಇದಾಗಿತ್ತು. ಅದರ ಒಳಗೆ, ಅವನು ಪ್ರಪಂಚದಾದ್ಯಂತದ ಸಾವಿರಾರು ಹಸ್ತಪ್ರತಿಗಳನ್ನು ಹೊಂದಿರುವ ಬೃಹತ್ ಗ್ರಂಥಾಲಯವನ್ನು ಸ್ಥಾಪಿಸಿದನು. ಇಲ್ಲಿ ಗಣಿತ, ವಿಜ್ಞಾನ ಮತ್ತು ಇತಿಹಾಸವನ್ನು ಕಲಿಯಲು ವಿದ್ವಾಂಸರು ಮತ್ತು ವಿದ್ಯಾರ್ಥಿಗಳು ದೂರದ ಊರುಗಳಿಂದ ಬರುತ್ತಿದ್ದರು. ಶಿಕ್ಷಣವು ಇಡೀ ಜಗತ್ತನ್ನು ಬೆಳಗಿಸುವ ದೀಪ ಎಂದು ಮಹಮೂದ್ ನಂಬಿದ್ದನು.", "🏛️"],
        ["Even though Mahmud Gawan was kind and wise, some jealous nobles in the court did not like his success. They were unhappy because he was a foreigner who had gained so much power through his goodness and intelligence. These rivals told lies to the Sultan, making him believe that his loyal minister was planning a betrayal. Sadly, the Sultan believed the false stories and ordered Mahmud’s execution in 1481. Despite such a tragic ending, Mahmud Gawan remained brave and peaceful until his final moments. He had spent his life serving a kingdom that was not his birthplace, showing that true loyalty and love for a land come from the heart, not just from where you are born.", "ಮಹಮೂದ್ ಗವಾನ್ ದಯಾಳು ಮತ್ತು ಬುದ್ಧಿವಂತನಾಗಿದ್ದರೂ, ಆಸ್ಥಾನದಲ್ಲಿದ್ದ ಕೆಲವು ಅಸೂಯೆ ಪಟ್ಟ ನಾಯಕರಿಗೆ ಅವನ ಯಶಸ್ಸು ಇಷ್ಟವಾಗಲಿಲ್ಲ. ಅವನು ವಿದೇಶಿಯನಾಗಿದ್ದರೂ ತನ್ನ ಬುದ್ಧಿವಂತಿಕೆಯಿಂದ ಇಷ್ಟು ಅಧಿಕಾರ ಪಡೆದಿದ್ದು ಅವರಿಗೆ ಬೇಸರ ತಂದಿತ್ತು. ಈ ಪ್ರತಿಸ್ಪರ್ಧಿಗಳು ಸುಲ್ತಾನನಿಗೆ ಸುಳ್ಳುಗಳನ್ನು ಹೇಳಿದರು. ದುರದೃಷ್ಟವಶಾತ್, ಸುಲ್ತಾನನು ಆ ಸುಳ್ಳು ಕಥೆಗಳನ್ನು ನಂಬಿ 1481 ರಲ್ಲಿ ಮಹಮೂದ್‌ನನ್ನು ಮರಣದಂಡನೆಗೆ ಆದೇಶಿಸಿದನು. ಅಂತಹ ದುರಂತದ ಅಂತ್ಯದ ಹೊರತಾಗಿಯೂ, ಮಹಮೂದ್ ಗವಾನ್ ತನ್ನ ಕೊನೆಯ ಕ್ಷಣದವರೆಗೂ ಧೈರ್ಯಶಾಲಿಯಾಗಿದ್ದನು. ಅವನು ಹುಟ್ಟಿದ ದೇಶವಲ್ಲದಿದ್ದರೂ ಆ ರಾಜ್ಯಕ್ಕಾಗಿ ತನ್ನ ಜೀವನವನ್ನು ಮುಡುಪಾಗಿಟ್ಟನು, ನಿಜವಾದ ನಿಷ್ಠೆಯು ಹೃದಯದಿಂದ ಬರುತ್ತದೆ ಎಂದು ಅವನು ತೋರಿಸಿಕೊಟ್ಟನು.", "⚔️"],
        ["Today, if you visit the city of Bidar in Karnataka, you can still see the towering ruins of the Mahmud Gawan Madrasa standing proudly against the blue sky. Even after hundreds of years, the remains of the colorful tiles remind us of the beauty he created. Mahmud Gawan is remembered as one of India's greatest ministers and a champion of learning. He taught us that a leader's true strength lies in books, justice, and building schools rather than just winning wars. Children in Karnataka still look up to his legacy, inspired by the scholar who arrived as a traveler and left behind a monument of wisdom that continues to tell its story to every visitor.", "ಇಂದು, ನೀವು ಕರ್ನಾಟಕದ ಬೀದರ್ ನಗರಕ್ಕೆ ಭೇಟಿ ನೀಡಿದರೆ, ಮಹಮೂದ್ ಗವಾನ್ ಮದರಸಾದ ಭವ್ಯ ಅವಶೇಷಗಳನ್ನು ನೋಡಬಹುದು. ನೂರಾರು ವರ್ಷಗಳ ನಂತರವೂ, ಅಲ್ಲಿನ ಬಣ್ಣಬಣ್ಣದ ಕಲ್ಲುಗಳು ಅವನು ಸೃಷ್ಟಿಸಿದ ಸೌಂದರ್ಯವನ್ನು ನಮಗೆ ನೆನಪಿಸುತ್ತವೆ. ಮಹಮೂದ್ ಗವಾನನನ್ನು ಭಾರತದ ಶ್ರೇಷ್ಠ ಮಂತ್ರಿಗಳಲ್ಲಿ ಒಬ್ಬನೆಂದು ಮತ್ತು ಶಿಕ್ಷಣದ ಹರಿಕಾರನೆಂದು ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ನಾಯಕನ ನಿಜವಾದ ಶಕ್ತಿ ಕೇವಲ ಯುದ್ಧಗಳನ್ನು ಗೆಲ್ಲುವುದರಲ್ಲಿಲ್ಲ, ಆದರೆ ಪುಸ್ತಕಗಳಲ್ಲಿ, ನ್ಯಾಯದಲ್ಲಿ ಮತ್ತು ಶಾಲೆಗಳನ್ನು ನಿರ್ಮಿಸುವಲ್ಲಿ ಅಡಗಿದೆ ಎಂದು ಅವನು ನಮಗೆ ಕಲಿಸಿದನು. ಒಬ್ಬ ಪ್ರವಾಸಿಯಾಗಿ ಬಂದು ಜ್ಞಾನದ ಸ್ಮಾರಕವನ್ನು ಬಿಟ್ಟುಹೋದ ಈ ವಿದ್ವಾಂಸನ ಕಥೆಯು ಇಂದಿಗೂ ಪ್ರೇರಣೆಯಾಗಿದೆ.", "🌟"]
      ],
      quiz: [
        ["Which kingdom did he serve?", "ಯಾವ ರಾಜ್ಯ?", ["Bahmani", "Chola", "Maratha"], ["ಬಹಮನಿ", "ಚೋಳ", "ಮರಾಠ"], 0],
        ["He built a famous…", "ಏನು ಕಟ್ಟಿದನು?", ["Madrasa", "Fort", "Bridge"], ["ಮದ್ರಸಾ", "ಕೋಟೆ", "ಸೇತುವೆ"], 0],
      
        ['Born in which country?', 'ಜನ್ಮ ದೇಶ?', ['Persia', 'India', 'China'], ['ಪರ್ಷಿಯಾ', 'ಭಾರತ', 'ಚೀನಾ'], 0],
        ['He served which sultanate?', 'ಯಾವ ಸುಲ್ತಾನತೆ?', ['Bahmani', 'Mughal', 'Maratha'], ['ಬಹಮನಿ', 'ಮೊಘಲ್', 'ಮರಾಠ'], 0],
        ['Built famous madrasa at…', 'ಮದ್ರಸಾ ಎಲ್ಲಿ?', ['Bidar', 'Hampi', 'Bengaluru'], ['ಬೀದರ್', 'ಹಂಪಿ', 'ಬೆಂಗಳೂರು'], 0],
        ['Madrasa built in year…', 'ಯಾವ ವರ್ಷ?', ['1472', '1300', '1800'], ['೧೪೭೨', '೧೩೦೦', '೧೮೦೦'], 0],
        ['His role at court?', 'ಹುದ್ದೆ?', ['Wazir/PM', 'King', 'Soldier'], ['ವಜೀರ್', 'ರಾಜ', 'ಸೈನಿಕ'], 0],
        ['Sultan he served?', 'ಯಾರ ಆಸ್ಥಾನ?', ['Muhammad Shah III', 'Akbar', 'Tipu'], ['ಮುಹಮ್ಮದ್ ಶಾ III', 'ಅಕ್ಬರ್', 'ಟಿಪ್ಪು'], 0],
        ['Madrasa was a centre of…', 'ಯಾವುದರ ಕೇಂದ್ರ?', ['Knowledge', 'Trade', 'War'], ['ಜ್ಞಾನ', 'ವ್ಯಾಪಾರ', 'ಯುದ್ಧ'], 0],
        ['Born in year…', 'ಜನ್ಮ ವರ್ಷ?', ['1411', '1700', '1900'], ['೧೪೧೧', '೧೭೦೦', '೧೯೦೦'], 0],
      ],
      memorial: ["Mahmud Gawan Madrasa", "ಮಹಮ್ಮದ್ ಗವಾನ್ ಮದ್ರಸಾ", "Bidar town", "ಬೀದರ್", "A magnificent 15th-century learning centre.", "15ನೇ ಶತಮಾನದ ಜ್ಞಾನ ಕೇಂದ್ರ.", "Mahmud Gawan Madrasa Bidar"],
    })],
  },
  {
    id: "chamarajanagar", name: { en: "Chamarajanagar", kn: "ಚಾಮರಾಜನಗರ" }, emoji: "🐘",
    heroes: [mkHero({
      id: "mahadeshwara", emoji: "🛕",
      name: ["Sri Male Mahadeshwara", "ಶ್ರೀ ಮಲೆ ಮಹದೇಶ್ವರ"],
      title: ["The Hill Saint", "ಬೆಟ್ಟದ ಸಂತ"],
      era: "15th Century",
      pages: [
        ["In the 15th century, a divine and radiant child was born who would one day become the Savior of the Hills. This boy was Mahadeshwara, a natural mystic who showed a deep connection to Lord Shiva from a very young age. Unlike other children who played with toys, Mahadeshwara was drawn to the mysteries of nature and the silence of the soul. He decided to leave his home and travel across the land as a wandering monk. Carrying the message of peace and devotion, he walked through villages and valleys, his heart filled with a desire to help the suffering. Even as a young seeker, people noticed a special light in his eyes, feeling that he was no ordinary traveler but a soul sent to guide them toward harmony and kindness.", "೧೫ನೇ ಶತಮಾನದಲ್ಲಿ, ಬೆಟ್ಟಗಳ ಸಂರಕ್ಷಕನಾಗಲಿರುವ ದಿವ್ಯ ಮಗುವೊಂದು ಜನಿಸಿತು. ಈತನೇ ಮಹದೇಶ್ವರ. ಬಾಲ್ಯದಿಂದಲೇ ಶಿವನ ಮೇಲೆ ಅಪಾರ ಭಕ್ತಿ ಹೊಂದಿದ್ದ ಈತ ಒಬ್ಬ ಸ್ವಾಭಾವಿಕ ರಹಸ್ಯವಾದಿಯಾಗಿದ್ದನು. ಇತರ ಮಕ್ಕಳು ಆಟಿಕೆಗಳೊಂದಿಗೆ ಆಡುತ್ತಿದ್ದರೆ, ಮಹದೇಶ್ವರನು ಪ್ರಕೃತಿಯ ರಹಸ್ಯಗಳು ಮತ್ತು ಆತ್ಮದ ಮೌನಕ್ಕೆ ಆಕರ್ಷಿತನಾಗಿದ್ದನು. ಅವನು ತನ್ನ ಮನೆಯನ್ನು ತೊರೆದು ಸಂಚಾರಿ ಕವಿಯಾಗಿ ನಾಡಿನಾದ್ಯಂತ ಸಂಚರಿಸಲು ನಿರ್ಧರಿಸಿದನು. ಶಾಂತಿ ಮತ್ತು ಭಕ್ತಿಯ ಸಂದೇಶವನ್ನು ಹೊತ್ತು, ಗ್ರಾಮಗಳು ಮತ್ತು ಕಣಿವೆಗಳ ಮೂಲಕ ಸಾಗಿದನು. ಇವನು ಸಾಮಾನ್ಯ ಪ್ರವಾಸಿಯಲ್ಲ, ಬದಲಾಗಿ ಜನರನ್ನು ಸೌಹಾರ್ದತೆ ಮತ್ತು ದಯೆಯತ್ತ ನಡೆಸಲು ಬಂದ ದಿವ್ಯ ಚೇತನ ಎಂದು ಜನರು ಅರಿತರು.", "✨"],
        ["Mahadeshwara’s journey eventually led him to the dense and mysterious forests of the Chamarajanagar district. These vast green hills, now known as Male Mahadeshwara Hills, became his sacred home. The area was wild and filled with dangerous animals, yet Mahadeshwara felt perfectly at peace. He moved through the thick woods without any fear, seeking a places to meditate and connect with the divine. The local tribal communities, who lived tucked away in the forest, were initially curious and cautious of this young saint. However, they soon saw his gentle nature and realized he had come to protect the land. He spent his time learning the secrets of the hills, preparing himself for a life dedicated to the welfare of the forest dwellers and all living creatures.", "ಮಹದೇಶ್ವರನ ಪ್ರಯಾಣವು ಅಂತಿಮವಾಗಿ ಚಾಮರಾಜನಗರ ಜಿಲ್ಲೆಯ ದಟ್ಟವಾದ ಮತ್ತು ನಿಗೂಢ ಕಾಡುಗಳಿಗೆ ಕರೆತಂದಿತು. ಈಗ ಮಲೆ ಮಹದೇಶ್ವರ ಬೆಟ್ಟಗಳೆಂದು ಕರೆಯಲ್ಪಡುವ ಈ ವಿಶಾಲವಾದ ಹಸಿರು ಬೆಟ್ಟಗಳು ಅವನ ಪವಿತ್ರ ಮನೆಯಾದವು. ಕಾಡು ಪ್ರಾಣಿಗಳಿಂದ ಕೂಡಿದ್ದ ಈ ಭಯಾನಕ ಪ್ರದೇಶದಲ್ಲಿ ಮಹದೇಶ್ವರನು ಸಂಪೂರ್ಣ ಶಾಂತಿಯನ್ನು ಅನುಭವಿಸಿದನು. ಅವನು ಯಾವುದೇ ಭಯವಿಲ್ಲದೆ ದಟ್ಟಾರಣ್ಯಗಳಲ್ಲಿ ಸಂಚರಿಸುತ್ತಾ, ಧ್ಯಾನಕ್ಕಾಗಿ ಸ್ಥಳಗಳನ್ನು ಹುಡುಕಿದನು. ಹಳೆಯ ಬುಡಕಟ್ಟು ಸಮುದಾಯಗಳು ಈ ಯುವ ಸನ್ಯಾಸಿಯನ್ನು ಕಂಡು ಮೊದಲು ಕುತೂಹಲ ಮತ್ತು ಎಚ್ಚರಿಕೆಯಿಂದಿದ್ದವು. ಆದರೆ, ಶೀಘ್ರದಲ್ಲೇ ಅವರು ಅವನ ಸೌಮ್ಯ ಸ್ವಭಾವವನ್ನು ಕಂಡು ಅವನು ಭೂಮಿಯನ್ನು ರಕ್ಷಿಸಲು ಬಂದಿದ್ದಾನೆ ಎಂದು ಅರಿತುಕೊಂಡರು. ಅವನು ಬೆಟ್ಟಗಳ ರಹಸ್ಯಗಳನ್ನು ಕಲಿಯುತ್ತಾ ತನ್ನ ಜೀವನವನ್ನು ಕಾಡಿನ ನಿವಾಸಿಗಳ ಒಳಿತಿಗಾಗಿ ಮುಡಿಪಾಗಿಟ್ಟನು.", "🌲"],
        ["As a Shaiva mystic, Mahadeshwara began performing incredible miracles that amazed everyone who saw them. One of the most famous stories tells of how he tamed a fierce, wild tiger using only his spiritual power. Instead of being afraid, he treated the beast with kindness, and soon, the tiger became his loyal companion. To the wonder of the forest people, Mahadeshwara would often ride the tiger through the mountains as though it were a gentle horse. He also used his powers to defeat wicked demons who haunted the hills and harmed the innocent. Beyond fighting monsters, he was a great healer. He used herbs and prayers to cure the illnesses of the tribal folk, earning their eternal love and respect as their divine protector and teacher.", "ಶೈವ ರಹಸ್ಯವಾದಿಯಾಗಿ, ಮಹದೇಶ್ವರನು ನಂಬಲಾಗದ ಪವಾಡಗಳನ್ನು ಮಾಡಲು ಪ್ರಾರಂಭಿಸಿದನು. ಅತ್ಯಂತ ಪ್ರಸಿದ್ಧವಾದ ಕಥೆಯೆಂದರೆ, ಅವನು ಕೇವಲ ತನ್ನ ಆಧ್ಯಾತ್ಮಿಕ ಶಕ್ತಿಯಿಂದ ಕ್ರೂರ ಹುಲಿಯನ್ನು ಪಳಗಿಸಿದನು. ಭಯಪಡುವ ಬದಲು, ಅವನು ಆ ಪ್ರಾಣಿಯನ್ನು ದಯೆಯಿಂದ ನಡೆಸಿಕೊಂಡನು ಮತ್ತು ಶೀಘ್ರದಲ್ಲೇ ಆ ಹುಲಿ ಅವನ ನಿಷ್ಠಾವಂತ ವಾಹನವಾಯಿತು. ಕಾಡಿನ ಜನರು ಬೆರಗಾಗುವಂತೆ, ಮಹದೇಶ್ವರನು ಹುಲಿಯ ಮೇಲೆ ಕುಳಿತು ಬೆಟ್ಟಗಳಲ್ಲಿ ಸಂಚರಿಸುತ್ತಿದ್ದನು. ಬೆಟ್ಟಗಳಲ್ಲಿ ವಾಸಿಸುತ್ತಾ ಮುಗ್ಧರಿಗೆ ತೊಂದರೆ ಕೊಡುತ್ತಿದ್ದ ದುಷ್ಟ ರಾಕ್ಷಸರನ್ನು ಅವನು ಸೋಲಿಸಿದನು. ಕೇವಲ ರಾಕ್ಷಸರನ್ನಷ್ಟೇ ಅಲ್ಲದೆ, ಅವನು ಬುಡಕಟ್ಟು ಜನರ ರೋಗಗಳನ್ನು ಗಿಡಮೂಲಿಕೆಗಳು ಮತ್ತು ಪ್ರಾರ್ಥನೆಗಳ ಮೂಲಕ ಗುಣಪಡಿಸಿದನು, ಆ ಮೂಲಕ ಅವರ ಪ್ರೀತಿ ಮತ್ತು ಗೌರವವನ್ನು ಸಂಪಾದಿಸಿದನು.", "🐅"],
        ["The legacy of Mahadeshwara is kept alive today through the vibrant tradition of the 'Male Mahadeshwara Kavya'. This is a long and beautiful oral epic that tells the story of his life, his miracles, and his teachings. The performers of this epic are known as Kamsale folk artists, named after the bronze rhythmic instruments they clash together while singing. They dance with great energy, their songs echoing through the hills and villages. These artists travel from place to place, ensuring that the stories of the saint’s bravery and kindness are never forgotten by the children of Karnataka. Through their rhythmic music and powerful storytelling, Mahadeshwara remains a hero who lives not just in history books, but in the hearts and voices of the people who worship him.", "ಮಹದೇಶ್ವರನ ಪರಂಪರೆಯು ಇಂದು 'ಮಲೆ ಮಹದೇಶ್ವರ ಕಾವ್ಯ' ಎಂಬ ರೋಮಾಂಚಕ ಜಾನಪದ ಸಂಪ್ರದಾಯದ ಮೂಲಕ ಜೀವಂತವಾಗಿದೆ. ಇದು ಅವನ ಜೀವನ, ಪವಾಡಗಳು ಮತ್ತು ಬೋಧನೆಗಳನ್ನು ವಿವರಿಸುವ ಸುದೀರ್ಘ ಮೌಖಿಕ ಮಹಾಕಾವ್ಯವಾಗಿದೆ. ಈ ಕಾವ್ಯವನ್ನು ಹಾಡುವವರನ್ನು 'ಕಂಸಾಳೆ' ಕಲಾವಿದರು ಎಂದು ಕರೆಯುತ್ತಾರೆ. ಅವರು ಹಾಡುವಾಗ ಕಂಚಿನ ತಾಳಗಳನ್ನು ಬಡಿಯುತ್ತಾ ಲಯಬದ್ಧವಾಗಿ ನೃತ್ಯ ಮಾಡುತ್ತಾರೆ. ಈ ಕಲಾವಿದರು ಊರೂರು ಸುತ್ತುತ್ತಾ, ಮಹದೇಶ್ವರನ ಶೌರ್ಯ ಮತ್ತು ದಯೆಯ ಕಥೆಗಳನ್ನು ಕರ್ನಾಟಕದ ಮಕ್ಕಳು ಎಂದಿಗೂ ಮರೆಯದಂತೆ ನೋಡಿಕೊಳ್ಳುತ್ತಾರೆ. ಅವರ ಲಯಬದ್ಧ ಸಂಗೀತ ಮತ್ತು ಪ್ರಭಾವಶಾಲಿ ಕಥಾವಾಚನದ ಮೂಲಕ, ಮಹದೇಶ್ವರನು ಕೇವಲ ಇತಿಹಾಸದ ಪುಸ್ತಕಗಳಲ್ಲಿ ಮಾತ್ರವಲ್ಲದೆ, ಜನರ ಹೃದಯ ಮತ್ತು ಧ್ವನಿಯಲ್ಲಿ ನೆಲೆಸಿದ್ದಾನೆ.", "🎶"],
        ["Today, high atop the Male Mahadeshwara Hills, a magnificent temple stands where the saint once walked. Every year, lakhs of devotees from all over the country travel to this hilltop to pay their respects and seek blessings. The atmosphere is filled with devotion, chants, and the sound of Kamsale music. People believe that the saint still watches over the forests and the animals he once protected. For the children of Karnataka, Sri Male Mahadeshwara is a hero who represents the harmony between humans, nature, and the divine. His life teaches us that true power lies in kindness, and that by living in balance with the world around us, we can perform our own small miracles every day for those in need.", "ಇಂದು, ಮಲೆ ಮಹದೇಶ್ವರ ಬೆಟ್ಟದ ಶಿಖರದ ಮೇಲೆ ಭವ್ಯವಾದ ದೇವಾಲಯವಿದೆ. ಪ್ರತಿ ವರ್ಷ ದೇಶದ ಮೂಲೆ ಮೂಲೆಗಳಿಂದ ಲಕ್ಷಾಂತರ ಭಕ್ತರು ಈ ಬೆಟ್ಟಕ್ಕೆ ಭೇಟಿ ನೀಡಿ ಆಶೀರ್ವಾದ ಪಡೆಯುತ್ತಾರೆ. ಅಲ್ಲಿನ ವಾತಾವರಣವು ಭಕ್ತಿ, ಮಂತ್ರಘೋಷ ಮತ್ತು ಕಂಸಾಳೆ ಸಂಗೀತದ ಧ್ವನಿಯಿಂದ ತುಂಬಿರುತ್ತದೆ. ಮಹದೇಶ್ವರನು ಇಂದಿಗೂ ತಾನು ರಕ್ಷಿಸಿದ ಕಾಡು ಮತ್ತು ಪ್ರಾಣಿಗಳನ್ನು ಕಾಯುತ್ತಿದ್ದಾನೆ ಎಂದು ಜನರು ನಂಬುತ್ತಾರೆ. ಕರ್ನಾಟಕದ ಮಕ್ಕಳಿಗೆ, ಶ್ರೀ ಮಲೆ ಮಹದೇಶ್ವರನು ಮಾನವ, ಪ್ರಕೃತಿ ಮತ್ತು ದೈವತ್ವದ ನಡುವಿನ ಸಾಮರಸ್ಯದ ಸಂಕೇತವಾಗಿದ್ದಾನೆ. ನಿಜವಾದ ಶಕ್ತಿಯು ದಯೆಯಲ್ಲಿ ಅಡಗಿದೆ ಮತ್ತು ಪ್ರಕೃತಿಯೊಂದಿಗೆ ಸಮತೋಲನದಿಂದ ಬದುಕುವ ಮೂಲಕ ನಾವು ಇತರರಿಗೆ ಸಹಾಯ ಮಾಡಬಹುದು ಎಂಬುದನ್ನು ಅವನ ಜೀವನ ನಮಗೆ ಕಲಿಸುತ್ತದೆ.", "🛕"]
      ],
      quiz: [
        ["He is the saint of…", "ಯಾವುದರ ಸಂತ?", ["The hills", "The sea", "The desert"], ["ಬೆಟ್ಟ", "ಸಮುದ್ರ", "ಮರುಭೂಮಿ"], 0],
        ["He tamed a wild…", "ಏನನ್ನು ಪಳಗಿಸಿದರು?", ["Tiger", "Eagle", "Snake"], ["ಹುಲಿ", "ಗರುಡ", "ಹಾವು"], 0],
      
        ['He lived in which century?', 'ಶತಮಾನ?', ['15th', '20th', '5th'], ['೧೫ನೇ', '೨೦ನೇ', '೫ನೇ'], 0],
        ['Hills named after him?', 'ಬೆಟ್ಟ?', ['Male Mahadeshwara', 'Nandi', 'Chamundi'], ['ಮಲೆ ಮಹದೇಶ್ವರ', 'ನಂದಿ', 'ಚಾಮುಂಡಿ'], 0],
        ['In which district?', 'ಜಿಲ್ಲೆ?', ['Chamarajanagar', 'Mysuru', 'Hassan'], ['ಚಾಮರಾಜನಗರ', 'ಮೈಸೂರು', 'ಹಾಸನ'], 0],
        ['Tradition of his songs?', 'ಪರಂಪರೆ?', ['Male Mahadeshwara Kavya', 'Vachana', 'Yakshagana'], ['ಮಲೆ ಮಹದೇಶ್ವರ ಕಾವ್ಯ', 'ವಚನ', 'ಯಕ್ಷಗಾನ'], 0],
        ['He is a saint of…', 'ಸಂತ?', ['Shaiva tradition', 'Vaishnava', 'Jain'], ['ಶೈವ', 'ವೈಷ್ಣವ', 'ಜೈನ'], 0],
        ['He tamed which animal?', 'ಪ್ರಾಣಿ?', ['Tiger', 'Lion', 'Bear'], ['ಹುಲಿ', 'ಸಿಂಹ', 'ಕರಡಿ'], 0],
        ['Famous for performing…', 'ಪ್ರಸಿದ್ಧಿ?', ['Miracles', 'Wars', 'Trade'], ['ಪವಾಡ', 'ಯುದ್ಧ', 'ವ್ಯಾಪಾರ'], 0],
        ['Devotees visit him in…', 'ಭಕ್ತರ ಯಾತ್ರೆ?', ['Lakhs', 'Tens', 'Hundreds'], ['ಲಕ್ಷಗಟ್ಟಲೆ', 'ಹತ್ತಾರು', 'ನೂರಾರು'], 0],
      ],
      memorial: ["Male Mahadeshwara Temple", "ಮಲೆ ಮಹದೇಶ್ವರ ದೇವಾಲಯ", "MM Hills, Chamarajanagar", "ಎಂಎಂ ಬೆಟ್ಟ", "A famous hill shrine in the Western Ghats.", "ಪಶ್ಚಿಮ ಘಟ್ಟಗಳಲ್ಲಿ ಪ್ರಸಿದ್ಧ ದೇವಾಲಯ.", "Male Mahadeshwara Hills temple"],
    })],
  },
  {
    id: "chikkaballapur", name: { en: "Chikkaballapur", kn: "ಚಿಕ್ಕಬಳ್ಳಾಪುರ" }, emoji: "⛰️",
    heroes: [mkHero({
      id: "sir-m-visvesvaraya", emoji: "🛠️",
      name: ["Sir M. Visvesvaraya", "ಸರ್ ಎಂ. ವಿಶ್ವೇಶ್ವರಯ್ಯ"],
      title: ["Engineer of Modern India", "ಆಧುನಿಕ ಭಾರತದ ಎಂಜಿನಿಯರ್"],
      era: "1860 – 1962",
      pages: [
        ["In the small, quiet village of Muddenahalli in Chikkaballapur, a brilliant star was born in 1860 named Mokshagundam Visvesvaraya. Growing up in a modest family, young Visvesvaraya walked miles to attend school, carrying a heart full of curiosity. He loved observing how things worked, from the flow of water in streams to the sturdy structure of local buildings. Even though his family lacked riches, his mother taught him the value of honesty and hard work. These early lessons in the humble surroundings of rural Karnataka shaped him into a boy who dreamed of using science to improve the lives of everyone around him. He knew that with education and discipline, he could build a brighter future for his people and the land he loved so dearly.", "ಚಿಕ್ಕಬಳ್ಳಾಪುರದ ಮುದ್ದೇನಹಳ್ಳಿ ಎಂಬ ಸಣ್ಣ ಗ್ರಾಮದಲ್ಲಿ ೧೮೬೦ ರಲ್ಲಿ ಮೋಕ್ಷಗುಂಡಂ ವಿಶ್ವೇಶ್ವರಯ್ಯ ಎಂಬ ಪ್ರತಿಭಾವಂತ ಬಾಲಕ ಜನಿಸಿದನು. ಸಾಮಾನ್ಯ ಕುಟುಂಬದಲ್ಲಿ ಬೆಳೆದ ಬಾಲಕ ವಿಶ್ವೇಶ್ವರಯ್ಯ, ಕುತೂಹಲದ ಮನಸ್ಸಿನೊಂದಿಗೆ ಶಾಲೆಗೆ ಹೋಗಲು ಮೈಲುಗಟ್ಟಲೆ ನಡೆಯುತ್ತಿದ್ದನು. ತೊರೆಗಳಲ್ಲಿ ಹರಿಯುವ ನೀರು ಅಥವಾ ಸ್ಥಳೀಯ ಕಟ್ಟಡಗಳ ರಚನೆಯನ್ನು ನೋಡಿ ಅವು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತವೆ ಎಂದು ತಿಳಿಯಲು ಅವರು ಇಷ್ಟಪಡುತ್ತಿದ್ದರು. ಅವರ ಕುಟುಂಬದಲ್ಲಿ ಹೆಚ್ಚಿನ ಸಂಪತ್ತು ಇಲ್ಲದಿದ್ದರೂ, ಅವರ ತಾಯಿ ಅವರಿಗೆ ಪ್ರಾಮಾಣಿಕತೆ ಮತ್ತು ಕಠಿಣ ಪರಿಶ್ರಮದ ಮೌಲ್ಯವನ್ನು ಕಲಿಸಿದರು. ಗ್ರಾಮೀಣ ಕರ್ನಾಟಕದ ಈ ವಾತಾವರಣವು ವಿಜ್ಞಾನದ ಮೂಲಕ ಜನರ ಜೀವನವನ್ನು ಸುಧಾರಿಸುವ ಕನಸು ಕಾಣಲು ಅವರಿಗೆ ಸ್ಫೂರ್ತಿ ನೀಡಿತು. ಶಿಕ್ಷಣ ಮತ್ತು ಶಿಸ್ತಿನಿಂದ ತನ್ನ ನಾಡಿನ ಜನರಿಗೆ ಉತ್ತಮ ಭವಿಷ್ಯವನ್ನು ಕಟ್ಟಿಕೊಡಬಹುದೆಂದು ಅವರು ಅರಿತಿದ್ದರು.", "🏠"],
        ["Visvesvaraya was a dedicated student who realized that knowledge was the key to progress. He moved to Bangalore and later to Pune to study civil engineering, always standing out for his sharp intellect and punctuality. He was known to carry his books everywhere, treating every moment as an opportunity to learn. After graduating at the top of his class, he began his career as an engineer, quickly gaining a reputation for solving difficult problems. In one famous project, he designed the automatic flood-gates at the Khadakwasla Reservoir, a clever invention that allowed water to be stored without harming the dam during floods. His fame as an expert who could master the flow of water began to spread across the entire country, making his home district proud.", "ವಿಶ್ವೇಶ್ವರಯ್ಯನವರು ಜ್ಞಾನವೇ ಪ್ರಗತಿಗೆ ಕನ್ನಡಿ ಎಂದು ನಂಬಿದ್ದ ಶಿಸ್ತಿನ ವಿದ್ಯಾರ್ಥಿಯಾಗಿದ್ದರು. ಅವರು ಸಿವಿಲ್ ಎಂಜಿನಿಯರಿಂಗ್ ಕಲಿಯಲು ಬೆಂಗಳೂರು ಮತ್ತು ನಂತರ ಪುಣೆಗೆ ತೆರಳಿದರು, ಅಲ್ಲಿ ತಮ್ಮ ಚುರುಕಾದ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ಸಮಯಪಾಲನೆಯಿಂದ ಎಲ್ಲರ ಗಮನ ಸೆಳೆದರು. ಪ್ರತಿಯೊಂದು ಕ್ಷಣವನ್ನು ಕಲಿಯಲು ಬಳಸುತ್ತಿದ್ದ ಅವರು ಯಾವಾಗಲೂ ಪುಸ್ತಕಗಳನ್ನು ಜೊತೆಯಲ್ಲೇ ಇಟ್ಟುಕೊಳ್ಳುತ್ತಿದ್ದರು. ಪದವಿಯಲ್ಲಿ ಪ್ರಥಮ ಸ್ಥಾನ ಪಡೆದ ನಂತರ, ಎಂಜಿನಿಯರ್ ಆಗಿ ತಮ್ಮ ವೃತ್ತಿಜೀವನವನ್ನು ಪ್ರಾರಂಭಿಸಿದ ಅವರು ಕಠಿಣ ಸಮಸ್ಯೆಗಳನ್ನು ಸುಲಭವಾಗಿ ಬಗೆಹರಿಸುತ್ತಾರೆ ಎಂಬ ಹೆಸರು ಮಾಡಿದರು. ಪುಣೆಯ ಖಡಕ್ವಾಸ್ಲಾ ಜಲಾಶಯದಲ್ಲಿ ಅವರು ವಿನ್ಯಾಸಗೊಳಿಸಿದ ಸ್ವಯಂಚಾಲಿತ ಗೇಟುಗಳು ಪ್ರವಾಹದ ಸಮಯದಲ್ಲಿ ಅಣೆಕಟ್ಟಿಗೆ ಹಾನಿಯಾಗದಂತೆ ನೀರನ್ನು ಸಂಗ್ರಹಿಸಲು ಸಹಾಯ ಮಾಡಿತು. ನೀರಿನ ಹರಿವನ್ನು ನಿಯಂತ್ರಿಸುವ ಅವರ ಈ ಚಾಣಾಕ್ಷತನ ಇಡೀ ದೇಶಕ್ಕೆ ತಿಳಿಯಿತು.", "📚"],
        ["The Maharaja of Mysore recognized his brilliance and invited him to serve as the Diwan of Mysore from 1912 to 1918. During this golden period, Visvesvaraya transformed the state into a modern marvel. He believed that industries and education were the pillars of a great nation. He worked tirelessly to establish important institutions like the Bhadravati Iron Works, the Mysore Soap Factory, and the Bank of Mysore. He also founded the University of Mysore to ensure that young people could gain wisdom near their homes. His vision was not just about building structures, but about creating jobs and opportunities for the common people. Under his leadership, Mysore became one of the most developed and prosperous regions in India, earning him the title of the Engineer of Modern India.", "ಮೈಸೂರು ಮಹಾರಾಜರು ಅವರ ಪ್ರತಿಭೆಯನ್ನು ಗುರುತಿಸಿ ೧೯೧೨ ರಿಂದ ೧೯೧೮ ರವರೆಗೆ ಮೈಸೂರಿನ ದಿವಾನರನ್ನಾಗಿ ನೇಮಿಸಿದರು. ಈ ಸುವರ್ಣ ಕಾಲದಲ್ಲಿ ವಿಶ್ವೇಶ್ವರಯ್ಯನವರು ಮೈಸೂರು ರಾಜ್ಯವನ್ನು ಆಧುನಿಕ ಮಾದರಿಯನ್ನಾಗಿ ಮಾಡಿದರು. ಕೈಗಾರಿಕೆಗಳು ಮತ್ತು ಶಿಕ್ಷಣವು ಒಂದು ರಾಷ್ಟ್ರದ ಆಧಾರಸ್ತಂಭಗಳೆಂದು ಅವರು ನಂಬಿದ್ದರು. ಅವರು ಭದ್ರಾವತಿ ಕಬ್ಬಿಣದ ಕಾರ್ಖಾನೆ, ಮೈಸೂರು ಸೋಪ್ ಫ್ಯಾಕ್ಟರಿ ಮತ್ತು ಸ್ಟೇಟ್ ಬ್ಯಾಂಕ್ ಆಫ್ ಮೈಸೂರನ್ನು ಸ್ಥಾಪಿಸಲು ದಣಿವರಿಯಿಲ್ಲದೆ ಕೆಲಸ ಮಾಡಿದರು. ಯುವಜನರು ಉತ್ತಮ ಶಿಕ್ಷಣ ಪಡೆಯಲು ಮೈಸೂರು ವಿಶ್ವವಿದ್ಯಾಲಯವನ್ನು ಸ್ಥಾಪಿಸಿದರು. ಅವರ ಗುರಿ ಕೇವಲ ಕಟ್ಟಡಗಳನ್ನು ಕಟ್ಟುವುದು ಮಾತ್ರವಲ್ಲದೆ, ಜನರಿಗೆ ಉದ್ಯೋಗ ಮತ್ತು ಅವಕಾಶಗಳನ್ನು ಒದಗಿಸುವುದಾಗಿತ್ತು. ಅವರ ನಾಯಕತ್ವದಲ್ಲಿ ಮೈಸೂರು ಭಾರತದ ಅತ್ಯಂತ ಅಭಿವೃದ್ಧಿ ಹೊಂದಿದ ಪ್ರದೇಶಗಳಲ್ಲಿ ಒಂದಾಯಿತು, ಇದರಿಂದ ಅವರಿಗೆ 'ಆಧುನಿಕ ಭಾರತದ ಎಂಜಿನಿಯರ್' ಎಂಬ ಹೆಸರು ಬಂದಿತು.", "🏗️"],
        ["One of his greatest achievements was the construction of the Krishna Raja Sagara (KRS) dam across the Kaveri River. At the time it was built, it was one of the largest dams in Asia. This massive structure brought life to the dry lands of Mandya and Mysore, turning them into lush green fields where farmers could grow crops all year round. Visvesvaraya spent countless hours at the site, ensuring every stone was placed perfectly and every measurement was correct. The dam did not just provide water; it brought hope and food to millions of families. People looked at the beautiful Brindavan Gardens next to the dam and saw the harmony between nature and engineering. This project remains a symbol of his technical genius and his deep love for the farmers of Karnataka.", "ಕಾವೇರಿ ನದಿಗೆ ಅಡ್ಡಲಾಗಿ ಕಟ್ಟಲಾದ ಕೃಷ್ಣರಾಜ ಸಾಗರ (KRS) ಅಣೆಕಟ್ಟು ಅವರ ಅತ್ಯಂತ ದೊಡ್ಡ ಸಾಧನೆಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ. ಅದು ನಿರ್ಮಾಣವಾದಾಗ ಏಷ್ಯಾದಲ್ಲೇ ಅತಿದೊಡ್ಡ ಅಣೆಕಟ್ಟುಗಳಲ್ಲಿ ಒಂದಾಗಿತ್ತು. ಈ ಬೃಹತ್ ರಚನೆಯು ಮಂಡ್ಯ ಮತ್ತು ಮೈಸೂರಿನ ಒಣ ಭೂಮಿಗೆ ಜೀವ ನೀಡಿತು, ಇದರಿಂದ ರೈತರು ವರ್ಷಪೂರ್ತಿ ಬೆಳೆ ಬೆಳೆಯಲು ಸಾಧ್ಯವಾಯಿತು. ವಿಶ್ವೇಶ್ವರಯ್ಯನವರು ಅಣೆಕಟ್ಟಿನ ಸ್ಥಳದಲ್ಲಿ ಅಸಂಖ್ಯಾತ ಗಂಟೆಗಳ ಕಾಲ ಕಳೆದು, ಪ್ರತಿಯೊಂದು ಅಳತೆಯೂ ಸರಿಯಾಗಿರುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಂಡರು. ಈ ಅಣೆಕಟ್ಟು ಕೇವಲ ನೀರನ್ನು ಮಾತ್ರವಲ್ಲದೆ ಲಕ್ಷಾಂತರ ಕುಟುಂಬಗಳಿಗೆ ಭರವಸೆಯನ್ನು ನೀಡಿತು. ಜನರು ಅಣೆಕಟ್ಟಿನ ಪಕ್ಕದಲ್ಲಿರುವ ಸುಂದರವಾದ ಬೃಂದಾವನ ಗಾರ್ಡನ್ ಅನ್ನು ನೋಡಿದಾಗ ಪ್ರಕೃತಿ ಮತ್ತು ತಂತ್ರಜ್ಞಾನದ ಸುಂದರ ಸಂಗಮ ಅವರಿಗೆ ಕಾಣಿಸುತ್ತದೆ. ಈ ಯೋಜನೆಯು ಇಂದಿಗೂ ಅವರ ತಾಂತ್ರಿಕ ಸಾಮರ್ಥ್ಯ ಮತ್ತು ರೈತರ ಮೇಲಿದ್ದ ಪ್ರೀತಿಯ ಸಂಕೇತವಾಗಿ ಉಳಿದಿದೆ.", "🌊"],
        ["Sir M. Visvesvaraya lived a long and meaningful life, reaching the age of 101. In 1955, the government honored him with the Bharat Ratna, India's highest award, for his extraordinary service. Every year on September 15th, his birthday is celebrated across India as Engineer’s Day to inspire young thinkers. To this day, his simple lifestyle and high thinking remain a model for everyone. Even as an old man, he remained active, always curious about new ways to help the nation. He showed the world that with hard work, integrity, and a desire to serve, one person can build a legacy that lasts for centuries. His life teaches children that they too can use their talents to solve problems and build a better world for everyone.", "ಸರ್ ಎಂ. ವಿಶ್ವೇಶ್ವರಯ್ಯನವರು ೧೦೧ ವರ್ಷಗಳ ಸುದೀರ್ಘ ಮತ್ತು ಸಾರ್ಥಕ ಜೀವನವನ್ನು ನಡೆಸಿದರು. ಭಾರತ ಸರ್ಕಾರವು ಅವರ ಅಸಾಧಾರಣ ಸೇವೆಗಾಗಿ ೧೯೫೫ ರಲ್ಲಿ ದೇಶದ ಅತ್ಯುನ್ನತ ಗೌರವವಾದ 'ಭಾರತ ರತ್ನ' ಪ್ರಶಸ್ತಿಯನ್ನು ನೀಡಿ ಗೌರವಿಸಿತು. ಪ್ರತಿ ವರ್ಷ ಸೆಪ್ಟೆಂಬರ್ ೧೫ ರಂದು ಅವರ ಜನ್ಮದಿನವನ್ನು ಭಾರತದಾದ್ಯಂತ 'ಎಂಜಿನಿಯರ್ ದಿನ' ಎಂದು ಆಚರಿಸಲಾಗುತ್ತದೆ. ಇಂದಿಗೂ ಅವರ ಸರಳ ಜೀವನ ಮತ್ತು ಉನ್ನತ ಚಿಂತನೆ ಎಲ್ಲರಿಗೂ ಮಾದರಿಯಾಗಿದೆ. ಇಳಿವಯಸ್ಸಿನಲ್ಲೂ ಅವರು ದೇಶದ ಸೇವೆ ಮಾಡಲು ಹೊಸ ಮಾರ್ಗಗಳನ್ನು ಹುಡುಕುತ್ತಿದ್ದರು. ಕಠಿಣ ಪರಿಶ್ರಮ ಮತ್ತು ಸೇವಾ ಮನೋಭಾವದಿಂದ ಒಬ್ಬ ವ್ಯಕ್ತಿಯು ಶತಮಾನಗಳ ಕಾಲ ಉಳಿಯುವ ಸಾಧನೆ ಮಾಡಬಹುದು ಎಂದು ಅವರು ಜಗತ್ತಿಗೆ ತೋರಿಸಿಕೊಟ್ಟರು. ಪ್ರತಿಯೊಬ್ಬ ಮಗುವೂ ಸಹ ತನ್ನ ಪ್ರತಿಭೆಯನ್ನು ಬಳಸಿ ಉತ್ತಮ ಪ್ರಪಂಚವನ್ನು ನಿರ್ಮಿಸಬಹುದು ಎಂಬ ಪಾಠವನ್ನು ಅವರ ಜೀವನವು ನಮಗೆ ಕಲಿಸುತ್ತದೆ.", "🎖️"]
      ],
      quiz: [
        ["His profession was…", "ವೃತ್ತಿ?", ["Engineer", "Doctor", "Poet"], ["ಎಂಜಿನಿಯರ್", "ವೈದ್ಯ", "ಕವಿ"], 0],
        ["Which dam did he plan?", "ಯಾವ ಅಣೆಕಟ್ಟು?", ["KRS", "Bhakra", "Hirakud"], ["ಕೆಆರ್‌ಎಸ್", "ಭಾಕ್ರಾ", "ಹಿರಾಕುಡ್"], 0],
      
        ['Born in village…', 'ಜನ್ಮ ಗ್ರಾಮ?', ['Muddenahalli', 'Hampi', 'Bidar'], ['ಮುದ್ದೇನಹಳ್ಳಿ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['Born in year…', 'ಜನ್ಮ ವರ್ಷ?', ['1860', '1800', '1900'], ['೧೮೬೦', '೧೮೦೦', '೧೯೦೦'], 0],
        ['He lived to age…', 'ವಯಸ್ಸು?', ['101', '60', '80'], ['೧೦೧', '೬೦', '೮೦'], 0],
        ['Diwan of Mysore from…', 'ಮೈಸೂರು ದಿವಾನ್?', ['1912', '1800', '1947'], ['೧೯೧೨', '೧೮೦೦', '೧೯೪೭'], 0],
        ['Awarded Bharat Ratna in…', 'ಭಾರತ ರತ್ನ?', ['1955', '1900', '1980'], ['೧೯೫೫', '೧೯೦೦', '೧೯೮೦'], 0],
        ['KRS dam is on river…', 'ಯಾವ ನದಿ?', ['Kaveri', 'Krishna', 'Tunga'], ['ಕಾವೇರಿ', 'ಕೃಷ್ಣಾ', 'ತುಂಗಾ'], 0],
        ['His birthday is celebrated as…', 'ಜನ್ಮದಿನ?', ["Engineers' Day", "Teachers' Day", "Doctors' Day"], ['ಎಂಜಿನಿಯರ್ಸ್ ಡೇ', 'ಶಿಕ್ಷಕರ ದಿನ', 'ವೈದ್ಯರ ದಿನ'], 0],
        ['He served as Diwan of…', 'ದಿವಾನ್?', ['Mysore', 'Hyderabad', 'Travancore'], ['ಮೈಸೂರು', 'ಹೈದರಾಬಾದ್', 'ತಿರುವಾಂಕೂರ್'], 0],
      ],
      memorial: ["Visvesvaraya Memorial", "ವಿಶ್ವೇಶ್ವರಯ್ಯ ಸ್ಮಾರಕ", "Muddenahalli, Chikkaballapur", "ಮುದ್ದೇನಹಳ್ಳಿ", "His birth-house museum displays his medals and tools.", "ಅವರ ಜನ್ಮಮನೆ ವಸ್ತುಸಂಗ್ರಹಾಲಯ.", "Visvesvaraya Memorial Muddenahalli"],
    })],
  },
  {
    id: "chikkamagaluru", name: { en: "Chikkamagaluru", kn: "ಚಿಕ್ಕಮಗಳೂರು" }, emoji: "☕",
    heroes: [mkHero({
      id: "baba-budan", emoji: "🌱",
      name: ["Baba Budan", "ಬಾಬಾ ಬುಡನ್"],
      title: ["Saint who brought coffee to India", "ಭಾರತಕ್ಕೆ ಕಾಫಿ ತಂದ ಸಂತ"],
      era: "17th Century",
      pages: [
        ["Long ago, in the early 16th century, lived a gentle Sufi saint named Baba Budan. Known to his followers as Hazrat Dada Hayat Mir Khalandar, he spent his days in quiet prayer and helpful service in the lush, green regions of Karnataka. He was a man of peace who cared deeply for all people, regardless of their background. His heart was filled with a desire to see the world beyond the mountains, so he decided to embark on a long and sacred journey. This journey would take him across vast oceans to the holy city of Mecca, a path that many pilgrims traveled to find wisdom and grace. Little did he know that his humble adventure would soon change the fields of India forever, bringing a magical new crop that would wake up the whole world.", "ಬಹಳ ಹಿಂದೆಯೇ, ೧೬ನೇ ಶತಮಾನದ ಆರಂಭದಲ್ಲಿ, ಬಾಬಾ ಬುಡನ್ ಎಂಬ ದಯಾಳು ಸೂಫಿ ಸಂತರೊಬ್ಬರು ವಾಸಿಸುತ್ತಿದ್ದರು. ಅವರ ಅನುಯಾಯಿಗಳಿಗೆ ಹಜರತ್ ದಾದಾ ಹಯಾತ್ ಮೀರ್ ಖಲಂದರ್ ಎಂದು ಪರಿಚಿತರಾಗಿದ್ದ ಅವರು, ಕರ್ನಾಟಕದ ಹಸಿರುಮಯ ಪ್ರದೇಶಗಳಲ್ಲಿ ಪ್ರಾರ್ಥನೆ ಮತ್ತು ಸೇವೆಯಲ್ಲಿ ದಿನಗಳನ್ನು ಕಳೆಯುತ್ತಿದ್ದರು. ಅವರು ಶಾಂತಿಪ್ರಿಯ ವ್ಯಕ್ತಿಯಾಗಿದ್ದರು ಮತ್ತು ಎಲ್ಲ ಜನರ ಬಗ್ಗೆ ಅಪಾರ ಕಾಳಜಿಯನ್ನು ಹೊಂದಿದ್ದರು. ಬೆಟ್ಟಗಳ ಆಚೆಗಿನ ಜಗತ್ತನ್ನು ನೋಡುವ ಹಂಬಲ ಅವರಲ್ಲಿ ತುಂಬಿತ್ತು, ಆದ್ದರಿಂದ ಅವರು ಒಂದು ಸುದೀರ್ಘ ಮತ್ತು ಪವಿತ್ರ ಪ್ರಯಾಣವನ್ನು ಕೈಗೊಳ್ಳಲು ನಿರ್ಧರಿಸಿದರು. ಈ ಪ್ರಯಾಣವು ಅವರನ್ನು ವಿಶಾಲವಾದ ಸಾಗರಗಳನ್ನು ದಾಟಿಸಿ ಮೆಕ್ಕಾ ಎಂಬ ಪವಿತ್ರ ನಗರಕ್ಕೆ ಕರೆದೊಯ್ಯಿತು. ಅವರ ಈ ವಿನಮ್ರ ಸಾಹಸವು ಶೀಘ್ರದಲ್ಲೇ ಭಾರತದ ಹೊಲಗದ್ದೆಗಳನ್ನು ಶಾಶ್ವತವಾಗಿ ಬದಲಾಯಿಸುತ್ತದೆ ಮತ್ತು ಇಡೀ ಜಗತ್ತನ್ನು ಎಚ್ಚರಿಸುವ ಒಂದು ಹೊಸ ಬೆಳೆಯನ್ನು ತರುತ್ತದೆ ಎಂದು ಯಾರಿಗೂ ತಿಳಿದಿರಲಿಲ್ಲ.", "☁️"],
        ["After finishing his prayers in Mecca, Baba Budan traveled through the rolling sands of Yemen on his way back home. While resting in the port city of Mocha, he discovered a dark, fragrant drink made from boiled beans that gave people energy and clarity. He loved the taste and realized how much this plant could help the farmers back in Karnataka. However, there was a big problem: the local authorities strictly forbade anyone from taking green coffee beans or fertile seeds out of the country. They wanted to keep the secrets of coffee for themselves. Baba Budan knew that to share this gift with his people, he would have to be very clever and brave. He watched the coffee plants swaying in the desert breeze and made a secret plan to bring them home.", "ಮೆಕ್ಕಾದಲ್ಲಿ ತಮ್ಮ ಪ್ರಾರ್ಥನೆಗಳನ್ನು ಮುಗಿಸಿದ ನಂತರ, ಬಾಬಾ ಬುಡನ್ ಅವರು ಮನೆಗೆ ಹಿಂದಿರುಗುವ ದಾರಿಯಲ್ಲಿ ಯೆಮೆನ್ ನ ಮರಳುಗಾಡಿನ ಮೂಲಕ ಪ್ರಯಾಣಿಸಿದರು. ಮೋಚಾ ಎಂಬ ಬಂದರು ನಗರದಲ್ಲಿ ವಿಶ್ರಾಂತಿ ಪಡೆಯುತ್ತಿರುವಾಗ, ಅವರು ಜನರಿಗೆ ಶಕ್ತಿ ಮತ್ತು ಚೈತನ್ಯವನ್ನು ನೀಡುವ ಕಪ್ಪು, ಸುವಾಸನೆಯ ಪಾನೀಯವನ್ನು ಕಂಡುಹಿಡಿದರು. ಆ ಪಾನೀಯದ ರುಚಿ ಅವರಿಗೆ ಬಹಳ ಇಷ್ಟವಾಯಿತು ಮತ್ತು ಈ ಸಸ್ಯವು ಕರ್ನಾಟಕದ ರೈತರಿಗೆ ಎಷ್ಟು ಸಹಾಯ ಮಾಡಬಹುದು ಎಂದು ಅವರು ಅರಿತುಕೊಂಡರು. ಆದರೆ, ಅಲ್ಲಿ ಒಂದು ದೊಡ್ಡ ಸಮಸ್ಯೆ ಇತ್ತು: ಸ್ಥಳೀಯ ಅಧಿಕಾರಿಗಳು ಕಾಫಿ ಬೀಜಗಳನ್ನು ಅಥವಾ ಸಸ್ಯಗಳನ್ನು ದೇಶದಿಂದ ಹೊರಗೆ ಕೊಂಡೊಯ್ಯುವುದನ್ನು ಕಟ್ಟುನಿಟ್ಟಾಗಿ ನಿಷೇಧಿಸಿದ್ದರು. ಕಾಫಿಯ ರಹಸ್ಯವನ್ನು ತಮ್ಮಲ್ಲಿಯೇ ಇಟ್ಟುಕೊಳ್ಳಲು ಅವರು ಬಯಸಿದ್ದರು. ಈ ಉಡುಗೊರೆಯನ್ನು ತನ್ನ ಜನರೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಲು ತಾನು ಬಹಳ ಚತುರ ಮತ್ತು ಧೈರ್ಯಶಾಲಿಯಾಗಬೇಕೆಂದು ಬಾಬಾ ಬುಡನ್ ಅರ್ಥಮಾಡಿಕೊಂಡರು.", "🐪"],
        ["To bypass the strict guards at the port, Baba Budan took seven small, green coffee beans. In his culture, the number seven is considered very lucky and sacred. He carefully tucked the beans against his belly and strapped them tightly to his body with his cloth belt. He kept his secret hidden under his robes as he boarded the ship. Every step he took required great courage, for he knew that if he were caught, he could face great trouble. For weeks across the bumpy ocean waves, he protected the seven little seeds with his life. He envisioned a future where the hills of his homeland would be covered in green leaves and red berries, providing a new livelihood for generations of families in the beautiful land of Karnataka.", "ಬಂದರಿನಲ್ಲಿರುವ ಕಟ್ಟುನಿಟ್ಟಿನ ಕಾವಲುಗಾರರನ್ನು ದಾಟಲು, ಬಾಬಾ ಬುಡನ್ ಅವರು ಕಾಫಿಯ ಏಳು ಸಣ್ಣ ಹಸಿರು ಬೀಜಗಳನ್ನು ತೆಗೆದುಕೊಂಡರು. ಅವರ ಸಂಸ್ಕೃತಿಯಲ್ಲಿ ಏಳು ಎಂಬ ಸಂಖ್ಯೆಯನ್ನು ಅದೃಷ್ಟ ಮತ್ತು ಪವಿತ್ರವೆಂದು ಪರಿಗಣಿಸಲಾಗುತ್ತದೆ. ಅವರು ಆ ಬೀಜಗಳನ್ನು ಕಾಳಜಿಯಿಂದ ತಮ್ಮ ಹೊಟ್ಟೆಯ ಬಳಿ ಇಟ್ಟುಕೊಂಡು, ಬಟ್ಟೆಯ ಪಟ್ಟಿಯಿಂದ ಗಟ್ಟಿಯಾಗಿ ಕಟ್ಟಿಕೊಂಡರು. ಹಡಗನ್ನು ಏರುವಾಗ ಅವರು ತಮ್ಮ ಗುಟ್ಟನ್ನು ನಿಲುವಂಗಿಯ ಅಡಿಯಲ್ಲಿ ಅಡಗಿಸಿಟ್ಟಿದ್ದರು. ಅವರು ಇಡುವ ಪ್ರತಿಯೊಂದು ಹೆಜ್ಜೆಯೂ ಹೆಚ್ಚಿನ ಧೈರ್ಯವನ್ನು ಬಯಸುತ್ತಿತ್ತು, ಏಕೆಂದರೆ ಸಿಕ್ಕಿಬಿದ್ದರೆ ದೊಡ್ಡ ತೊಂದರೆಯನ್ನು ಅನುಭವಿಸಬೇಕಾಗುತ್ತದೆ ಎಂಬುದು ಅವರಿಗೆ ತಿಳಿದಿತ್ತು. ವಾರಗಟ್ಟಲೆ ಅಲೆಗಳ ಮೇಲೆ ಪ್ರಯಾಣಿಸುವಾಗ, ಅವರು ಆ ಪುಟ್ಟ ಬೀಜಗಳನ್ನು ಪ್ರಾಣಕ್ಕಿಂತ ಹೆಚ್ಚಾಗಿ ರಕ್ಷಿಸಿದರು. ಕರ್ನಾಟಕದ ಬೆಟ್ಟಗಳಲ್ಲಿ ಈ ಸಸ್ಯಗಳು ಬೆಳೆದು ರೈತರಿಗೆ ಹೊಸ ಜೀವನವನ್ನು ನೀಡುವ ಭವಿಷ್ಯವನ್ನು ಅವರು ಕನಸು ಕಂಡರು.", "🫘"],
        ["When at last he returned to the cool, misty mountains of Chikkamagaluru, Baba Budan found the perfect spot to plant his treasures. He chose the slopes of the Chandragiri Hills, where the soil was rich and the air was fresh. He carefully untied the seven beans from his belly and pushed them into the soft earth. Day after day, he tended to the soil and watched for the first signs of green. Soon, tiny sprouts emerged, growing into strong bushes with dark leaves and fragrant white flowers. These few seeds became the ancestors of every coffee plant in India. The local people watched in wonder as the hillsides began to transform. Because of his selfless act, the very first coffee plantation in India was born right there in the heart of Karnataka.", "ಅಂತಿಮವಾಗಿ ಅವರು ಚಿಕ್ಕಮಗಳೂರಿನ ತಂಪಾದ, ಮಂಜಿನ ಬೆಟ್ಟಗಳಿಗೆ ಮರಳಿದಾಗ, ಬಾಬಾ ಬುಡನ್ ಅವರು ತಮ್ಮ ನಿಧಿಯನ್ನು ನೆಡಲು ಸೂಕ್ತವಾದ ಸ್ಥಳವನ್ನು ಕಂಡುಕೊಂಡರು. ಅವರು ಮಣ್ಣು ಮತ್ತು ಗಾಳಿ ಪೂರಕವಾಗಿದ್ದ ಚಂದ್ರಗಿರಿ ಬೆಟ್ಟದ ಇಳಿಜಾರುಗಳನ್ನು ಆರಿಸಿಕೊಂಡರು. ತಮ್ಮ ಹೊಟ್ಟೆಯ ಬಳಿ ಕಟ್ಟಿಕೊಂಡಿದ್ದ ಆ ಏಳು ಬೀಜಗಳನ್ನು ಎಚ್ಚರಿಕೆಯಿಂದ ಬಿಚ್ಚಿ ಮೃದುವಾದ ಮಣ್ಣಿನಲ್ಲಿ ನೆಟ್ಟರು. ದಿನಕಳೆದಂತೆ ಅವರು ಮಣ್ಣನ್ನು ಪೋಷಿಸುತ್ತಾ ಮೊದಲ ಹಸಿರು ಮೊಳಕೆಗಾಗಿ ಕಾಯುತ್ತಿದ್ದರು. ಶೀಘ್ರದಲ್ಲೇ ಚಿಕ್ಕ ಮೊಳಕೆಗಳು ಕಾಣಿಸಿಕೊಂಡವು, ಅವು ದಟ್ಟವಾದ ಎಲೆಗಳು ಮತ್ತು ಸುವಾಸನೆಯ ಬಿಳಿ ಹೂವುಗಳನ್ನು ಹೊಂದಿದ ಬಲವಾದ ಪೊದೆಗಳಾಗಿ ಬೆಳೆದವು. ಈ ಕೆಲವು ಬೀಜಗಳು ಭಾರತದ ಪ್ರತಿಯೊಂದು ಕಾಫಿ ಗಿಡದ ಮೂಲವಾದವು. ಅವರ ಈ ನಿಸ್ವಾರ್ಥ ಕಾರ್ಯದಿಂದಾಗಿ, ಭಾರತದ ಅತ್ಯಂತ ಮೊದಲ ಕಾಫಿ ತೋಟವು ಕರ್ನಾಟಕದ ಹೃದಯಭಾಗದಲ್ಲಿ ಜನ್ಮತಾಳಿತು.", "🌱"],
        ["Today, those majestic mountains are renamed Baba Budangiri in his honor. Children and families visit the hills to breathe the crisp air and see where the story of Indian coffee began. Baba Budan is remembered not just as a brave traveler, but as a saint revered by both Hindus and Muslims alike, proving that goodness brings all people together. Thousands of coffee estates now spread across India, providing jobs and delicious drinks for millions. Every time you smell the rich aroma of coffee brewing in a kitchen, you are smelling the legacy of those seven hidden seeds. Baba Budan’s courage and love for his land turned a quiet mountain range into a world-famous home of coffee, forever connecting the spirit of Karnataka to the rest of the world.", "ಇಂದು, ಆ ಭವ್ಯವಾದ ಪರ್ವತಗಳಿಗೆ ಅವರ ಗೌರವಾರ್ಥವಾಗಿ 'ಬಾಬಾ ಬುಡನ್‌ಗಿರಿ' ಎಂದು ಮರುನಾಮಕರಣ ಮಾಡಲಾಗಿದೆ. ಭಾರತೀಯ ಕಾಫಿಯ ಕಥೆ ಎಲ್ಲಿ ಆರಂಭವಾಯಿತು ಎಂಬುದನ್ನು ನೋಡಲು ಇಂದಿಗೂ ಅನೇಕರು ಈ ಬೆಟ್ಟಗಳಿಗೆ ಭೇಟಿ ನೀಡುತ್ತಾರೆ. ಬಾಬಾ ಬುಡನ್ ಅವರನ್ನು ಕೇವಲ ಧೈರ್ಯಶಾಲಿ ಪ್ರವಾಸಿಗನಾಗಿ ಮಾತ್ರವಲ್ಲದೆ, ಹಿಂದೂ ಮತ್ತು ಮುಸ್ಲಿಮರಿಬ್ಬರೂ ಗೌರವಿಸುವ ಸಂತರಾಗಿ ನೆನಪಿಸಿಕೊಳ್ಳಲಾಗುತ್ತದೆ. ಇಂದು ಭಾರತದಾದ್ಯಂತ ಸಾವಿರಾರು ಕಾಫಿ ತೋಟಗಳು ಹರಡಿಕೊಂಡಿವೆ, ಇದು ಲಕ್ಷಾಂತರ ಜನರಿಗೆ ಉದ್ಯೋಗ ಮತ್ತು ರುಚಿಕರವಾದ ಪಾನೀಯವನ್ನು ಒದಗಿಸುತ್ತಿದೆ. ಪ್ರತಿ ಬಾರಿ ಕಾಫಿಯ ಸುವಾಸನೆಯನ್ನು ಆಸ್ವಾದಿಸುವಾಗ, ಆ ಏಳು ಗುಪ್ತ ಬೀಜಗಳ ಪರಂಪರೆಯನ್ನು ನೀವು ನೆನಪಿಸಿಕೊಳ್ಳಬಹುದು. ಬಾಬಾ ಬುಡನ್ ಅವರ ಧೈರ್ಯ ಮತ್ತು ಪ್ರೀತಿಯು ಒಂದು ಸಣ್ಣ ಬೆಟ್ಟವನ್ನು ಜಗತ್ಪ್ರಸಿದ್ಧ ಕಾಫಿಯ ನಾಡನ್ನಾಗಿ ಮಾಡಿತು ಮತ್ತು ಕರ್ನಾಟಕದ ಕೀರ್ತಿಯನ್ನು ಜಗದಗಲ ಪಸರಿಸಿತು.", "⛰️"]
      ],
      quiz: [
        ["He brought what to India?", "ಏನು ತಂದರು?", ["Coffee", "Tea", "Cocoa"], ["ಕಾಫಿ", "ಚಹಾ", "ಕೋಕೋ"], 0],
        ["From which country?", "ಯಾವ ದೇಶ?", ["Yemen", "Brazil", "Italy"], ["ಯೆಮೆನ್", "ಬ್ರೆಜಿಲ್", "ಇಟಲಿ"], 0],
      
        ['He brought coffee in which century?', 'ಶತಮಾನ?', ['16th', '20th', '12th'], ['೧೬ನೇ', '೨೦ನೇ', '೧೨ನೇ'], 0],
        ['How many beans did he bring?', 'ಎಷ್ಟು ಬೀಜ?', ['Seven', 'Two', 'Hundred'], ['ಏಳು', 'ಎರಡು', 'ನೂರು'], 0],
        ['He travelled from which port?', 'ಬಂದರು?', ['Mocha', 'Mumbai', 'Goa'], ['ಮೋಚಾ', 'ಮುಂಬೈ', 'ಗೋವಾ'], 0],
        ['He is a saint of which faith?', 'ನಂಬಿಕೆ?', ['Sufi', 'Hindu', 'Christian'], ['ಸೂಫಿ', 'ಹಿಂದೂ', 'ಕ್ರೈಸ್ತ'], 0],
        ['Hills now named…', 'ಬೆಟ್ಟ?', ['Baba Budangiri', 'Chandragiri', 'Nandi'], ['ಬಾಬಾ ಬುಡಂಗಿರಿ', 'ಚಂದ್ರಗಿರಿ', 'ನಂದಿ'], 0],
        ['Originally hills were called…', 'ಮೂಲ ಹೆಸರು?', ['Chandragiri', 'Nandi', 'Mullayanagiri'], ['ಚಂದ್ರಗಿರಿ', 'ನಂದಿ', 'ಮುಳ್ಳಯ್ಯನಗಿರಿ'], 0],
        ['Coffee planted in district…', 'ಜಿಲ್ಲೆ?', ['Chikkamagaluru', 'Mysuru', 'Bidar'], ['ಚಿಕ್ಕಮಗಳೂರು', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Number 7 was considered…', 'ಸಂಖ್ಯೆ ೭?', ['Sacred', 'Unlucky', 'Random'], ['ಪವಿತ್ರ', 'ಅಶುಭ', 'ಸಾಮಾನ್ಯ'], 0],
      ],
      memorial: ["Baba Budangiri Hills", "ಬಾಬಾ ಬುಡನ್‌ಗಿರಿ", "Chikkamagaluru", "ಚಿಕ್ಕಮಗಳೂರು", "Sacred hills covered in coffee gardens.", "ಕಾಫಿ ತೋಟಗಳ ಪವಿತ್ರ ಬೆಟ್ಟ.", "Baba Budangiri Chikkamagaluru"],
    })],
  },
  {
    id: "chitradurga", name: { en: "Chitradurga", kn: "ಚಿತ್ರದುರ್ಗ" }, emoji: "🏯",
    heroes: [mkHero({
      id: "onake-obavva", emoji: "🪵",
      name: ["Onake Obavva", "ಒನಕೆ ಓಬವ್ವ"],
      title: ["The Pestle Warrior", "ಒನಕೆಯ ವೀರಮಹಿಳೆ"],
      era: "18th Century",
      pages: [
        ["Long ago, in the 18th century, there lived a brave woman named Onake Obavva in the historic town of Chitradurga. She was the wife of Mudda Hanuma, a humble guard at the magnificent rocky fort during the rule of Madakari Nayaka. Obavva was an ordinary woman leading a simple life, but her heart was filled with courage and devotion to her land. In those days, Chitradurga was a powerful kingdom known for its seven circles of strong stone walls. Obavva lived near these walls, helping her husband and tending to her daily chores. She did not know that her name would one day be written in gold in the history of Karnataka. Her story begins with a quiet sense of duty and a love for the majestic fort she called home.", "ಬಹಳ ಹಿಂದೆಯೇ, 18 ನೇ ಶತಮಾನದಲ್ಲಿ, ಕರ್ನಾಟಕದ ಐತಿಹಾಸಿಕ ಪಟ್ಟಣವಾದ ಚಿತ್ರದುರ್ಗದಲ್ಲಿ ಓಬವ್ವ ಎಂಬ ಧೈರ್ಯಶಾಲಿ ಮಹಿಳೆ ವಾಸಿಸುತ್ತಿದ್ದರು. ಅವರು ಮದಕರಿ ನಾಯಕರ ಆಳ್ವಿಕೆಯಲ್ಲಿ ಭವ್ಯವಾದ ಕಲ್ಲಿನ ಕೋಟೆಯ ಕಾವಲುಗಾರನಾಗಿದ್ದ ಮುದ್ದ ಹನುಮನ ಪತ್ನಿಯಾಗಿದ್ದರು. ಓಬವ್ವ ಸಾಮಾನ್ಯ ಜೀವನ ನಡೆಸುತ್ತಿದ್ದರೂ, ಅವರ ಹೃದಯವು ನಾಡಿನ ಬಗ್ಗೆ ಧೈರ್ಯ ಮತ್ತು ಭಕ್ತಿಯಿಂದ ತುಂಬಿತ್ತು. ಆ ದಿನಗಳಲ್ಲಿ ಚಿತ್ರದುರ್ಗವು ತನ್ನ ಏಳು ಸುತ್ತಿನ ಭದ್ರವಾದ ಕಲ್ಲಿನ ಗೋಡೆಗಳಿಗೆ ಹೆಸರಾದ ಪ್ರಬಲ ರಾಜ್ಯವಾಗಿತ್ತು. ಓಬವ್ವ ಈ ಗೋಡೆಗಳ ಬಳಿಯೇ ವಾಸಿಸುತ್ತಾ, ತನ್ನ ಗಂಡನಿಗೆ ಸಹಾಯ ಮಾಡುತ್ತಾ ದಿನನಿತ್ಯದ ಕೆಲಸಗಳಲ್ಲಿ ತೊಡಗಿಸಿಕೊಂಡಿದ್ದರು. ಒಂದು ದಿನ ಕರ್ನಾಟಕದ ಇತಿಹಾಸದಲ್ಲಿ ತನ್ನ ಹೆಸರು ಬಂಗಾರದ ಅಕ್ಷರಗಳಲ್ಲಿ ಬರೆಯಲ್ಪಡುತ್ತದೆ ಎಂದು ಅವಳಿಗೆ ತಿಳಿದಿರಲಿಲ್ಲ. ಅವರ ಕಥೆಯು ಕರ್ತವ್ಯ ಪ್ರಜ್ಞೆ ಮತ್ತು ತಮ್ಮ ಕೋಟೆಯ ಮೇಲಿನ ಪ್ರೀತಿಯಿಂದ ಪ್ರಾರಂಭವಾಗುತ್ತದೆ.", "🏰"],
        ["As a hardworking woman of the household, Obavva was very familiar with her traditional tools. Her most important tool was the 'onake', a heavy wooden pestle used for pounding grain. Every day, she would use the onake to prepare food, developing great strength in her arms. She lived a quiet life, often watching her husband guard the watchtower. While the soldiers practiced with swords and shields, Obavva mastered the weight and balance of her wooden pestle through her daily labor. She was observant and knew every corner of the rocky landscape around the fort. This strength and knowledge of her surroundings would soon become the shield that protected the entire kingdom from a secret invasion by enemy forces.", "ಮನೆಯ ಶ್ರಮಜೀವಿ ಮಹಿಳೆಯಾಗಿ, ಓಬವ್ವ ತನ್ನ ಸಾಂಪ್ರದಾಯಿಕ ಸಾಧನಗಳ ಬಗ್ಗೆ ಚೆನ್ನಾಗಿ ತಿಳಿದಿದ್ದರು. ಧಾನ್ಯ ಕುಟ್ಟಲು ಬಳಸುವ ಭಾರವಾದ ಮರದ 'ಒನಕೆ' ಅವರ ಪ್ರಮುಖ ಸಾಧನವಾಗಿತ್ತು. ಪ್ರತಿದಿನ ಅವರು ಆಹಾರ ತಯಾರಿಸಲು ಒನಕೆಯನ್ನು ಬಳಸುತ್ತಿದ್ದರು, ಇದರಿಂದ ಅವರ ಕೈಗಳಲ್ಲಿ ಹೆಚ್ಚಿನ ಶಕ್ತಿ ಉಂಟಾಗಿತ್ತು. ಅವರು ಶಾಂತ ಜೀವನ ನಡೆಸುತ್ತಿದ್ದರು ಮತ್ತು ಹೆಚ್ಚಾಗಿ ತನ್ನ ಪತಿ ಕಾವಲು ಗೋಪುರವನ್ನು ಕಾಯುವುದನ್ನು ಗಮನಿಸುತ್ತಿದ್ದರು. ಸೈನಿಕರು ಕತ್ತಿ ಮತ್ತು ಗುರಾಣಿಗಳಿಂದ ಅಭ್ಯಾಸ ಮಾಡುತ್ತಿರುವಾಗ, ಓಬವ್ವ ತನ್ನ ದೈನಂದಿನ ಕೆಲಸದ ಮೂಲಕ ಮರದ ಒನಕೆಯ ತೂಕ ಮತ್ತು ಸಮತೋಲನವನ್ನು ಕರಗತ ಮಾಡಿಕೊಂಡಿದ್ದರು. ಅವರು ಬಹಳ ಜಾಗರೂಕರಾಗಿದ್ದರು ಮತ್ತು ಕೋಟೆಯ ಸುತ್ತಲಿನ ಪ್ರತಿಯೊಂದು ಮೂಲೆಗಳನ್ನು ತಿಳಿದಿದ್ದರು. ಈ ಶಕ್ತಿ ಮತ್ತು ಪರಿಸರದ ಜ್ಞಾನವು ಶೀಘ್ರದಲ್ಲೇ ಇಡೀ ರಾಜ್ಯವನ್ನು ಶತ್ರು ಪಡೆಗಳ ರಹಸ್ಯ ಆಕ್ರಮಣದಿಂದ ರಕ್ಷಿಸುವ ಗುರಾಣಿಯಾಗಲಿದೆ.", "🥣"],
        ["One afternoon, while her husband was away for lunch, Obavva went to fetch water near a small opening in the fort walls called a 'kindi'. Suddenly, she heard a strange, scratching sound. Peeking through the crevice, she realized that the soldiers of Hyder Ali were trying to sneak into the fort one by one through this narrow gap. Instead of running away in fear, the brave Obavva decided to act. She did not have a sword or a spear, but she firmly gripped her trusty wooden onake. She stood silently by the opening, hidden from view. She knew that if she shouted for help, the enemies might be alerted and rush in all at once. She chose to fight alone to save her people.", "ಒಂದು ಮಧ್ಯಾಹ್ನ, ತನ್ನ ಪತಿ ಊಟಕ್ಕೆ ಹೋದಾಗ, ಓಬವ್ವ ಕೋಟೆಯ ಗೋಡೆಯಲ್ಲಿರುವ 'ಕಿಂಡಿ' ಎಂಬ ಸಣ್ಣ ರಂಧ್ರದ ಬಳಿ ನೀರು ತರಲು ಹೋದರು. ಹಠಾತ್ತನೆ ಅವರಿಗೆ ವಿಚಿತ್ರವಾದ ಶಬ್ದ ಕೇಳಿಸಿತು. ಕಿಂಡಿಯ ಮೂಲಕ ಇಣುಕಿ ನೋಡಿದಾಗ, ಹೈದರ್ ಅಲಿಯ ಸೈನಿಕರು ಈ ಕಿರಿದಾದ ರಂಧ್ರದ ಮೂಲಕ ಒಬ್ಬೊಬ್ಬರಾಗಿ ಕೋಟೆಯೊಳಗೆ ನುಗ್ಗಲು ಪ್ರಯತ್ನಿಸುತ್ತಿರುವುದು ಅವಳಿಗೆ ತಿಳಿಯಿತು. ಭಯದಿಂದ ಓಡಿಹೋಗುವ ಬದಲು, ಧೈರ್ಯಶಾಲಿ ಓಬವ್ವ ಎದುರಿಸಲು ನಿರ್ಧರಿಸಿದರು. ಅವರ ಬಳಿ ಕತ್ತಿ ಅಥವಾ ಈಟಿ ಇರಲಿಲ್ಲ, ಆದರೆ ಅವರು ತನ್ನ ನೆಚ್ಚಿನ ಮರದ ಒನಕೆಯನ್ನು ಗಟ್ಟಿಯಾಗಿ ಹಿಡಿದುಕೊಂಡರು. ಅವರು ಯಾರಿಗೂ ಕಾಣದಂತೆ ಕಿಂಡಿಯ ಪಕ್ಕದಲ್ಲಿ ಮೌನವಾಗಿ ನಿಂತರು. ಸಹಾಯಕ್ಕಾಗಿ ಕೂಗಿದರೆ ಶತ್ರುಗಳು ಜಾಗರೂಕರಾಗಿ ಒಮ್ಮೆಗೆ ನುಗ್ಗಬಹುದು ಎಂದು ಅವಳಿಗೆ ತಿಳಿದಿತ್ತು. ತನ್ನ ಜನರನ್ನು ಉಳಿಸಲು ಅವಳು ಒಬ್ಬಳೇ ಹೋರಾಡಲು ನಿರ್ಧರಿಸಿದಳು.", "🤫"],
        ["As the first soldier squeezed through the narrow gap, Obavva raised her heavy onake and struck him firmly on the head. He fell silently. One by one, more soldiers tried to enter through the crevice, unaware of the danger waiting inside. Each time a head appeared, Obavva used her strength to defeat them, moving the bodies away to keep the path clear for the next intruder. She fought with incredible focus and stamina, protecting the fort entirely on her own. By the time her husband returned from his meal, he was shocked to see a pile of enemy soldiers and his wife standing guard with a blood-stained pestle. Her quick thinking and bravery had stopped a massive invasion and saved the Chitradurga fort.", "ಮೊದಲ ಸೈನಿಕನು ಕಿರಿದಾದ ಕಿಂಡಿಯ ಮೂಲಕ ಒಳಗೆ ಬರುತ್ತಿದ್ದಂತೆ, ಓಬವ್ವ ತನ್ನ ಭಾರವಾದ ಒನಕೆಯನ್ನು ಎತ್ತಿ ಅವನ ತಲೆಗೆ ಬಲವಾಗಿ ಹೊಡೆದಳು. ಅವನು ಮೌನವಾಗಿ ಕೆಳಗೆ ಬಿದ್ದನು. ಅಪಾಯದ ಅರಿವಿಲ್ಲದೆ ಇನ್ನೂ ಅನೇಕ ಸೈನಿಕರು ಒಬ್ಬೊಬ್ಬರಾಗಿ ಕಿಂಡಿಯ ಮೂಲಕ ಬರಲು ಪ್ರಯತ್ನಿಸಿದರು. ಪ್ರತಿ ಬಾರಿ ಸೈನಿಕನು ತಲೆಯೆತ್ತಿದಾಗ, ಓಬವ್ವ ತನ್ನ ಶಕ್ತಿಯನ್ನು ಬಳಸಿ ಅವರನ್ನು ಸೋಲಿಸಿದಳು ಮತ್ತು ದಾರಿಯನ್ನು ಸುಗಮಗೊಳಿಸಲು ಶವಗಳನ್ನು ಪಕ್ಕಕ್ಕೆ ಸರಿಸಿದಳು. ಅವಳು ಅದ್ಭುತ ಏಕಾಗ್ರತೆ ಮತ್ತು ತಾಳ್ಮೆಯಿಂದ ಹೋರಾಡಿ, ತನ್ನ ಸ್ವಂತ ಬಲದಿಂದ ಕೋಟೆಯನ್ನು ರಕ್ಷಿಸಿದಳು. ಅವಳ ಪತಿ ಊಟ ಮುಗಿಸಿ ಹಿಂತಿರುಗಿದಾಗ, ಅಲ್ಲಿ ಬಿದ್ದಿದ್ದ ಶತ್ರು ಸೈನಿಕರ ರಾಶಿ ಮತ್ತು ರಕ್ತಸಿಕ್ತ ಒನಕೆಯೊಂದಿಗೆ ಕಾವಲು ಕಾಯುತ್ತಿದ್ದ ತನ್ನ ಹೆಂಡತಿಯನ್ನು ನೋಡಿ ಬೆಚ್ಚಿಬಿದ್ದನು. ಅವಳ ಸಮಯಪ್ರಜ್ಞೆ ಮತ್ತು ಧೈರ್ಯವು ದೊಡ್ಡ ಆಕ್ರಮಣವನ್ನು ತಡೆದು ಚಿತ್ರದುರ್ಗದ ಕೋಟೆಯನ್ನು ಉಳಿಸಿತು.", "⚔️"],
        ["Tragically, Obavva passed away shortly after her heroic act, but her legend lives on forever. Today, the narrow opening in the fort is famously called 'Onake Obavva Kindi' in her honor. She is remembered as a symbol of women's strength and patriotism in Karnataka. Her story teaches children that courage does not always need fancy weapons; it comes from a brave heart and the will to protect what is right. Every year, people visit the Chitradurga fort to see the place where an ordinary woman with a wooden pestle defeated a powerful army. Onake Obavva remains an eternal inspiration, showing us that even one person can make a difference and change the course of history through selfless bravery.", "ದುರದೃಷ್ಟವಶಾತ್, ಓಬವ್ವ ಈ ವೀರ ಕೃತ್ಯದ ಸ್ವಲ್ಪ ಸಮಯದ ನಂತರ ನಿಧನರಾದರು, ಆದರೆ ಅವರ ಸಾಹಸಗಾಥೆ ಶಾಶ್ವತವಾಗಿ ಉಳಿದಿದೆ. ಇಂದು, ಅವರ ಗೌರವಾರ್ಥವಾಗಿ ಕೋಟೆಯ ಆ ಕಿರಿದಾದ ಕಿಂಡಿಯನ್ನು 'ಒನಕೆ ಓಬವ್ವನ ಕಿಂಡಿ' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ. ಕರ್ನಾಟಕದಲ್ಲಿ ಅವರನ್ನು ಸ್ತ್ರೀ ಶಕ್ತಿ ಮತ್ತು ದೇಶಪ್ರೇಮದ ಸಂಕೇತವಾಗಿ ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ಧೈರ್ಯಕ್ಕೆ ಯಾವಾಗಲೂ ಅಲಂಕಾರಿಕ ಆಯುಧಗಳ ಅಗತ್ಯವಿಲ್ಲ, ಅದು ಧೈರ್ಯವಂತ ಹೃದಯ ಮತ್ತು ಸರಿ ಉದ್ದೇಶದಿಂದ ಬರುತ್ತದೆ ಎಂದು ಅವರ ಕಥೆ ಮಕ್ಕಳಿಗೆ ಕಲಿಸುತ್ತದೆ. ಮರದ ಒನಕೆಯನ್ನು ಹಿಡಿದ ಸಾಮಾನ್ಯ ಮಹಿಳೆ ಪ್ರಬಲ ಸೈನ್ಯವನ್ನು ಸೋಲಿಸಿದ ಸ್ಥಳವನ್ನು ನೋಡಲು ಪ್ರತಿ ವರ್ಷ ಜನರು ಚಿತ್ರದುರ್ಗದ ಕೋಟೆಗೆ ಭೇಟಿ ನೀಡುತ್ತಾರೆ. ಒನಕೆ ಓಬವ್ವ ಅವರು ನಮ್ಮೆಲ್ಲರಿಗೂ ಶಾಶ್ವತ ಸ್ಫೂರ್ತಿಯಾಗಿದ್ದಾರೆ, ಒಬ್ಬ ವ್ಯಕ್ತಿಯೂ ಕೂಡ ನಿಸ್ವಾರ್ಥ ಧೈರ್ಯದ ಮೂಲಕ ಇತಿಹಾಸವನ್ನೇ ಬದಲಾಯಿಸಬಹುದು ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟಿದ್ದಾರೆ.", "🌟"]
      ],
      quiz: [
        ["What weapon did she use?", "ಆಯುಧ?", ["Wooden pestle", "Sword", "Bow"], ["ಒನಕೆ", "ಕತ್ತಿ", "ಬಿಲ್ಲು"], 0],
        ["Which fort did she save?", "ಯಾವ ಕೋಟೆ?", ["Chitradurga", "Kittur", "Bidar"], ["ಚಿತ್ರದುರ್ಗ", "ಕಿತ್ತೂರು", "ಬೀದರ್"], 0],
      
        ['She lived in which century?', 'ಶತಮಾನ?', ['18th', '12th', '20th'], ['೧೮ನೇ', '೧೨ನೇ', '೨೦ನೇ'], 0],
        ["Her husband's name?", 'ಪತಿ?', ['Mudda Hanuma', 'Tipu', 'Hyder'], ['ಮುದ್ದ ಹನುಮ', 'ಟಿಪ್ಪು', 'ಹೈದರ್'], 0],
        ['Enemy soldiers belonged to…', 'ಶತ್ರು?', ['Hyder Ali', 'British', 'Mughals'], ['ಹೈದರ್ ಅಲಿ', 'ಬ್ರಿಟಿಷ್', 'ಮೊಘಲ್'], 0],
        ['She defended which fort?', 'ಯಾವ ಕೋಟೆ?', ['Chitradurga', 'Bidar', 'Hampi'], ['ಚಿತ್ರದುರ್ಗ', 'ಬೀದರ್', 'ಹಂಪಿ'], 0],
        ['Opening in fort wall called…', 'ಬಿಂಡಿ?', ['Kindi', 'Door', 'Window'], ['ಕಿಂಡಿ', 'ಬಾಗಿಲು', 'ಕಿಟಕಿ'], 0],
        ['Onake is used to…', 'ಒನಕೆ?', ['Pound grain', 'Cut wood', 'Carry water'], ['ಧಾನ್ಯ ಕುಟ್ಟಲು', 'ಮರ ಕಡಿಯಲು', 'ನೀರು ಸಾಗಿಸಲು'], 0],
        ['Husband was away for…', 'ಪತಿ ಎಲ್ಲಿಗೆ?', ['Lunch', 'Battle', 'Hunt'], ['ಊಟ', 'ಯುದ್ಧ', 'ಬೇಟೆ'], 0],
        ['She is a symbol of…', 'ಸಂಕೇತ?', ["Women's bravery", 'Music', 'Trade'], ['ಮಹಿಳಾ ಶೌರ್ಯ', 'ಸಂಗೀತ', 'ವ್ಯಾಪಾರ'], 0],
      ],
      memorial: ["Chitradurga Fort", "ಚಿತ್ರದುರ್ಗ ಕೋಟೆ", "Chitradurga", "ಚಿತ್ರದುರ್ಗ", "The famous fort still has the small hole where she fought.", "ಅವಳು ಹೋರಾಡಿದ ರಂಧ್ರ ಇಂದಿಗೂ ಇದೆ.", "Chitradurga Fort Obavva"],
    })],
  },
  {
    id: "dakshina-kannada", name: { en: "Dakshina Kannada", kn: "ದಕ್ಷಿಣ ಕನ್ನಡ" }, emoji: "🌊",
    heroes: [mkHero({
      id: "rani-abbakka", emoji: "👸",
      name: ["Rani Abbakka Chowta", "ರಾಣಿ ಅಬ್ಬಕ್ಕ ಚೌಟ"],
      title: ["The Fearless Queen of Ullal", "ಉಳ್ಳಾಲದ ನಿರ್ಭೀತ ರಾಣಿ"],
      era: "16th Century",
      pages: [
        ["Long ago, in the lush coastal land of Dakshina Kannada, a brave girl named Abbakka Chowta was born into the royal family of Ullal. As a Tuluva Jain princess, she was raised to be a protector of her people and their beautiful port near Mangaluru. From a young age, she learned that being a leader meant more than wearing a crown; it meant having a heart full of courage. Her family taught her the importance of independence and the strength required to defend their home from those who came across the sea. Abbakka grew up watching the rhythmic waves of the Arabian Sea, unaware that she would one day become its most formidable guardian and India’s first woman freedom fighter, standing tall against mighty foreign powers.", "ಬಹಳ ಹಿಂದೆಯೇ, ದಕ್ಷಿಣ ಕನ್ನಡದ ಕರಾವಳಿ ಪ್ರದೇಶದಲ್ಲಿ, ಅಭಕ್ಕ ಚೌಟ ಎಂಬ ಧೀರ ಬಾಲಕಿ ಉಳ್ಳಾಲದ ರಾಜಮನೆತನದಲ್ಲಿ ಜನಿಸಿದಳು. ತುಳುವ ಜೈನ ರಾಜಕುಮಾರಿಯಾಗಿ, ಅವಳು ತನ್ನ ಜನರು ಮತ್ತು ಮಂಗಳೂರಿನ ಸಮೀಪವಿರುವ ಸುಂದರವಾದ ಬಂದರನ್ನು ರಕ್ಷಿಸುವಂತೆ ಬೆಳೆದಳು. ನಾಯಕಿಯಾಗಿರುವುದು ಎಂದರೆ ಕೇವಲ ಕಿರೀಟವನ್ನು ಧರಿಸುವುದಲ್ಲ, ಅದು ಧೈರ್ಯ ತುಂಬಿದ ಹೃದಯವನ್ನು ಹೊಂದಿರುವುದು ಎಂದು ಅವಳು ಚಿಕ್ಕ ವಯಸ್ಸಿನಲ್ಲೇ ಕಲಿತಳು. ಸಮುದ್ರದ ಆಚೆಯಿಂದ ಬರುವವರಿಂದ ತಮ್ಮ ನಾಡನ್ನು ರಕ್ಷಿಸಲು ಬೇಕಾದ ಸ್ವಾತಂತ್ರ್ಯ ಮತ್ತು ಶಕ್ತಿಯ ಮಹತ್ವವನ್ನು ಅವಳ ಕುಟುಂಬವು ಅವಳಿಗೆ ಕಲಿಸಿತು. ಅಬ್ಬಕ್ಕ ಅರಬ್ಬಿ ಸಮುದ್ರದ ಅಲೆಗಳನ್ನು ನೋಡುತ್ತಾ ಬೆಳೆದಳು, ಒಂದು ದಿನ ತಾನು ಈ ಸಮುದ್ರದ ಅಪ್ರತಿಮ ರಕ್ಷಕಿಯಾಗುತ್ತೇನೆ ಮತ್ತು ವಿದೇಶಿ ಶಕ್ತಿಗಳ ವಿರುದ್ಧ ನಿಲ್ಲುವ ಭಾರತದ ಮೊದಲ ಮಹಿಳಾ ಸ್ವಾತಂತ್ರ್ಯ ಹೋರಾಟಗಾರ್ತಿಯಾಗುತ್ತೇನೆ ಎಂದು ಅವಳು ತಿಳಿದಿರಲಿಲ್ಲ.", "👸"],
        ["As the Queen of Ullal, Rani Abbakka became a master of strategy and warfare. She knew that the Portuguese, who wanted to control the spice trade, were a great threat to her kingdom. To protect her land, she didn't just rely on her own strength; she was a brilliant diplomat who forged powerful alliances with the Zamorin of Calicut and the Sultan of Bijapur. She trained both men and women to be fearless soldiers, teaching them that unity was their greatest weapon. Abbakka spent her days inspecting her defenses and preparing her people for the challenges ahead. She was not just a queen who sat on a throne, but a warrior who walked among her soldiers, ready to defend the dignity of her motherland.", "ಉಳ್ಳಾಲದ ರಾಣಿಯಾಗಿ, ಅಬ್ಬಕ್ಕ ತಂತ್ರಗಾರಿಕೆ ಮತ್ತು ಯುದ್ಧಕಲೆಯಲ್ಲಿ ಪ್ರವೀಣಳಾದಳು. ಸಾಂಬಾರ ಪದಾರ್ಥಗಳ ವ್ಯಾಪಾರವನ್ನು ನಿಯಂತ್ರಿಸಲು ಬಯಸಿದ್ದ ಪೋರ್ಚುಗೀಸರು ತಮ್ಮ ರಾಜ್ಯಕ್ಕೆ ದೊಡ್ಡ ಆಪತ್ತು ಎಂದು ಅವಳು ತಿಳಿದಿದ್ದಳು. ತನ್ನ ನಾಡನ್ನು ರಕ್ಷಿಸಲು, ಅವಳು ಕೇವಲ ತನ್ನ ಶಕ್ತಿಯನ್ನು ಮಾತ್ರ ನಂಬಲಿಲ್ಲ; ಅವಳು ಕ್ಯಾಲಿಕಟ್‌ನ ಜಾಮೋರಿನ್ ಮತ್ತು ಬಿಜಾಪುರದ ಸುಲ್ತಾನರೊಂದಿಗೆ ಪ್ರಬಲ ಮೈತ್ರಿ ಮಾಡಿಕೊಂಡ ಶ್ರೇಷ್ಠ ರಾಜತಾಂತ್ರಿಕಳಾಗಿದ್ದಳು. ಅವಳು ಪುರುಷರು ಮತ್ತು ಮಹಿಳೆಯರಿಬ್ಬರಿಗೂ ಭಯವಿಲ್ಲದ ಸೈನಿಕರಾಗಲು ತರಬೇತಿ ನೀಡಿದಳು, ಒಗ್ಗಟ್ಟೇ ಅವರ ದೊಡ್ಡ ಆಯುಧ ಎಂದು ಕಲಿಸಿದಳು. ಅಬ್ಬಕ್ಕ ತನ್ನ ರಕ್ಷಣಾ ವ್ಯವಸ್ಥೆಯನ್ನು ಪರಿಶೀಲಿಸುತ್ತಾ ಮತ್ತು ತನ್ನ ಜನರನ್ನು ಮುಂದಿನ ಸವಾಲುಗಳಿಗೆ ಸಿದ್ಧಪಡಿಸುತ್ತಾ ದಿನಗಳನ್ನು ಕಳೆದಳು. ಅವಳು ಕೇವಲ ಸಿಂಹಾಸನದ ಮೇಲೆ ಕುಳಿತ ರಾಣಿಯಾಗಿರಲಿಲ್ಲ, ತನ್ನ ಸೈನಿಕರೊಂದಿಗೆ ಹೆಜ್ಜೆ ಹಾಕುವ ಮತ್ತು ಮಾತೃಭೂಮಿಯ ಗೌರವವನ್ನು ರಕ್ಷಿಸಲು ಸಿದ್ಧರಿರುವ ಯೋಧೆಯಾಗಿದ್ದಳು.", "🏹"],
        ["The Portuguese launched many attacks on Ullal, but Rani Abbakka defied them for over forty years. During the fierce battles at sea, she introduced a terrifying secret weapon called Agnivana, or fire-arrows. When the enemy ships approached the shore, her skilled archers launched these flaming arrows, setting the massive Portuguese wooden vessels ablaze. The sight of the burning ships lighting up the night sky filled her people with hope and the invaders with fear. Despite having fewer resources than the foreign navy, Abbakka's clever tactics and the use of the Agnivana kept the invaders at bay. She proved that intelligence and localized innovation could defeat even the most advanced weapons of the time, protecting the coast of Karnataka with fire and fury.", "ಪೋರ್ಚುಗೀಸರು ಉಳ್ಳಾಲದ ಮೇಲೆ ಅನೇಕ ಬಾರಿ ದಾಳಿ ಮಾಡಿದರು, ಆದರೆ ಅಬ್ಬಕ್ಕ ರಾಣಿ ನಲವತ್ತು ವರ್ಷಗಳಿಗೂ ಹೆಚ್ಚು ಕಾಲ ಅವರನ್ನು ಎದುರಿಸಿದಳು. ಸಮುದ್ರದಲ್ಲಿ ನಡೆದ ಭೀಕರ ಯುದ್ಧಗಳ ಸಮಯದಲ್ಲಿ, ಅವಳು 'ಅಗ್ನಿಬಾಣ' ಎಂಬ ನಿಗೂಢ ಆಯುಧವನ್ನು ಪರಿಚಯಿಸಿದಳು. ಶತ್ರು ಹಡಗುಗಳು ದಡಕ್ಕೆ ಬಂದಾಗ, ಅವಳ ನೈಪುಣ್ಯವುಳ್ಳ ಬಿಲ್ಲುಗಾರರು ಈ ಉರಿಯುವ ಬಾಣಗಳನ್ನು ಬಿಟ್ಟರು, ಇದರಿಂದ ಪೋರ್ಚುಗೀಸರ ಬೃಹತ್ ಮರದ ಹಡಗುಗಳು ಬೆಂಕಿಗೆ ಆಹುತಿಯಾದವು. ರಾತ್ರಿಯ ಆಕಾಶದಲ್ಲಿ ಉರಿಯುತ್ತಿದ್ದ ಹಡಗುಗಳ ನೋಟವು ಅವಳ ಜನರಲ್ಲಿ ಭರವಸೆಯನ್ನು ಮತ್ತು ಆಕ್ರಮಣಕಾರಿಗಳಲ್ಲಿ ಭಯವನ್ನು ತುಂಬಿತು. ವಿದೇಶಿ ನೌಕಾಪಡೆಗಿಂತ ಕಡಿಮೆ ಸಂಪನ್ಮೂಲಗಳನ್ನು ಹೊಂದಿದ್ದರೂ, ಅಬ್ಬಕ್ಕಳ ಚತುರ ತಂತ್ರಗಳು ಮತ್ತು ಅಗ್ನಿಬಾಣದ ಬಳಕೆಯು ಆಕ್ರಮಣಕಾರರನ್ನು ದೂರವಿಟ್ಟಿತು. ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ಸ್ಥಳೀಯ ಆವಿಷ್ಕಾರವು ಆ ಕಾಲದ ಅತ್ಯಂತ ಸುಧಾರಿತ ಆಯುಧಗಳನ್ನು ಸಹ ಸೋಲಿಸಬಹುದು ಎಂದು ಅವಳು ಸಾಬೀತುಪಡಿಸಿದಳು.", "🔥"],
        ["Rani Abbakka’s journey was filled with bravery, but it ended with a bittersweet sacrifice. After decades of ruling with an iron will, she was eventually betrayed by those who should have stood by her side. Captured by the Portuguese and thrown into prison, the 'Fearless Queen' did not sit quietly in despair. Even behind bars, her spirit remained unbroken. She chose to fight until her last breath, choosing to die as a warrior in prison rather than live as a captured subject. Her life story teaches us that true victory is not just about winning battles, but about never surrendering one's principles and love for their country. She passed away with the same courage that she showed on the battlefield, leaving behind a legacy of absolute defiance against injustice.", "ರಾಣಿ ಅಬ್ಬಕ್ಕನ ಪ್ರಯಾಣವು ಶೌರ್ಯದಿಂದ ಕೂಡಿತ್ತು, ಆದರೆ ಅದು ಕಹಿ ಮತ್ತು ಸಿಹಿಯಾದ ತ್ಯಾಗದಿಂದ ಕೊನೆಗೊಂಡಿತು. ದಶಕಗಳ ಕಾಲ ಉಕ್ಕಿನ ಇಚ್ಛಾಶಕ್ತಿಯಿಂದ ಆಳಿದ ನಂತರ, ಅವಳು ಅಂತಿಮವಾಗಿ ಅವಳ ಜೊತೆಗಿರಬೇಕಾದವರಿಂದಲೇ ದ್ರೋಹಕ್ಕೆ ಒಳಗಾದಳು. ಪೋರ್ಚುಗೀಸರಿಂದ ಸೆರೆಹಿಡಿಯಲ್ಪಟ್ಟು ಸೆರೆಮನೆಗೆ ತಳ್ಳಲ್ಪಟ್ಟಾಗಲೂ ಈ 'ಅಭಯ ರಾಣಿ' ನಿರಾಶೆಯಿಂದ ಸುಮ್ಮನೆ ಕುಳಿತುಕೊಳ್ಳಲಿಲ್ಲ. ಸೆರೆಮನೆಯ ಕಂಬಿಗಳ ಹಿಂದೆಯೂ ಅವಳ ಆತ್ಮಸ್ಥೈರ್ಯ ಕುಗ್ಗಿರಲಿಲ್ಲ. ಅವಳು ಸೆರೆಹಿಡಿಯಲ್ಪಟ್ಟ ಪ್ರಜೆಯಾಗಿ ಬದುಕುವ ಬದಲು ಸೆರೆಮನೆಯಲ್ಲಿ ಯೋಧೆಯಾಗಿ ಸಾಯಲು ನಿರ್ಧರಿಸಿ, ತನ್ನ ಕೊನೆಯ ಉಸಿರು ಇರುವವರೆಗೂ ಹೋರಾಡಿದಳು. ನಿಜವಾದ ವಿಜಯವು ಕೇವಲ ಯುದ್ಧಗಳನ್ನು ಗೆಲ್ಲುವುದಲ್ಲ, ಬದಲಾಗಿ ಒಬ್ಬರ ತತ್ವಗಳನ್ನು ಮತ್ತು ದೇಶದ ಮೇಲಿನ ಪ್ರೀತಿಯನ್ನು ಎಂದಿಗೂ ಬಿಟ್ಟುಕೊಡದಿರುವುದು ಎಂದು ಅವಳ ಜೀವನ ಕಥೆ ನಮಗೆ ಕಲಿಸುತ್ತದೆ. ಅವಳು ಯುದ್ಧಭೂಮಿಯಲ್ಲಿ ತೋರಿಸಿದಂತೆಯೇ ಅದೇ ಧೈರ್ಯದೊಂದಿಗೆ ನಿಧನರಾದರು.", "⚔️"],
        ["Today, Rani Abbakka Chowta is remembered as a true daughter of the soil and a legendary hero of Karnataka. Every year, people celebrate her memory through festivals and songs that tell the story of the first woman to wave the flag of freedom against European powers. Her statue stands tall, reminding every child that courage knows no gender and that one should always protect their heritage. She is a symbol of Dakshina Kannada’s pride and India’s indomitable spirit. As children listen to the tales of the Queen who used fire-arrows and outsmarted empires, they learn that with bravery, unity, and a love for one's land, anyone can make a difference in history. Rani Abbakka lives on in the waves of the Arabian Sea and the hearts of her people.", "ಇಂದು, ರಾಣಿ ಅಬ್ಬಕ್ಕ ಚೌಟ ಅವರನ್ನು ಮಣ್ಣಿನ ನಿಜವಾದ ಮಗಳು ಮತ್ತು ಕರ್ನಾಟಕದ ದಂತಕಥೆಯ ವೀರವನಿತೆಯಾಗಿ ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ಯುರೋಪಿಯನ್ ಶಕ್ತಿಗಳ ವಿರುದ್ಧ ಸ್ವಾತಂತ್ರ್ಯದ ಧ್ವಜವನ್ನು ಹಾರಿಸಿದ ಮೊದಲ ಮಹಿಳೆಯ ಕಥೆಯನ್ನು ಹೇಳುವ ಹಬ್ಬಗಳು ಮತ್ತು ಹಾಡುಗಳ ಮೂಲಕ ದಶಕಗಳಿಂದ ಅವಳನ್ನು ಸ್ಮರಿಸಲಾಗುತ್ತಿದೆ. ಅವಳ ಪ್ರತಿಮೆಯು ಎತ್ತರವಾಗಿ ನಿಂತಿದ್ದು, ಧೈರ್ಯಕ್ಕೆ ಲಿಂಗಭೇದವಿಲ್ಲ ಮತ್ತು ಪ್ರತಿಯೊಬ್ಬರೂ ತಮ್ಮ ಪರಂಪರೆಯನ್ನು ರಕ್ಷಿಸಬೇಕು ಎಂದು ಪ್ರತಿಯೊಂದು ಮಗುವಿಗೂ ನೆನಪಿಸುತ್ತದೆ. ಅವಳು ದಕ್ಷಿಣ ಕನ್ನಡದ ಹೆಮ್ಮೆ ಮತ್ತು ಭಾರತದ ಅದಮ್ಯ ಚೇತನದ ಸಂಕೇತ. ಅಗ್ನಿಬಾಣಗಳನ್ನು ಬಳಸಿ ಸಾಮ್ರಾಜ್ಯಗಳನ್ನು ಸೋಲಿಸಿದ ರಾಣಿಯ ಕಥೆಗಳನ್ನು ಮಕ್ಕಳು ಕೇಳುತ್ತಿರುವಾಗ, ಧೈರ್ಯ, ಒಗ್ಗಟ್ಟು ಮತ್ತು ನಾಡಿನ ಮೇಲಿನ ಪ್ರೀತಿಯಿಂದ ಯಾರು ಬೇಕಾದರೂ ಇತಿಹಾಸದಲ್ಲಿ ಬದಲಾವಣೆ ತರಬಹುದು ಎಂದು ಅವರು ಕಲಿಯುತ್ತಾರೆ. ರಾಣಿ ಅಬ್ಬಕ್ಕ ಅರಬ್ಬಿ ಸಮುದ್ರದ ಅಲೆಗಳಲ್ಲಿ ಮತ್ತು ತನ್ನ ಜನರ ಹೃದಯದಲ್ಲಿ ಅಮರಳಾಗಿದ್ದಾಳೆ.", "🇮🇳"]
      ],
      quiz: [
        ["Whom did she fight?", "ಯಾರ ವಿರುದ್ಧ?", ["Portuguese", "British", "French"], ["ಪೋರ್ಚುಗೀಸರು", "ಬ್ರಿಟಿಷರು", "ಫ್ರೆಂಚರು"], 0],
        ["She ruled…", "ರಾಜ್ಯ?", ["Ullal", "Hampi", "Mysuru"], ["ಉಳ್ಳಾಲ", "ಹಂಪಿ", "ಮೈಸೂರು"], 0],
      
        ['She belonged to which faith?', 'ಧರ್ಮ?', ['Jain', 'Hindu', 'Muslim'], ['ಜೈನ', 'ಹಿಂದೂ', 'ಮುಸ್ಲಿಂ'], 0],
        ['Royal family of…', 'ರಾಜವಂಶ?', ['Chowta', 'Tuluva', 'Hoysala'], ['ಚೌಟ', 'ತುಳುವ', 'ಹೊಯ್ಸಳ'], 0],
        ['She fought for how many years?', 'ಎಷ್ಟು ವರ್ಷ?', ['40+', '5', '100'], ['೪೦+', '೫', '೧೦೦'], 0],
        ['She used what fire weapon?', 'ಬೆಂಕಿ ಆಯುಧ?', ['Fire arrows (Agnivana)', 'Cannon', 'Sword'], ['ಅಗ್ನಿಬಾಣ', 'ಫಿರಂಗಿ', 'ಕತ್ತಿ'], 0],
        ['She ruled from…', 'ಆಳ್ವಿಕೆ?', ['Ullal', 'Hampi', 'Mysuru'], ['ಉಳ್ಳಾಲ', 'ಹಂಪಿ', 'ಮೈಸೂರು'], 0],
        ['Her enemy controlled…', 'ಶತ್ರು ನಿಯಂತ್ರಣ?', ['Spice trade', 'Gold', 'Silk'], ['ಸಂಬಾರ ವ್ಯಾಪಾರ', 'ಚಿನ್ನ', 'ರೇಷ್ಮೆ'], 0],
        ['She was eventually…', 'ಅಂತ್ಯ?', ['Betrayed', 'Crowned', 'Married'], ['ವಂಚಿಸಲ್ಪಟ್ಟಳು', 'ಪಟ್ಟಾಭಿಷೇಕ', 'ವಿವಾಹ'], 0],
        ['Her district?', 'ಜಿಲ್ಲೆ?', ['Dakshina Kannada', 'Udupi', 'Bidar'], ['ದಕ್ಷಿಣ ಕನ್ನಡ', 'ಉಡುಪಿ', 'ಬೀದರ್'], 0],
      ],
      memorial: ["Rani Abbakka Statue", "ರಾಣಿ ಅಬ್ಬಕ್ಕ ಪ್ರತಿಮೆ", "Ullal, Mangaluru", "ಉಳ್ಳಾಲ", "A grand statue near the Ullal sea-shore.", "ಉಳ್ಳಾಲ ಕಡಲತೀರದ ಪ್ರತಿಮೆ.", "Rani Abbakka statue Ullal"],
    })],
  },
  {
    id: "davanagere", name: { en: "Davanagere", kn: "ದಾವಣಗೆರೆ" }, emoji: "🥞",
    heroes: [mkHero({
      id: "j-h-patel", emoji: "🎤",
      name: ["J. H. Patel", "ಜೆ. ಎಚ್. ಪಟೇಲ್"],
      title: ["People's Chief Minister", "ಜನರ ಮುಖ್ಯಮಂತ್ರಿ"],
      era: "1930 – 2000",
      pages: [
        ["In the green village of Karignur in the Davanagere district, a bright boy named Jayadevappa Halappa Patel was born in 1930. Growing up in the heart of Karnataka, he loved the simple life of the countryside and the stories of hardworking people. Known to everyone as J.H. Patel, he was a curious child who always had a smile on his face. He watched how people helped one another in the fields and learned that every person, no matter how small, deserved respect. His childhood in the rural landscape shaped his heart, filling it with a deep love for his land and a desire to make life better for everyone in his community.", "ದಾವಣಗೆರೆ ಜಿಲ್ಲೆಯ ಹಸಿರು ಗ್ರಾಮವಾದ ಕರೀಗನೂರಿನಲ್ಲಿ, ಜಯದೇವಪ್ಪ ಹಾಲಪ್ಪ ಪಟೇಲ್ ಎಂಬ ಬುದ್ಧಿವಂತ ಹುಡುಗ ೧೯೩೦ರಲ್ಲಿ ಜನಿಸಿದನು. ಕರ್ನಾಟಕದ ಹೃದಯಭಾಗದಲ್ಲಿ ಬೆಳೆದ ಅವನು, ಹಳ್ಳಿಯ ಸರಳ ಜೀವನ ಮತ್ತು ಕಷ್ಟಪಟ್ಟು ದುಡಿಯುವ ಜನರ ಕಥೆಗಳನ್ನು ಪ್ರೀತಿಸುತ್ತಿದ್ದನು. ಎಲ್ಲರಿಗೂ ಜೆ.ಎಚ್. ಪಟೇಲ್ ಎಂದೇ ಪರಿಚಿತನಾಗಿದ್ದ ಈತ ಯಾವಾಗಲೂ ನಗುಮುಖದ ಕುತೂಹಲದ ಹಾಲಕನಾಗಿದ್ದನು. ಹೊಲಗಳಲ್ಲಿ ಜನರು ಒಬ್ಬರಿಗೊಬ್ಬರು ಸಹಾಯ ಮಾಡುವುದನ್ನು ಗಮನಿಸುತ್ತಿದ್ದ ಅವನು, ಪ್ರತಿಯೊಬ್ಬ ವ್ಯಕ್ತಿಯೂ ಗೌರವಕ್ಕೆ ಪಾತ್ರರು ಎಂಬ ಪಾಠವನ್ನು ಕಲಿತನು. ಗ್ರಾಮೀಣ ಪರಿಸರದ ಅವನ ಬಾಲ್ಯವು ಅವನ ಹೃದಯದಲ್ಲಿ ತನ್ನ ಭೂಮಿಯ ಮೇಲೆ ಆಳವಾದ ಪ್ರೀತಿಯನ್ನು ಮತ್ತು ಸಮಾಜದ ಪ್ರತಿಯೊಬ್ಬರ ಜೀವನವನ್ನು ಉತ್ತಮಗೊಳಿಸುವ ಬಯಕೆಯನ್ನು ತುಂಬಿತು.", "🌾"],
        ["As J.H. Patel grew older, he wanted to use his voice to stand up for justice. He studied hard and became a clever lawyer. During his youth, he met people who believed in a big idea called socialism, which means making sure everyone gets a fair share of the world’s treasures. He became a devoted follower of the thinker Ram Manohar Lohia. Patel realized that words could be more powerful than anything else if used kindly. He practiced his speaking skills, learning how to use humor and wit to explain difficult problems. He became a champion for the farmers and laborers, showing them that a lawyer could be a true friend to the common people.", "ಜೆ.ಎಚ್. ಪಟೇಲರು ಬೆಳೆಯುತ್ತಿದ್ದಂತೆ, ನ್ಯಾಯಕ್ಕಾಗಿ ಹೋರಾಡಲು ತಮ್ಮ ಧ್ವನಿಯನ್ನು ಬಳಸಲು ಬಯಸಿದರು. ಅವರು ಶ್ರದ್ಧೆಯಿಂದ ವ್ಯಾಸಂಗ ಮಾಡಿ ಚತುರ ವಕೀಲರಾದರು. ತಮ್ಮ ಯೌವನದಲ್ಲಿ, ಅವರು ಸಮಾಜವಾದ ಎಂಬ ದೊಡ್ಡ ಸಿದ್ಧಾಂತವನ್ನು ನಂಬುವ ಜನರನ್ನು ಭೇಟಿಯಾದರು, ಇದರರ್ಥ ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಸಮಾನ ಪಾಲು ಸಿಗಬೇಕೆಂಬುದು. ಅವರು ಚಿಂತಕ ರಾಮಮನೋಹರ ಲೋಹಿಯಾರ ನಿಷ್ಠಾವಂತ ಅನುಯಾಯಿಯಾದರು. ದಯೆಯಿಂದ ಮಾತನಾಡಿದರೆ ಮಾತುಗಳು ಎಲ್ಲದಕ್ಕಿಂತ ಶಕ್ತಿಯುತವಾಗಬಲ್ಲವು ಎಂದು ಪಟೇಲರು ಅರಿತುಕೊಂಡರು. ಕಷ್ಟದ ಸಮಸ್ಯೆಗಳನ್ನು ವಿವರಿಸಲು ಹಾಸ್ಯ ಮತ್ತು ಚತುರತೆಯನ್ನು ಹೇಗೆ ಬಳಸಬೇಕೆಂದು ಅವರು ಕರಗತ ಮಾಡಿಕೊಂಡರು. ರೈತರು ಮತ್ತು ಕಾರ್ಮಿಕರ ಪರವಾಗಿ ನಿಂತ ಅವರು, ವಕೀಲರು ಸಾಮಾನ್ಯ ಜನರ ನಿಜವಾದ ಸ್ನೇಹಿತನಾಗಬಲ್ಲರು ಎಂದು ತೋರಿಸಿಕೊಟ್ಟರು.", "⚖️"],
        ["Patel's journey took him from the courtrooms to the big stage of leadership. He was elected as a member of the legislative assembly from Channagiri. People loved to listen to him speak because he never used fancy or confusing words. Instead, he spoke plainly and honestly, often making the whole room laugh with his quick wit. He served as a minister in many different cabinets, always focusing on how to help the state grow. Even when things were difficult, he remained secular, meaning he treated people of all religions with the same kindness and fairness. His ability to connect with everyone through his legendary oratory made him a very special leader in Karnataka.", "ಪಟೇಲರ ಪಯಣವು ನ್ಯಾಯಾಲಯದಿಂದ ನಾಯಕತ್ವದ ದೊಡ್ಡ ವೇದಿಕೆಯತ್ತ ಸಾಗಿತು. ಅವರು ಚನ್ನಗಿರಿಯಿಂದ ವಿಧಾನಸಭಾ ಸದಸ್ಯರಾಗಿ ಆಯ್ಕೆಯಾದರು. ಜನರು ಅವರ ಭಾಷಣಗಳನ್ನು ಕೇಳಲು ಇಷ್ಟಪಡುತ್ತಿದ್ದರು ಏಕೆಂದರೆ ಅವರು ಎಂದಿಗೂ ಗೊಂದಲಕಾರಿ ಪದಗಳನ್ನು ಬಳಸುತ್ತಿರಲಿಲ್ಲ. ಬದಲಾಗಿ, ಅವರು ಸರಳವಾಗಿ ಮತ್ತು ಪ್ರಾಮಾಣಿಕವಾಗಿ ಮಾತನಾಡುತ್ತಿದ್ದರು, ತಮ್ಮ ಚತುರ ಮಾತುಗಳಿಂದ ಎಲ್ಲರನ್ನೂ ನಗಿಸುತ್ತಿದ್ದರು. ಅವರು ಅನೇಕ ಸಚಿವ ಸಂಪುಟಗಳಲ್ಲಿ ಮಂತ್ರಿಯಾಗಿ ಸೇವೆ ಸಲ್ಲಿಸಿದರು, ಯಾವಾಗಲೂ ರಾಜ್ಯದ ಅಭಿವೃದ್ಧಿಯತ್ತ ಗಮನ ಹರಿಸಿದರು. ಪರಿಸ್ಥಿತಿ ಕಷ್ಟವಾಗಿದ್ದಾಗಲೂ ಅವರು ಜಾತ್ಯತೀತವಾಗಿ ಉಳಿದರು, ಅಂದರೆ ಎಲ್ಲಾ ಧರ್ಮದ ಜನರನ್ನು ಸಮಾನ ಪ್ರೀತಿ ಮತ್ತು ನ್ಯಾಯದಿಂದ ನಡೆಸಿಕೊಂಡರು. ತಮ್ಮ ಅದ್ಭುತ ವಾಗ್ಪಟುತ್ವದ ಮೂಲಕ ಎಲ್ಲರನ್ನೂ ತಲುಪುವ ಅವರ ಸಾಮರ್ಥ್ಯವು ಅವರನ್ನು ಕರ್ನಾಟಕದ ವಿಶೇಷ ನಾಯಕನನ್ನಾಗಿ ಮಾಡಿತು.", "🎤"],
        ["In 1996, a very big honor came to J.H. Patel when he became the 15th Chief Minister of Karnataka. Leading the Janata Dal party, he worked from 1996 to 1999 to bring progress to the state. He was often called the 'People's Chief Minister' because he never forgot his roots in the village. Even from his high office, he remained approachable and simple. He worked on policies that helped the common man and made sure the government listened to the voices of the poor. His time as leader was marked by his unique style of balancing serious work with a lighthearted spirit, proving that a leader can be both powerful and full of joy.", "೧೯೯೬ರಲ್ಲಿ, ಜೆ.ಎಚ್. ಪಟೇಲರು ಕರ್ನಾಟಕದ ೧೫ನೇ ಮುಖ್ಯಮಂತ್ರಿಯಾದಾಗ ಅವರಿಗೆ ದೊಡ್ಡ ಗೌರವ ಲಭಿಸಿತು. ಜನತಾ ದಳ ಪಕ್ಷದ ನಾಯಕರಾಗಿ, ಅವರು ೧೯೯೬ ರಿಂದ ೧೯೯೯ ರವರೆಗೆ ರಾಜ್ಯದ ಪ್ರಗತಿಗಾಗಿ ಕೆಲಸ ಮಾಡಿದರು. ತಮ್ಮ ಹಳ್ಳಿಯ ಬೇರುಗಳನ್ನು ಎಂದಿಗೂ ಮರೆಯದ ಕಾರಣ ಅವರನ್ನು 'ಜನರ ಮುಖ್ಯಮಂತ್ರಿ' ಎಂದು ಕರೆಯಲಾಗುತ್ತಿತ್ತು. ಉನ್ನತ ಅಧಿಕಾರದಲ್ಲಿದ್ದರೂ ಅವರು ಸರಳವಾಗಿ ಮತ್ತು ಜನರಿಗೆ ಸುಲಭವಾಗಿ ಸಿಗುವಂತಿದ್ದರು. ಅವರು ಸಾಮಾನ್ಯ ಜನರಿಗೆ ಸಹಾಯ ಮಾಡುವ ನೀತಿಗಳ ಮೇಲೆ ಕೆಲಸ ಮಾಡಿದರು ಮತ್ತು ಸರ್ಕಾರವು ಬಡವರ ಧ್ವನಿಯನ್ನು ಕೇಳುವಂತೆ ಮಾಡಿದರು. ಗಂಭೀರವಾದ ಕೆಲಸವನ್ನು ಹಾಸ್ಯ ಪ್ರವೃತ್ತಿಯೊಂದಿಗೆ ಸಮತೋಲನಗೊಳಿಸಿದ ಅವರ ವಿಶಿಷ್ಟ ಶೈಲಿಯು, ಒಬ್ಬ ನಾಯಕನು ಶಕ್ತಿಯುತ ಮತ್ತು ಸಂತೋಷಭರಿತನಾಗಿರಬಹುದು ಎಂದು ಸಾಬೀತುಪಡಿಸಿತು.", "🏛️"],
        ["Though he passed away in the year 2000, J.H. Patel’s legacy lives on in the hearts of the people of Karnataka. He is remembered not just as a politician, but as a wise mentor who guided many future leaders. Today, children learn about his witty stories and his brave stand for equality. He showed us that being a leader is about being honest, keeping a sense of humor, and caring for every citizen regardless of their background. His life tells us that even a boy from a small village like Karignur can grow up to guide a whole state with wisdom, laughter, and a very kind heart for the people.", "ಜೆ.ಎಚ್. ಪಟೇಲರು ೨೦೦೦ನೇ ಇಸವಿಯಲ್ಲಿ ನಿಧನರಾದರೂ, ಅವರ ನೆನಪು ಕರ್ನಾಟಕದ ಜನರ ಹೃದಯದಲ್ಲಿ ಅಚ್ಚಳಿಯದೆ ಉಳಿದಿದೆ. ಅವರು ಕೇವಲ ರಾಜಕಾರಣಿಯಾಗಿ ಮಾತ್ರವಲ್ಲದೆ, ಅನೇಕ ಮುಂದಿನ ನಾಯಕರಿಗೆ ಮಾರ್ಗದರ್ಶನ ನೀಡಿದ ಬುದ್ಧಿವಂತ ಗುರುವಾಗಿಯೂ ನೆನಪಿಸಿಕೊಳ್ಳಲ್ಪಡುತ್ತಾರೆ. ಇಂದು ಮಕ್ಕಳು ಅವರ ಚತುರ ಕಥೆಗಳು ಮತ್ತು ಸಮಾನತೆಗಾಗಿ ಅವರು ತೆಗೆದುಕೊಂಡ ಕೆಚ್ಚೆದೆಯ ನಿಲುವುಗಳ ಬಗ್ಗೆ ಕಲಿಯುತ್ತಾರೆ. ನಾಯಕತ್ವ ಎಂದರೆ ಪ್ರಾಮಾಣಿಕವಾಗಿರುವುದು, ಹಾಸ್ಯ ಪ್ರವೃತ್ತಿಯನ್ನು ಹೊಂದಿರುವುದು ಮತ್ತು ಹಿನ್ನೆಲೆಯನ್ನು ಲೆಕ್ಕಿಸದೆ ಪ್ರತಿಯೊಬ್ಬ ಪ್ರಜೆಯನ್ನು ಪ್ರೀತಿಸುವುದು ಎಂದು ಅವರು ನಮಗೆ ತೋರಿಸಿಕೊಟ್ಟರು. ಕರೀಗನೂರಿನಂತಹ ಸಣ್ಣ ಹಳ್ಳಿಯ ಹುಡುಗನೂ ಕೂಡ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ದಯೆಯ ಹೃದಯದಿಂದ ಇಡೀ ರಾಜ್ಯವನ್ನು ಮುನ್ನಡೆಸಬಹುದು ಎಂದು ಅವರ ಜೀವನ ನಮಗೆ ತಿಳಿಸುತ್ತದೆ.", "🌟"]
      ],
      quiz: [
        ["His position?", "ಹುದ್ದೆ?", ["Chief Minister", "President", "Speaker"], ["ಮುಖ್ಯಮಂತ್ರಿ", "ರಾಷ್ಟ್ರಪತಿ", "ಸಭಾಧ್ಯಕ್ಷ"], 0],
        ["He was famous for his…", "ಪ್ರಸಿದ್ಧಿ?", ["Speeches", "Paintings", "Songs"], ["ಭಾಷಣ", "ಚಿತ್ರ", "ಹಾಡು"], 0],
      
        ['Born in year…', 'ಜನ್ಮ ವರ್ಷ?', ['1930', '1900', '1950'], ['೧೯೩೦', '೧೯೦೦', '೧೯೫೦'], 0],
        ['Birth village?', 'ಗ್ರಾಮ?', ['Karignur', 'Hampi', 'Bidar'], ['ಕರಿಗನೂರು', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['Profession?', 'ವೃತ್ತಿ?', ['Lawyer', 'Doctor', 'Engineer'], ['ವಕೀಲ', 'ವೈದ್ಯ', 'ಎಂಜಿನಿಯರ್'], 0],
        ['CM number of Karnataka?', 'ಎಷ್ಟನೇ ಮುಖ್ಯಮಂತ್ರಿ?', ['15th', '2nd', '20th'], ['೧೫ನೇ', '೨ನೇ', '೨೦ನೇ'], 0],
        ['Became CM in year…', 'ವರ್ಷ?', ['1996', '1980', '2010'], ['೧೯೯೬', '೧೯೮೦', '೨೦೧೦'], 0],
        ['Party?', 'ಪಕ್ಷ?', ['Janata Dal', 'BJP', 'Congress'], ['ಜನತಾ ದಳ', 'ಬಿಜೆಪಿ', 'ಕಾಂಗ್ರೆಸ್'], 0],
        ['Constituency?', 'ಕ್ಷೇತ್ರ?', ['Channagiri', 'Hampi', 'Bidar'], ['ಚನ್ನಗಿರಿ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Davanagere', 'Mysuru', 'Bidar'], ['ದಾವಣಗೆರೆ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
      ],
      memorial: ["J. H. Patel Memorial", "ಪಟೇಲ್ ಸ್ಮಾರಕ", "Karignur, Davanagere", "ಕರಿಗನೂರು", "His birth village honours his life.", "ಅವರ ಜನ್ಮ ಗ್ರಾಮ.", "JH Patel memorial Karignur"],
    })],
  },
  {
    id: "dharwad", name: { en: "Dharwad", kn: "ಧಾರವಾಡ" }, emoji: "🎶",
    heroes: [mkHero({
      id: "bhimsen-joshi", emoji: "🎤",
      name: ["Pandit Bhimsen Joshi", "ಪಂಡಿತ್ ಭೀಮಸೇನ್ ಜೋಶಿ"],
      title: ["Legend of Hindustani Music", "ಹಿಂದೂಸ್ತಾನಿ ಸಂಗೀತದ ದಂತಕಥೆ"],
      era: "1922 – 2011",
      pages: [
        ["In the small town of Gadag in the Dharwad district of Karnataka, a young boy named Bhimsen Joshi was born in 1922. Even as a small child, Bhimsen was deeply enchanted by music. Whenever he heard the sound of a gramophone or a local musician singing, he would stop everything and listen with wide eyes. His father was a teacher, but Bhimsen’s heart was set on a different path. He didn't just want to listen to songs; he felt a burning desire to learn the magical secrets of Hindustani classical music himself. This passion grew so strong that it defined his entire childhood and set the stage for an incredible journey across India.", "ಕರ್ನಾಟಕದ ಧಾರವಾಡ ಜಿಲ್ಲೆಯ ಗದಗ ಎಂಬ ಸಣ್ಣ ಪಟ್ಟಣದಲ್ಲಿ ಒಬ್ಬ ಬಾಲಕ ಜನಿಸಿದನು, ಅವನ ಹೆಸರು ಭೀಮಸೇನ್ ಜೋಶಿ. ಚಿಕ್ಕಂದಿನಿಂದಲೂ ಭೀಮಸೇನನಿಗೆ ಸಂಗೀತದ ಮೇಲೆ ಅಪಾರ ಪ್ರೀತಿ ಇತ್ತು. ಗ್ರಾಮಫೋನ್‌ನ ಶಬ್ದವಾಗಲಿ ಅಥವಾ ಸ್ಥಳೀಯ ಗಾಯಕರ ಹಾಡಾಗಲಿ ಕೇಳಿದಾಗ ಅವರು ಎಲ್ಲವನ್ನೂ ಮರೆತು ಕಣ್ಣರಳಿಸಿ ಕೇಳುತ್ತಿದ್ದರು. ಅವರ ತಂದೆ ಶಿಕ್ಷಕರಾಗಿದ್ದರು, ಆದರೆ ಭೀಮಸೇನನ ಮನಸ್ಸು ಬೇರೆಯದೇ ಹಾದಿಯಲ್ಲಿತ್ತು. ಅವರು ಕೇವಲ ಹಾಡುಗಳನ್ನು ಕೇಳಲು ಬಯಸಲಿಲ್ಲ; ತಾವೇ ಸ್ವತಃ ಹಿಂದೂಸ್ತಾನಿ ಶಾಸ್ತ್ರೀಯ ಸಂಗೀತದ ರಹಸ್ಯಗಳನ್ನು ಕಲಿಯಬೇಕೆಂಬ ಹಂಬಲ ಅವರಲ್ಲಿತ್ತು. ಈ ತೀವ್ರವಾದ ಹಂಬಲವು ಅವರ ಬಾಲ್ಯವನ್ನು ರೂಪಿಸಿತು ಮತ್ತು ಭಾರತದಾದ್ಯಂತ ಅದ್ಭುತ ಪ್ರಯಾಣಕ್ಕೆ ನಾಂದಿ ಹಾಡಿತು.", "🏠"],
        ["Most eleven-year-old children are busy playing games, but Bhimsen was different. Driven by a desperate search for a music teacher or guru, he actually ran away from home alone! He traveled far and wide across North India, sometimes traveling on trains without a ticket and even working small jobs just to find someone who could teach him the Kirana gharana style. After several years of searching and surviving on humble means, his journey finally led him back to his roots. He found his master, the great Sawai Gandharva, in Kundgol. His teacher agreed to train him, but the lessons were hard and required many hours of practice every single day.", "ಸಾಮಾನ್ಯವಾಗಿ ಹನ್ನೊಂದು ವರ್ಷದ ಮಕ್ಕಳು ಆಟವಾಡುತ್ತಿರುತ್ತಾರೆ, ಆದರೆ ಭೀಮಸೇನ ವಿಭಿನ್ನವಾಗಿ ಬೆಳೆದರು. ಸಂಗೀತ ಗುರುವಿನ ಹುಡುಕಾಟದಲ್ಲಿ ಅವರು ತಮ್ಮ ಹನ್ನೊಂದನೇ ವಯಸ್ಸಿನಲ್ಲೇ ಮನೆಯಿಂದ ಹೊರಟರು! ಕಿರಾಣ ಘರಾನಾ ಶೈಲಿಯನ್ನು ಕಲಿಸುವ ಗುರುವಿಗಾಗಿ ಅವರು ಉತ್ತರ ಭಾರತದಾದ್ಯಂತ ಸಂಚರಿಸಿದರು. ಕೆಲವೊಮ್ಮೆ ಟಿಕೆಟ್ ಇಲ್ಲದೆ ರೈಲಿನಲ್ಲಿ ಪ್ರಯಾಣಿಸುತ್ತಾ, ಸಣ್ಣಪುಟ್ಟ ಕೆಲಸಗಳನ್ನು ಮಾಡುತ್ತಾ ಅಲೆದರು. ಹಲವಾರು ವರ್ಷಗಳ ಕಠಿಣ ಹುಡುಕಾಟದ ನಂತರ, ಅವರು ಕುಂದಗೋಳದಲ್ಲಿ ತಮ್ಮ ಗುರುಗಳಾದ ಸವಾಯಿ ಗಂಧರ್ವರನ್ನು ಕಂಡುಕೊಂಡರು. ಅವರ ಗುರುಗಳು ತರಬೇತಿ ನೀಡಲು ಒಪ್ಪಿಕೊಂಡರು, ಆದರೆ ಶಿಕ್ಷಣವು ಅತ್ಯಂತ ಕಠಿಣವಾಗಿತ್ತು ಮತ್ತು ಪ್ರತಿದಿನ ಹಲವು ಗಂಟೆಗಳ ಕಾಲ ಕಠಿಣ ಅಭ್ಯಾಸ ಮಾಡಬೇಕಾಗಿತ್ತು.", "🚂"],
        ["Bhimsen settled between Dharwad and Pune, dedicating his entire life to mastering his voice. He practiced with such energy and devotion that he could sing for hours without getting tired. People began to notice his powerful and soulful voice. He became a grand master of the 'khyal' style, but he was also famous for singing beautiful bhajans and abhangs that moved listeners to tears. His 'Santvani' performances, which were collections of devotional songs, became legendary across Karnataka and Maharashtra. He proved that classical music was not just for experts, but a gift that could be enjoyed by every person, young or old, through simple and heartfelt devotion.", "ಭೀಮಸೇನರು ಧಾರವಾಡ ಮತ್ತು ಪುಣೆಯ ನಡುವೆ ನೆಲೆಸಿದರು, ತಮ್ಮ ಇಡೀ ಜೀವನವನ್ನು ಗಾಯನಕ್ಕಾಗಿ ಮುಡಿಪಾಗಿಟ್ಟರು. ಅವರು ಅಪಾರ ಶಕ್ತಿ ಮತ್ತು ಭಕ್ತಿಯಿಂದ ಅಭ್ಯಾಸ ಮಾಡುತ್ತಿದ್ದರು, ಇದರಿಂದಾಗಿ ಅವರು ಸುಸ್ತಾಗದೆ ಗಂಟೆಗಟ್ಟಲೆ ಹಾಡುತ್ತಿದ್ದರು. ಅವರ ಶಕ್ತಿಯುತ ಮತ್ತು ಭಾವಪೂರ್ಣ ಧ್ವನಿಯನ್ನು ಜನರು ಗುರುತಿಸಲು ಪ್ರಾರಂಭಿಸಿದರು. ಅವರು 'ಖಯಾಲ್' ಶೈಲಿಯ ಮಹಾನ್ ಗಾಯಕರಾದರು, ಆದರೆ ಭಜನೆಗಳು ಮತ್ತು ಅಭಂಗಗಳನ್ನು ಹಾಡುವುದರಲ್ಲಿಯೂ ಅವರು ಪ್ರಸಿದ್ಧರಾಗಿದ್ದರು. ಅವರ 'ಸಂತವಾಣಿ' ಪ್ರದರ್ಶನಗಳು ಕರ್ನಾಟಕ ಮತ್ತು ಮಹಾರಾಷ್ಟ್ರದಾದ್ಯಂತ ದಂತಕಥೆಯಾದವು. ಶಾಸ್ತ್ರೀಯ ಸಂಗೀತವು ಕೇವಲ ಪರಿಣಿತರಿಗೆ ಮಾತ್ರವಲ್ಲ, ಸರಳ ಭಕ್ತಿಯ ಮೂಲಕ ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ತಲುಪಬಹುದು ಎಂದು ಅವರು ಸಾಬೀತುಪಡಿಸಿದರು.", "🎤"],
        ["In 1988, Pandit Bhimsen Joshi’s voice echoed across every television screen in India. He sang the iconic opening lines of 'Mile Sur Mera Tumhara,' a song meant to bring all Indians together regardless of their language or background. This song made him a household name even among children who didn't know classical music. Because of his incredible contribution to music, he received the highest honors a citizen can get. He was awarded the Sangeet Natak Akademi award and the Padma Vibhushan. Finally, in 2008, he was honored with the Bharat Ratna, India's highest civilian award, becoming only the second musician in history to receive this prestigious title.", "೧೯೮೮ ರಲ್ಲಿ, ಪಂಡಿತ್ ಭೀಮಸೇನ್ ಜೋಶಿಯವರ ಧ್ವನಿಯು ಭಾರತದ ಪ್ರತಿಯೊಂದು ದೂರದರ್ಶನದಲ್ಲಿ ಮೊಳಗಿತು. ಅವರು 'ಮಿಲೆ ಸುರ್ ಮೇರಾ ತುಮ್ಹಾರಾ' ಎಂಬ ಹಾಡಿನ ಆರಂಭಿಕ ಸಾಲುಗಳನ್ನು ಹಾಡಿದರು, ಇದು ಭಾರತೀಯರೆಲ್ಲರನ್ನು ಒಗ್ಗೂಡಿಸುವ ಕರೆಯಾಗಿತ್ತು. ಈ ಹಾಡು ಅವರನ್ನು ಶಾಸ್ತ್ರೀಯ ಸಂಗೀತ ತಿಳಿಯದ ಮಕ್ಕಳಿಗೂ ಪರಿಚಿತವಾಗುವಂತೆ ಮಾಡಿತು. ಸಂಗೀತ ಕ್ಷೇತ್ರಕ್ಕೆ ಅವರು ನೀಡಿದ ಅಪಾರ ಕೊಡುಗೆಯನ್ನು ಗುರುತಿಸಿ ಅವರಿಗೆ ಪದ್ಮ ವಿಭೂಷಣ ಮತ್ತು ಕೇಂದ್ರ ಸಂಗೀತ ನಾಟಕ ಅಕಾಡೆಮಿ ಪ್ರಶಸ್ತಿಗಳನ್ನು ನೀಡಲಾಯಿತು. ಅಂತಿಮವಾಗಿ, ೨೦೦೮ ರಲ್ಲಿ ಅವರಿಗೆ ಭಾರತದ ಅತ್ಯುನ್ನತ ನಾಗರಿಕ ಗೌರವವಾದ 'ಭಾರತ ರತ್ನ' ನೀಡಿ ಗೌರವಿಸಲಾಯಿತು.", "🇮🇳"],
        ["Pandit Bhimsen Joshi passed away in 2011, but his legacy lives on through his music and the Sawai Gandharva music festival he started. He remains a shining star of Karnataka and an inspiration for every child who has a big dream and the courage to follow it. He showed the world that with hard work, patience, and love for one's art, a boy from a small town in Gadag can reach the very top of the world. Even today, when we hear his deep voice singing about unity or devotion, we remember the legend who never stopped searching for the perfect melody. His life teaches us to always listen to our hearts.", "ಪಂಡಿತ್ ಭೀಮಸೇನ್ ಜೋಶಿಯವರು ೨೦೧೧ ರಲ್ಲಿ ನಿಧನರಾದರು, ಆದರೆ ಅವರ ಸಂಗೀತ ಮತ್ತು ಅವರು ಪ್ರಾರಂಭಿಸಿದ ಸವಾಯಿ ಗಂಧರ್ವ ಸಂಗೀತ ಉತ್ಸವದ ಮೂಲಕ ಅವರು ಇಂದಿಗೂ ಅಮರರಾಗಿದ್ದಾರೆ. ದೊಡ್ಡ ಕನಸುಗಳನ್ನು ಹೊಂದಿರುವ ಮತ್ತು ಅದನ್ನು ಅನುಸರಿಸುವ ಧೈರ್ಯವಿರುವ ಪ್ರತಿಯೊಬ್ಬ ಮಗುವಿಗೆ ಅವರು ಸ್ಫೂರ್ತಿಯಾಗಿದ್ದಾರೆ. ಕಠಿಣ ಪರಿಶ್ರಮ ಮತ್ತು ಕಲೆಯ ಮೇಲಿನ ಪ್ರೀತಿಯಿಂದ, ಗದಗಿನಂತಹ ಸಣ್ಣ ಪಟ್ಟಣದ ಹುಡುಗ ಜಗತ್ತಿನ ಶಿಖರವನ್ನೇರಬಹುದು ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು. ಇಂದು ಕೂಡ ಅವರ ಗಂಭೀರ ಧ್ವನಿಯನ್ನು ಕೇಳಿದಾಗ, ಪರಿಪೂರ್ಣ ರಾಗಕ್ಕಾಗಿ ಸದಾ ಹಾತೊರೆಯುತ್ತಿದ್ದ ಆ ಮಹಾನ್ ಕಲಾವಿದ ನಮಗೆ ನೆನಪಾಗುತ್ತಾರೆ. ಅವರ ಜೀವನವು ನಮ್ಮ ಮನಸ್ಸಿನ ಮಾತನ್ನು ಕೇಳಲು ನಮಗೆ ಕಲಿಸುತ್ತದೆ.", "🌟"]
      ],
      quiz: [
        ["His art form?", "ಕಲೆ?", ["Hindustani vocal", "Bharatanatyam", "Painting"], ["ಹಿಂದೂಸ್ತಾನಿ ಗಾಯನ", "ಭರತನಾಟ್ಯ", "ಚಿತ್ರಕಲೆ"], 0],
        ["Which honour?", "ಯಾವ ಪ್ರಶಸ್ತಿ?", ["Bharat Ratna", "Oscar", "Grammy"], ["ಭಾರತ ರತ್ನ", "ಆಸ್ಕರ್", "ಗ್ರ್ಯಾಮಿ"], 0],
      
        ['Born in year…', 'ಜನ್ಮ ವರ್ಷ?', ['1922', '1900', '1950'], ['೧೯೨೨', '೧೯೦೦', '೧೯೫೦'], 0],
        ['Born in town…', 'ಪಟ್ಟಣ?', ['Gadag', 'Hampi', 'Bidar'], ['ಗದಗ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['He ran away at age…', 'ವಯಸ್ಸು?', ['11', '18', '25'], ['೧೧', '೧೮', '೨೫'], 0],
        ['Famous song of unity?', 'ಹಾಡು?', ['Mile Sur Mera Tumhara', 'Vande Mataram', 'Sare Jahan'], ['ಮಿಲೆ ಸುರ್', 'ವಂದೇ ಮಾತರಂ', 'ಸಾರೆ ಜಹಾ'], 0],
        ['That song aired in year…', 'ವರ್ಷ?', ['1988', '1947', '2000'], ['೧೯೮೮', '೧೯೪೭', '೨೦೦೦'], 0],
        ['He died in year…', 'ಮರಣ?', ['2011', '1990', '2020'], ['೨೦೧೧', '೧೯೯೦', '೨೦೨೦'], 0],
        ['Music festival started by him?', 'ಸಂಗೀತೋತ್ಸವ?', ['Sawai Gandharva', 'Tansen', 'Dover Lane'], ['ಸವಾಯಿ ಗಂಧರ್ವ', 'ತಾನ್ಸೇನ್', 'ಡೋವರ್'], 0],
        ['His gharana?', 'ಘರಾಣ?', ['Kirana', 'Gwalior', 'Jaipur'], ['ಕಿರಾಣಾ', 'ಗ್ವಾಲಿಯರ್', 'ಜೈಪುರ'], 0],
      ],
      memorial: ["Bhimsen Joshi Smarak", "ಭೀಮಸೇನ್ ಸ್ಮಾರಕ", "Dharwad", "ಧಾರವಾಡ", "Dharwad's music school carries his name.", "ಧಾರವಾಡದ ಸಂಗೀತ ಶಾಲೆ.", "Bhimsen Joshi memorial Dharwad"],
    })],
  },
  {
    id: "gadag", name: { en: "Gadag", kn: "ಗದಗ" }, emoji: "📜",
    heroes: [mkHero({
      id: "kumara-vyasa", emoji: "📖",
      name: ["Kumara Vyasa", "ಕುಮಾರವ್ಯಾಸ"],
      title: ["Poet of Karnata Bharata", "ಕರ್ನಾಟ ಭಾರತದ ಕವಿ"],
      era: "15th Century",
      pages: [
        ["In the 15th century, in the beautiful district of Gadag in Karnataka, a young boy named Naranappa was born. Even as a child, he was known for his gentle nature and his deep devotion to Lord Veeranarayana. While other children played in the streets, Naranappa's heart was filled with stories of ancient heroes and the rhythm of music. Growing up in a time of great kings and grand temples, he felt a special connection to the spiritual roots of his land. People noticed that Naranappa had a unique gift for words, and they began to see the spark of a future poet within him. This humble boy from Gadag would eventually grow up to be known as Kumara Vyasa, one of the most celebrated poets in the history of the Kannada language.", "೧೫ನೇ ಶತಮಾನದಲ್ಲಿ, ಕರ್ನಾಟಕದ ಸುಂದರ ಜಿಲ್ಲೆಯಾದ ಗದಗಿನಲ್ಲಿ ನಾರಣಪ್ಪ ಎಂಬ ಬಾಲಕನು ಜನಿಸಿದನು. ಬಾಲ್ಯದಿಂದಲೇ ಆತನು ತನ್ನ ಸೌಮ್ಯ ಸ್ವಭಾವ ಮತ್ತು ಶ್ರೀ ವೀರನಾರಾಯಣನ ಮೇಲಿನ ಅಚಲ ಭಕ್ತಿಗೆ ಹೆಸರಾಗಿದ್ದನು. ಉಳಿದ ಮಕ್ಕಳು ಬೀದಿಗಳಲ್ಲಿ ಆಟವಾಡುತ್ತಿದ್ದರೆ, ನಾರಣಪ್ಪನ ಹೃದಯವು ಪುರಾಣದ ವೀರರ ಕಥೆಗಳು ಮತ್ತು ಸಂಗೀತದ ಲಯದಿಂದ ತುಂಬಿರುತ್ತಿತ್ತು. ದೊಡ್ಡ ಅರಸರು ಮತ್ತು ವೈಭವದ ದೇಗುಲಗಳ ಕಾಲದಲ್ಲಿ ಬೆಳೆದ ಆತನು, ತನ್ನ ನಾಡಿನ ಆಧ್ಯಾತ್ಮಿಕ ಬೇರುಗಳೊಂದಿಗೆ ವಿಶೇಷವಾದ ಸಂಬಂಧವನ್ನು ಹೊಂದಿದ್ದನು. ನಾರಣಪ್ಪನಿಗೆ ಶಬ್ದಗಳ ಮೇಲೆ ವಿಶಿಷ್ಟವಾದ ಹಿಡಿತವಿರುವುದನ್ನು ಜನರು ಗಮನಿಸಿದರು ಮತ್ತು ಅವನಲ್ಲಿ ಒಬ್ಬ ಮಹಾನ್ ಕವಿಯಾಗುವ ಲಕ್ಷಣಗಳನ್ನು ಕಂಡರು. ಗದಗದ ಈ ವಿನೀತ ಬಾಲಕನು ಮುಂದೆ ಕನ್ನಡ ಸಾಹಿತ್ಯ ಚರಿತ್ರೆಯಲ್ಲಿ ಅತಿ ಹೆಚ್ಚು ಗೌರವಿಸಲ್ಪಟ್ಟ 'ಕುಮಾರವ್ಯಾಸ' ಎಂಬ ಹೆಸರಿನಿಂದ ಖ್ಯಾತನಾದನು.", "🏠"],
        ["As he reached adulthood, Naranappa’s life revolved around the sacred Veeranarayana Temple in Gadag. Choosing a quiet spot under a large, ancient peepal tree within the temple premises, he spent hours in deep meditation and prayer. It is said that he sought divine inspiration to bring the epic of the Mahabharata to the common people. He did not seek gold or worldly fame; instead, he wanted to share the timeless lessons of dharma through poetry. With his heart set on this holy mission, he began to transform his thoughts into beautiful verses. This sacred tree became his sanctuary, where he felt the presence of the divine guiding his pen, allowing him to weave a grand tapestry of words that would inspire generations to come.", "ನಾರಣಪ್ಪನು ಬೆಳೆದು ದೊಡ್ಡವನಾದಂತೆ, ಅವನ ಜೀವನವು ಗದಗದ ಪವಿತ್ರ ವೀರನಾರಾಯಣ ದೇವಸ್ಥಾನದ ಸುತ್ತಲೇ ಸಾಗಿತ್ತು. ದೇವಸ್ಥಾನದ ಆವರಣದಲ್ಲಿದ್ದ ಒಂದು ದೊಡ್ಡದಾದ, ಪುರಾತನ ಅಶ್ವತ್ಥ ಮರದ ಕೆಳಗೆ ಶಾಂತವಾದ ಜಾಗವನ್ನು ಆರಿಸಿಕೊಂಡು, ಅವನು ಗಂಟೆಗಟ್ಟಲೆ ಧ್ಯಾನ ಮತ್ತು ಪ್ರಾರ್ಥನೆಯಲ್ಲಿ ತೊಡಗುತ್ತಿದ್ದನು. ಮಹಾಭಾರತದ ಮಹಾಕಾವ್ಯವನ್ನು ಸಾಮಾನ್ಯ ಜನರಿಗೆ ತಲುಪಿಸಲು ಅವನು ದೈವಿಕ ಸ್ಫೂರ್ತಿಯನ್ನು ಬಯಸಿದನು ಎಂದು ಹೇಳಲಾಗುತ್ತದೆ. ಅವನು ಚಿನ್ನ ಅಥವಾ ಲೌಕಿಕ ಕೀರ್ತಿಯನ್ನು ಬಯಸಲಿಲ್ಲ; ಬದಲಾಗಿ, ಕವಿತೆಯ ಮೂಲಕ ಧರ್ಮದ ಶಾಶ್ವತ ಪಾಠಗಳನ್ನು ಹಂಚಿಕೊಳ್ಳಲು ಬಯಸಿದನು. ಈ ಪವಿತ್ರ ಉದ್ದೇಶದೊಂದಿಗೆ, ಅವನು ತನ್ನ ಆಲೋಚನೆಗಳನ್ನು ಸುಂದರವಾದ ಪದ್ಯಗಳನ್ನಾಗಿ ಪರಿವರ್ತಿಸಲು ಪ್ರಾರಂಭಿಸಿದನು. ಈ ಪವಿತ್ರ ಮರವು ಅವನ ಆಶ್ರಯತಾಣವಾಯಿತು, ಅಲ್ಲಿ ದೈವದ ಮಾರ್ಗದರ್ಶನವನ್ನು ಅನುಭವಿಸುತ್ತಾ ಅವನು ಮುಂದಿನ ತಲೆಮಾರುಗಳಿಗೆ ಪ್ರೇರಣೆ ನೀಡುವಂತಹ ಶಬ್ದಗಳ ಮಹಾನ್ ಕಾವ್ಯವನ್ನು ರಚಿಸಲು ಮುಂದಾದನು.", "🌳"],
        ["Under that very peepal tree, Naranappa began writing his masterpiece, 'Karnata Bharata Kathamanjari,' also known as Gadugina Bharata. He wrote with such speed and passion that it seemed as though the words were flowing straight from the divine. He chose a specific poetic style called Bhamini Shatpadi, a six-line metre that has a beautiful, rhythmic flow when recited. Covering the first ten chapters, or Parvas, of the Mahabharata, he brought the characters to life in a way that had never been done before in Kannada. His writing was so powerful and vivid that even the most complex scenes of the epic became easy for everyone to understand and enjoy. He showed that high literature could belong to every person, from the simplest villager to the learned scholar.", "ಅದೇ ಅಶ್ವತ್ಥ ಮರದ ಕೆಳಗೆ ಕುಳಿತು ನಾರಣಪ್ಪನು ತನ್ನ ಮೇರುಕೃತಿಯಾದ 'ಕರ್ಣಾಟ ಭಾರತ ಕಥಾಮಂಜರಿ'ಯನ್ನು ಬರೆಯಲು ಪ್ರಾರಂಭಿಸಿದನು, ಇದನ್ನು 'ಗದುಗಿನ ಭಾರತ' ಎಂದೂ ಕರೆಯುತ್ತಾರೆ. ಶಬ್ದಗಳು ದೈವಿಕವಾಗಿ ಹರಿಯುವಂತೆ ಅವನು ಅಷ್ಟು ವೇಗವಾಗಿ ಮತ್ತು ಉತ್ಸಾಹದಿಂದ ಬರೆದನು. ಅವನು 'ಭಾಮಿನಿ ಷಟ್ಪದಿ' ಎಂಬ ವಿಶಿಷ್ಟ ಕಾವ್ಯ ಶೈಲಿಯನ್ನು ಆರಿಸಿಕೊಂಡನು, ಇದು ಆರು ಸಾಲುಗಳ ಛಂದಸ್ಸಾಗಿದ್ದು, ವಾಚಿಸುವಾಗ ಸುಂದರವಾದ ಲಯವನ್ನು ಹೊಂದಿರುತ್ತದೆ. ಮಹಾಭಾರತದ ಮೊದಲ ಹತ್ತು ಪರ್ವಗಳನ್ನು ಒಳಗೊಂಡಂತೆ, ಅವನು ಈ ಮೊದಲು ಕನ್ನಡದಲ್ಲಿ ಯಾರು ಮಾಡದ ರೀತಿಯಲ್ಲಿ ಪಾತ್ರಗಳಿಗೆ ಜೀವ ತುಂಬಿದನು. ಅವನ ಬರವಣಿಗೆ ಎಷ್ಟು ಶಕ್ತಿಯುತ ಮತ್ತು ಎದ್ದುಕಾಣುವಂತಿತ್ತು ಎಂದರೆ ಮಹಾಕಾವ್ಯದ ಅತ್ಯಂತ ಸಂಕೀರ್ಣ ಸನ್ನಿವೇಶಗಳು ಸಹ ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಸುಲಭವಾಗಿ ಅರ್ಥವಾಗುವಂತೆ ಮತ್ತು ಆನಂದಿಸುವಂತಿದ್ದವು. ಉನ್ನತ ಸಾಹಿತ್ಯವು ಸಾಧಾರಣ ಜನರಿಂದ ಹಿಡಿದು ವಿದ್ವಾಂಸರವರೆಗೆ ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಸೇರಿದ್ದೆಂದು ಅವನು ತೋರಿಸಿಕೊಟ್ಟನು.", "✍️"],
        ["Naranappa took the pen name 'Kumara Vyasa,' meaning the son or disciple of the original sage Vyasa, who wrote the first Mahabharata. His achievement was monumental because he translated the complex Sanskrit epic into the heart-language of the people of Karnataka. By doing so, he became the greatest Kannada epic poet of the medieval era. His verses were not just words on a page but were meant to be sung aloud in a tradition known as Gamaka. Through these musical recitations, the stories of Krishna, Arjuna, and the Great War echoed through every household in the land. Kumara Vyasa’s work proved that Kannada was a language capable of expressing the deepest emotions and the most grand adventures, cementing his place as a true hero of literature.", "ನಾರಣಪ್ಪನು ಮೂಲ ಮಹಾಭಾರತ ಬರೆದ ವೇದವ್ಯಾಸರ ಪುತ್ರ ಅಥವಾ ಶಿಷ್ಯ ಎಂಬರ್ಥ ಬರುವ 'ಕುಮಾರವ್ಯಾಸ' ಎಂಬ ಕಾವ್ಯನಾಮವನ್ನು ಸ್ವೀಕರಿಸಿದನು. ಸಂಕೀರ್ಣವಾದ ಸಂಸ್ಕೃತ ಮಹಾಕಾವ್ಯವನ್ನು ಕರ್ನಾಟಕದ ಜನರ ಹ್ರದಯದ ಭಾಷೆಗೆ ಅನುವಾದಿಸುವ ಮೂಲಕ ಅವನು ಸ್ಮರಣೀಯ ಸಾಧನೆ ಮಾಡಿದನು. ಈ ಮೂಲಕ ಮಧ್ಯಕಾಲೀನ ಯುಗದ ಅತ್ಯಂತ ಶ್ರೇಷ್ಠ ಕನ್ನಡ ಮಹಾಕವಿ ಎಂದು ಪ್ರಸಿದ್ಧನಾದನು. ಅವನ ಪದ್ಯಗಳು ಕೇವಲ ಕಾಗದದ ಮೇಲಿನ ಅಕ್ಷರಗಳಾಗಿರಲಿಲ್ಲ, ಬದಲಾಗಿ ಅವುಗಳನ್ನು 'ಗಮಕ' ಎಂಬ ಸಂಪ್ರದಾಯದಲ್ಲಿ ಹಾಡಲು ಉದ್ದೇಶಿಸಲಾಗಿತ್ತು. ಈ ಸಂಗೀತಮಯ ವಾಚನಗಳ ಮೂಲಕ, ಕೃಷ್ಣ, ಅರ್ಜುನ ಮತ್ತು ಮಹಾಯುದ್ಧದ ಕಥೆಗಳು ನಾಡಿನ ಪ್ರತಿಯೊಂದು ಮನೆಯಲ್ಲೂ ಮೊಳಗಿದವು. ಕನ್ನಡವು ಅತ್ಯಂತ ಆಳವಾದ ಭಾವನೆಗಳನ್ನು ಮತ್ತು ಭವ್ಯವಾದ ಸಾಹಸಗಳನ್ನು ವ್ಯಕ್ತಪಡಿಸಲು ಸಮರ್ಥವಾದ ಭಾಷೆ ಎಂದು ಕುಮಾರವ್ಯಾಸನ ಕೃತಿಯು ಸಾಬೀತುಪಡಿಸಿತು, ಇದು ಅವನನ್ನು ಸಾಹಿತ್ಯದ ನಿಜವಾದ ವೀರನಾಗಿ ಮಾಡಿತು.", "📜"],
        ["Today, more than five hundred years later, the name of Kumara Vyasa and his Gadugina Bharata still shine brightly in Karnataka. The temple of Veeranarayana in Gadag remains a place of pilgrimage for lovers of poetry, who walk the same grounds where Naranappa once sat. His lines are still recited in schools and homes, teaching modern children about bravery, truth, and kindness. Every time someone sings a verse in the Bhamini Shatpadi style, the spirit of the poet under the peepal tree lives on. Kumara Vyasa remains an inspiration because he showed us that with devotion and a love for one's mother tongue, one can create something that never fades away. He is truly the poet who gave the story of India to the soul of Karnataka.", "ಇಂದು, ಐನೂರಕ್ಕೂ ಹೆಚ್ಚು ವರ್ಷಗಳ ನಂತರವೂ, ಕುಮಾರವ್ಯಾಸ ಮತ್ತು ಅವನ 'ಗದುಗಿನ ಭಾರತ'ದ ಹೆಸರು ಕರ್ನಾಟಕದಲ್ಲಿ ಪ್ರಕಾಶಮಾನವಾಗಿ ಬೆಳಗುತ್ತಿದೆ. ಗದಗದ ವೀರನಾರಾಯಣ ದೇವಸ್ಥಾನವು ಇಂದಿಗೂ ಸಾಹಿತ್ಯ ಪ್ರೇಮಿಗಳ ಪುಣ್ಯಕ್ಷೇತ್ರವಾಗಿದೆ, ಅಲ್ಲಿ ಭಕ್ತರು ಅಂದು ನಾರಣಪ್ಪನು ಕುಳಿತಿದ್ದ ಜಾಗದಲ್ಲೇ ಸಂಚರಿಸುತ್ತಾರೆ. ಇಂದಿಗೂ ಶಾಲೆಗಳಲ್ಲಿ ಮತ್ತು ಮನೆಗಳಲ್ಲಿ ಅವನ ಪದ್ಯಗಳನ್ನು ವಾಚಿಸಲಾಗುತ್ತಿದೆ, ಇದು ಇಂದಿನ ಮಕ್ಕಳಿಗೆ ಶೌರ್ಯ, ಸತ್ಯ ಮತ್ತು ದಯೆಯ ಬಗ್ಗೆ ಕಲಿಸುತ್ತಿದೆ. ಭಾಮಿನಿ ಷಟ್ಪದಿ ಶೈಲಿಯಲ್ಲಿ ಯಾರಾದರೂ ಪದ್ಯವನ್ನು ಹಾಡಿದಾಗಲೆಲ್ಲಾ, ಅಶ್ವತ್ಥ ಮರದ ಕೆಳಗಿದ್ದ ಆ ಕವಿಯ ಚೇತನವು ಮರುಜೀವ ಪಡೆಯುತ್ತದೆ. ಭಕ್ತಿ ಮತ್ತು ಮಾತೃಭಾಷೆಯ ಮೇಲಿನ ಪ್ರೀತಿಯಿಂದ ಎಂದಿಗೂ ಅಳಿಯದ ಕೃತಿಯನ್ನು ಸೃಷ್ಟಿಸಬಹುದು ಎಂದು ನಮಗೆ ತೋರಿಸಿಕೊಟ್ಟ ಕುಮಾರವ್ಯಾಸರು ಎಂದಿಗೂ ನಮಗೆ ಸ್ಫೂರ್ತಿಯಾಗಿದ್ದಾರೆ. ಅವರು ನಿಜವಾಗಿಯೂ ಭಾರತದ ಮಹಾಕಥೆಯನ್ನು ಕರ್ನಾಟಕದ ಆತ್ಮಕ್ಕೆ ನೀಡಿದ ಮಹಾನ್ ಕವಿ.", "🌟"]
      ],
      quiz: [
        ["Which epic did he retell?", "ಯಾವ ಕಾವ್ಯ?", ["Mahabharata", "Ramayana", "Vedas"], ["ಮಹಾಭಾರತ", "ರಾಮಾಯಣ", "ವೇದ"], 0],
        ["His real name?", "ನಿಜ ಹೆಸರು?", ["Naranappa", "Basavappa", "Puttappa"], ["ನಾರಣಪ್ಪ", "ಬಸವಪ್ಪ", "ಪುಟ್ಟಪ್ಪ"], 0],
      
        ['Lived in which century?', 'ಶತಮಾನ?', ['15th', '12th', '20th'], ['೧೫ನೇ', '೧೨ನೇ', '೨೦ನೇ'], 0],
        ['Real name?', 'ನಿಜ ಹೆಸರು?', ['Naranappa', 'Basavappa', 'Puttappa'], ['ನಾರಣಪ್ಪ', 'ಬಸವಪ್ಪ', 'ಪುಟ್ಟಪ್ಪ'], 0],
        ['Pen name means disciple of…', 'ಶಿಷ್ಯ?', ['Vyasa', 'Valmiki', 'Kalidasa'], ['ವ್ಯಾಸ', 'ವಾಲ್ಮೀಕಿ', 'ಕಾಳಿದಾಸ'], 0],
        ['Wrote under which tree?', 'ಯಾವ ಮರ?', ['Peepal', 'Banyan', 'Mango'], ['ಅರಳಿ ಮರ', 'ಆಲ', 'ಮಾವು'], 0],
        ['At which temple?', 'ದೇವಾಲಯ?', ['Veeranarayana', 'Krishna', 'Shiva'], ['ವೀರನಾರಾಯಣ', 'ಕೃಷ್ಣ', 'ಶಿವ'], 0],
        ['Temple in town…', 'ಪಟ್ಟಣ?', ['Gadag', 'Hampi', 'Bidar'], ['ಗದಗ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['His epic is also called…', 'ಮಹಾಕಾವ್ಯ?', ['Gadugina Bharata', 'Pampa Bharata', 'Ranna'], ['ಗದುಗಿನ ಭಾರತ', 'ಪಂಪ ಭಾರತ', 'ರನ್ನ'], 0],
        ['Wrote in language…', 'ಭಾಷೆ?', ['Kannada', 'Sanskrit', 'Tamil'], ['ಕನ್ನಡ', 'ಸಂಸ್ಕೃತ', 'ತಮಿಳು'], 0],
      ],
      memorial: ["Veeranarayana Temple", "ವೀರನಾರಾಯಣ ದೇವಾಲಯ", "Gadag town", "ಗದಗ", "The temple where Kumara Vyasa wrote his epic.", "ಕುಮಾರವ್ಯಾಸ ಬರೆದ ದೇವಾಲಯ.", "Veeranarayana temple Gadag"],
    })],
  },
  {
    id: "hassan", name: { en: "Hassan", kn: "ಹಾಸನ" }, emoji: "🛕",
    heroes: [mkHero({
      id: "jakanachari", emoji: "🪨",
      name: ["Amarashilpi Jakanachari", "ಅಮರಶಿಲ್ಪಿ ಜಕಣಾಚಾರಿ"],
      title: ["Master Sculptor of Hoysala Temples", "ಹೊಯ್ಸಳ ಶಿಲ್ಪಿ"],
      era: "Legendary",
      pages: [
        ["Long ago, in a peaceful village in Karnataka, lived a young boy named Jakanachari. From an early age, he was fascinated by the stones hills that surrounded him. While other children played games, Jakanachari spent his time watching master craftsmen shape blocks of granite. He had a natural gift for seeing the beauty hidden inside cold, hard rocks. His heart was filled with a dream to become the greatest sculptor the world had ever known. He traveled far from his home to learn the secrets of the chisel and hammer, dedicating every waking hour to perfecting his craft. His hands became steady and his mind grew sharp, preparing him for a life of creating masterpieces that would stand for centuries.", "ಬಹಳ ಹಿಂದೆಯೇ, ಕರ್ನಾಟಕದ ಒಂದು ಪ್ರಶಾಂತ ಗ್ರಾಮದಲ್ಲಿ ಜಕಣಾಚಾರಿ ಎಂಬ ಬಾಲಕನಿದ್ದನು. ಬಾಲ್ಯದಿಂದಲೇ ಅವನಿಗೆ ಸುತ್ತಮುತ್ತಲ ಬೆಟ್ಟಗಳ ಕಲ್ಲುಗಳ ಬಗ್ಗೆ ತೀವ್ರ ಆಕರ್ಷಣೆ ಇತ್ತು. ಉಳಿದ ಮಕ್ಕಳು ಆಟವಾಡುತ್ತಿದ್ದರೆ, ಜಕಣಾಚಾರಿ ಕಲ್ಲುಗಳಿಗೆ ರೂಪ ನೀಡುವ ಶಿಲ್ಪಿಗಳನ್ನು ನೋಡುತ್ತಾ ಸಮಯ ಕಳೆಯುತ್ತಿದ್ದನು. ತಣ್ಣನೆಯ ಕಠಿಣ ಶಿಲೆಗಳೊಳಗೆ ಅಡಗಿರುವ ಸೌಂದರ್ಯವನ್ನು ಕಾಣುವ ನೈಸರ್ಗಿಕ ಪ್ರತಿಭೆ ಅವನಿಗಿತ್ತು. ಪ್ರಪಂಚವೇ ಹೆಮ್ಮೆಪಡುವಂತಹ ಶ್ರೇಷ್ಠ ಶಿಲ್ಪಿಯಾಗಬೇಕೆಂಬ ಕನಸು ಅವನ ಹೃದಯದಲ್ಲಿ ತುಂಬಿತ್ತು. ತನ್ನ ಕೌಶಲವನ್ನು ಸುಧಾರಿಸಿಕೊಳ್ಳಲು ಸುತ್ತಿಗೆ ಮತ್ತು ಉಳಿಯ ರಹಸ್ಯಗಳನ್ನು ಕಲಿಯಲು ಅವನು ತನ್ನ ಮನೆಯಿಂದ ದೂರ ಪ್ರಯಾಣಿಸಿದನು. ಶತಮಾನಗಳ ಕಾಲ ಉಳಿಯುವ ಮೇರುಕೃತಿಗಳನ್ನು ನಿರ್ಮಿಸಲು ಸಾಧ್ಯವಾಗುವಂತೆ ಅವನ ಕೈಗಳು ಸ್ಥಿರವಾದವು ಮತ್ತು ಮನಸ್ಸು ಚುರುಕಾಯಿತು.", "🎨"],
        ["As he reached adulthood, Jakanachari's fame spread across the Hoysala Empire. The kings recognized his extraordinary talent and commissioned him to build grand temples like the Chennakeshava in Belur. He worked with mysterious soapstone, which was soft to carve but turned hard as steel over time. Jakanachari spent decades working in the district of Hassan, turning temple walls into stone libraries of legends. He carved intricate dancers, majestic lions, and graceful gods with such detail that they looked like they might breathe at any moment. His work was not just art; it was a form of worship, and he became the Master Sculptor known as Amarashilpi, meaning the immortal craftsman.", "ಜಕಣಾಚಾರಿಯು ವಯಸ್ಕನಾಗುತ್ತಿದ್ದಂತೆ, ಅವನ ಕೀರ್ತಿಯು ಹೊಯ್ಸಳ ಸಾಮ್ರಾಜ್ಯದಾದ್ಯಂತ ಹರಡಿತು. ಅವನ ಅಸಾಧಾರಣ ಪ್ರತಿಭೆಯನ್ನು ಗುರುತಿಸಿದ ಅರಸರು ಬೇಲೂರಿನ ಚೆನ್ನಕೇಶವನಂತಹ ಭವ್ಯ ದೇವಾಲಯಗಳನ್ನು ನಿರ್ಮಿಸಲು ಅವನಿಗೆ ಆದೇಶ ನೀಡಿದರು. ಅವನು ಕೆತ್ತಲು ಮೃದುವಾದ ಆದರೆ ಕಾಲಕ್ರಮೇಣ ಉಕ್ಕಿನಂತೆ ಗಟ್ಟಿಯಾಗುವ ಬಳಪದ ಕಲ್ಲಿನಿಂದ ಕೆಲಸ ಮಾಡುತ್ತಿದ್ದನು. ಹಾಸನ ಜಿಲ್ಲೆಯಲ್ಲಿ ದಶಕಗಳ ಕಾಲ ಶ್ರಮಿಸಿದ ಜಕಣಾಚಾರಿ, ದೇವಾಲಯದ ಗೋಡೆಗಳನ್ನು ಪುರಾಣ ಕಥೆಗಳ ಭಂಡಾರವನ್ನಾಗಿ ಬದಲಿಸಿದನು. ಅವನು ಕೆತ್ತಿದ ನರ್ತಕಿಯರು, ಭವ್ಯ ಸಿಂಹಗಳು ಮತ್ತು ಸುಂದರ ದೇವತೆಗಳು ಎಷ್ಟೊಂದು ಸೂಕ್ಷ್ಮವಾಗಿದ್ದವೆಂದರೆ ಅವುಗಳು ಯಾವುದೇ ಕ್ಷಣದಲ್ಲಿ ಉಸಿರಾಡಬಹುದು ಎಂಬಂತೆ ತೋರುತ್ತಿದ್ದವು. ಅವನ ಕೆಲಸವು ಕೇವಲ ಕಲೆಯಾಗಿರದೆ, ಒಂದು ಭಕ್ತಿಯ ರೂಪವಾಗಿತ್ತು ಮತ್ತು ಅವನು 'ಅಮರಶಿಲ್ಪಿ' ಎಂದು ಪ್ರಸಿದ್ಧನಾದನು.", "🏛️"],
        ["One day, while working on a magnificent idol, a young man named Dankanachari arrived at the site. This stranger claimed that the statue Jakanachari was working on had a serious flaw. Dankanachari pointed out that hidden inside the stone was a live toad, which made the statue imperfect for worship. Jakanachari, confident in his skill, made a bold vow: if there was a flaw, he would cut off his own right hand. To his absolute shock, when the stone was chiseled open, a toad hopped out. True to his word and filled with deep sorrow and penance, the master sculptor severed his carving hand. He did not know yet that the clever young man was actually his own long-lost son.", "ಒಂದು ದಿನ, ಜಕಣಾಚಾರಿಯು ಭವ್ಯವಾದ ವಿಗ್ರಹವೊಂದನ್ನು ಕೆತ್ತುತ್ತಿರುವಾಗ, ಡಂಕಣಾಚಾರಿ ಎಂಬ ಯುವಕನು ಅಲ್ಲಿಗೆ ಬಂದನು. ಜಕಣಾಚಾರಿ ಮಾಡುತ್ತಿರುವ ವಿಗ್ರಹದಲ್ಲಿ ಒಂದು ದೋಷವಿದೆ ಎಂದು ಆ ಅಪರಿಚಿತ ಯುವಕನು ಹೇಳಿದನು. ಕಲ್ಲಿನ ಒಳಗೆ ಕಪ್ಪೆಯೊಂದು ಅಡಗಿದೆ, ಇದು ವಿಗ್ರಹವನ್ನು ಪೂಜೆಗೆ ಅನರ್ಹಗೊಳಿಸುತ್ತದೆ ಎಂದು ಡಂಕಣಾಚಾರಿ ಎಚ್ಚರಿಸಿದನು. ತನ್ನ ಕೌಶಲದಲ್ಲಿ ನಂಬಿಕೆಯಿದ್ದ ಜಕಣಾಚಾರಿಯು ಒಂದು ಪ್ರತಿಜ್ಞೆ ಮಾಡಿದನು: ಒಂದು ವೇಳೆ ದೋಷವಿದ್ದರೆ ತನ್ನ ಬಲಗೈಯನ್ನು ಕತ್ತರಿಸಿಕೊಳ್ಳುವುದಾಗಿ ಹೇಳಿದನು. ಕಲ್ಲನ್ನು ಸೀಳಿದಾಗ ಅದರೊಳಗಿಂದ ಕಪ್ಪೆಯೊಂದು ಹೊರಬಂದಾಗ ಅವನಿಗೆ ಆಘಾತವಾಯಿತು. ತನ್ನ ಮಾತಿನಂತೆ, ತೀವ್ರ ದುಃಖ ಮತ್ತು ಪಶ್ಚಾತ್ತಾಪದಿಂದ ಆ ಶಿಲ್ಪಿ ತನ್ನ ಕೈಯನ್ನು ಕತ್ತರಿಸಿಕೊಂಡನು. ಆ ಬುದ್ಧಿವಂತ ಯುವಕ ಬೇರೆ ಯಾರೂ ಅಲ್ಲ, ತನ್ನದೇ ಕಳೆದುಹೋದ ಮಗ ಎಂಬ ವಿಷಯ ಆಗ ಅವನಿಗೆ ತಿಳಿದಿರಲಿಲ್ಲ.", "🔍"],
        ["Broken-hearted but still devoted to his gods, Jakanachari traveled to a place called Kridapura. He spent his days in deep prayer and sought forgiveness for his pride. According to the legend, a miracle happened due to his unwavering faith. Divine grace touched him, and his right hand was miraculously restored to its original strength. Because of this divine event, the village of Kridapura was renamed Kaidala, which means 'the hand that was regained' in the Kannada language. Overjoyed and reunited with his son Dankanachari, the master returned to his tools. Together, the father and son worked to finish beautiful shrines, proving that even after great mistakes, dedication and humility can lead to healing and restoration.", "ಹೃದಯವೊಡೆದಿದ್ದರೂ ದೈವಭಕ್ತಿಯನ್ನು ಬಿಡದ ಜಕಣಾಚಾರಿಯು ಕ್ರೀಡಾಪುರ ಎಂಬ ಸ್ಥಳಕ್ಕೆ ಹೋದನು. ಅವನು ಅಲ್ಲಿ ತನ್ನ ಅಹಂಕಾರಕ್ಕಾಗಿ ಕ್ಷಮೆಯಾಚಿಸುತ್ತಾ ದಿನಗಳನ್ನು ಕಳೆದನು. ದಂತಕಥೆಯ ಪ್ರಕಾರ, ಅವನ ಅಚಲ ನಂಬಿಕೆಯಿಂದ ಒಂದು ಪವಾಡ ಸಂಭವಿಸಿತು. ದೈವಿಕ ಕೃಪೆಯಿಂದ ಅವನ ಬಲಗೈ ಪವಾಡಸದೃಶವಾಗಿ ಮತ್ತೆ ಮರಳಿತು. ಈ ದೈವಿಕ ಘಟನೆಯ ಕಾರಣದಿಂದಾಗಿ ಕ್ರೀಡಾಪುರವನ್ನು 'ಕೈದಾಲ' ಎಂದು ಮರುನಾಮಕರಣ ಮಾಡಲಾಯಿತು, ಅಂದರೆ 'ಮರಳಿ ಪಡೆದ ಕೈ' ಎಂದು ಅರ್ಥ. ಅಪಾರ ಸಂತೋಷದಿಂದ ತನ್ನ ಮಗ ಡಂಕಣಾಚಾರಿಯೊಂದಿಗೆ ಒಂದಾದ ಜಕಣಾಚಾರಿಯು ಮರಳಿ ತನ್ನ ಕೆಲಸಕ್ಕೆ ಮರಳಿದನು. ಅಚಲ ಭಕ್ತಿ ಮತ್ತು ನಮ್ರತೆಯು ನಮ್ಮನ್ನು ಮತ್ತೆ ಸರಿಪಡಿಸಬಹುದು ಎಂದು ತೋರಿಸಿಕೊಡುತ್ತಾ ತಂದೆ ಮತ್ತು ಮಗ ಸೇರಿ ಸುಂದರ ದೇವಾಲಯಗಳನ್ನು ಪೂರ್ಣಗೊಳಿಸಿದರು.", "✨"],
        ["Today, thousands of people from all over the world visit Hassan to see the wonders created by Amarashilpi Jakanachari. The temples of Belur and Halebidu stand as stone poems, telling stories of ancient India's glory. His legacy reminds every child in Karnataka that true greatness comes from passion, hard work, and the courage to admit when one is wrong. He remains the ultimate symbol of the state's incredible stone-carving tradition. When you see a beautifully carved pillar or a smiling stone goddess in a Hoysala temple, remember the story of the man whose hands were guided by both skill and spirit. Jakanachari's art will live forever as long as these stones whisper his name to the wind.", "ಇಂದು, ಅಮರಶಿಲ್ಪಿ ಜಕಣಾಚಾರಿ ನಿರ್ಮಿಸಿದ ಅದ್ಭುತಗಳನ್ನು ನೋಡಲು ವಿಶ್ವದಾದ್ಯಂತದ ಸಾವಿರಾರು ಜನರು ಹಾಸನಕ್ಕೆ ಭೇಟಿ ನೀಡುತ್ತಾರೆ. ಬೇಲೂರು ಮತ್ತು ಹಳೇಬೀಡು ದೇವಾಲಯಗಳು ಪ್ರಾಚೀನ ಭಾರತದ ವೈಭವವನ್ನು ಸಾರುವ ಕಲ್ಲಿನ ಕವಿತೆಗಳಂತೆ ನಿಂತಿವೆ. ನಿಜವಾದ ಶ್ರೇಷ್ಠತೆಯು ಶ್ರದ್ಧೆ, ಪರಿಶ್ರಮ ಮತ್ತು ತಪ್ಪನ್ನು ಒಪ್ಪಿಕೊಳ್ಳುವ ಧೈರ್ಯದಿಂದ ಬರುತ್ತದೆ ಎಂದು ಅವನ ಜೀವನವು ಕರ್ನಾಟಕದ ಪ್ರತಿಯೊಬ್ಬ ಮಗುವಿಗೆ ನೆನಪಿಸುತ್ತದೆ. ಅವನು ನಮ್ಮ ರಾಜ್ಯದ ಅದ್ಭುತ ಶಿಲ್ಪಕಲೆ ಸಂಪ್ರದಾಯದ ಪರಮ ಸಂಕೇತವಾಗಿ ಅಜರಾಮರನಾಗಿದ್ದಾನೆ. ನೀವು ಹೊಯ್ಸಳ ದೇವಾಲಯಗಳಲ್ಲಿ ಸುಂದರವಾಗಿ ಕೆತ್ತಿದ ಕಂಬ ಅಥವಾ ನಗುತ್ತಿರುವ ಶಿಲಾಬಾಲಿಕೆಯನ್ನು ನೋಡಿದಾಗ, ಕೌಶಲ ಮತ್ತು ಭಕ್ತಿಯನ್ನು ಮೈಗೂಡಿಸಿಕೊಂಡಿದ್ದ ಆ ಮಹಾನ್ ವ್ಯಕ್ತಿಯನ್ನು ಸ್ಮರಿಸಿ. ಈ ಕಲ್ಲುಗಳು ಅವನ ಹೆಸರನ್ನು ಗಾಳಿಯಲ್ಲಿ ಉಸಿರಾಡುವವರೆಗೂ ಜಕಣಾಚಾರಿಯ ಕಲೆ ಅಮರವಾಗಿ ಉಳಿಯುತ್ತದೆ.", "🇮🇳"]
      ],
      quiz: [
        ["He carved temples at…", "ಎಲ್ಲಿ?", ["Belur & Halebidu", "Hampi", "Badami"], ["ಬೇಲೂರು ಹಳೇಬೀಡು", "ಹಂಪಿ", "ಬಾದಾಮಿ"], 0],
        ["His art was…", "ಕಲೆ?", ["Sculpture", "Music", "Poetry"], ["ಶಿಲ್ಪಕಲೆ", "ಸಂಗೀತ", "ಕಾವ್ಯ"], 0],
      
        ['He worked under which empire?', 'ಸಾಮ್ರಾಜ್ಯ?', ['Hoysala', 'Vijayanagara', 'Mughal'], ['ಹೊಯ್ಸಳ', 'ವಿಜಯನಗರ', 'ಮೊಘಲ್'], 0],
        ["Title 'Amarashilpi' means…", 'ಅರ್ಥ?', ['Immortal sculptor', 'Great king', 'Wise poet'], ['ಅಮರ ಶಿಲ್ಪಿ', 'ಮಹಾ ರಾಜ', 'ಕವಿ'], 0],
        ['Famous temples at Belur and…', 'ಮತ್ತು…', ['Halebidu', 'Hampi', 'Badami'], ['ಹಳೇಬೀಡು', 'ಹಂಪಿ', 'ಬಾದಾಮಿ'], 0],
        ["Son's name?", 'ಮಗ?', ['Dankanachari', 'Naranappa', 'Basava'], ['ಡಂಕನಾಚಾರಿ', 'ನಾರಣಪ್ಪ', 'ಬಸವ'], 0],
        ['Penance done at place…', 'ಪ್ರಾಯಶ್ಚಿತ್ತ?', ['Kridapura', 'Hampi', 'Bidar'], ['ಕ್ರೀಡಾಪುರ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['Material he carved?', 'ಯಾವ ವಸ್ತು?', ['Stone', 'Wood', 'Metal'], ['ಕಲ್ಲು', 'ಮರ', 'ಲೋಹ'], 0],
        ['Temples are in district…', 'ಜಿಲ್ಲೆ?', ['Hassan', 'Mysuru', 'Bidar'], ['ಹಾಸನ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Lesson from his story?', 'ಪಾಠ?', ['Humility', 'Greed', 'Anger'], ['ವಿನಯ', 'ಲೋಭ', 'ಕೋಪ'], 0],
      ],
      memorial: ["Chennakeshava Temple", "ಚೆನ್ನಕೇಶವ ದೇವಾಲಯ", "Belur, Hassan", "ಬೇಲೂರು", "12th-century masterpiece.", "12ನೇ ಶತಮಾನದ ಕೃತಿ.", "Chennakeshava Temple Belur"],
    })],
  },
  {
    id: "haveri", name: { en: "Haveri", kn: "ಹಾವೇರಿ" }, emoji: "🌻",
    heroes: [mkHero({
      id: "kanaka-dasa", emoji: "🪕",
      name: ["Kanaka Dasa", "ಕನಕದಾಸ"],
      title: ["Saint-Poet of Equality", "ಸಮಾನತೆಯ ಸಂತ-ಕವಿ"],
      era: "1509 – 1609",
      pages: [
        ["Long ago, in the green land of Bada in Haveri, a brave boy named Thimmappa Nayaka was born into the Kuruba community. His family were shepherds and protectors of the land. Thimmappa grew up to be a strong warrior and a leader, but his heart was filled with thoughts of God. He often spent his time thinking about the beauty of the world and the kindness that humans should show to one another. Despite his status as a local chieftain, he realized that true strength did not come from weapons or wealth, but from a peaceful mind and a loving heart. He chose to leave his life as a soldier behind to become a wandering singer and a poet, dedicating his life to spreading messages of devotion and equality across the beautiful land of Karnataka.", "ಬಹಳ ಹಿಂದೆಯೇ, ಹಾವೇರಿಯ ಬಾಡ ಎಂಬ ಹಸಿರು ನಾಡಿನಲ್ಲಿ, ಕುರುಬ ಸಮುದಾಯದಲ್ಲಿ ತಿಮ್ಮಪ್ಪ ನಾಯಕ ಎಂಬ ಧೈರ್ಯಶಾಲಿ ಹುಡುಗ ಹುಟ್ಟಿದನು. ಇವನ ಕುಟುಂಬದವರು ಕುರಿಗಾಹಿಗಳು ಮತ್ತು ನಾಡಿನ ರಕ್ಷಕರಾಗಿದ್ದರು. ತಿಮ್ಮಪ್ಪ ಒಬ್ಬ ಶಕ್ತಿಯುತ ಯೋಧ ಮತ್ತು ನಾಯಕನಾಗಿ ಬೆಳೆದನು, ಆದರೆ ಅವನ ಹೃದಯವು ದೇವರ ಆಲೋಚನೆಗಳಿಂದ ತುಂಬಿತ್ತು. ಅವನು ಪ್ರಪಂಚದ ಸೌಂದರ್ಯ ಮತ್ತು ಮನುಷ್ಯರು ಪರಸ್ಪರ ತೋರಬೇಕಾದ ದಯೆಯ ಬಗ್ಗೆ ಯೋಚಿಸುತ್ತಾ ಸಮಯ ಕಳೆಯುತ್ತಿದ್ದನು. ಒಬ್ಬ ನಾಯಕನಾಗಿದ್ದರೂ ಸಹ, ನಿಜವಾದ ಶಕ್ತಿಯು ಆಯುಧಗಳಿಂದ ಅಥವಾ ಸಂಪತ್ತಿನಿಂದ ಬರುವುದಿಲ್ಲ, ಬದಲಾಗಿ ಶಾಂತಿಯುತ ಮನಸ್ಸು ಮತ್ತು ಪ್ರೀತಿಯ ಹೃದಯದಿಂದ ಬರುತ್ತದೆ ಎಂದು ಅವನು ಅರಿತುಕೊಂಡನು. ಅವನು ತನ್ನ ಸೈನಿಕ ಜೀವನವನ್ನು ಬಿಟ್ಟು ಅಲೆಮಾರಿ ಗಾಯಕ ಮತ್ತು ಕವಿಯಾಗಲು ನಿರ್ಧರಿಸಿದನು, ಕರ್ನಾಟಕದಾದ್ಯಂತ ಭಕ್ತಿ ಮತ್ತು ಸಮಾನತೆಯ ಸಂದೇಶಗಳನ್ನು ಹರಡಲು ತನ್ನ ಜೀವನವನ್ನು ಮುಡಿಪಾಗಿಟ್ಟನು.", "🐑"],
        ["Thimmappa became the great saint Kanaka Dasa, a devoted disciple of the wise teacher Vyasaraya. He began writing beautiful songs called Kirtanas in the common language of the people, Kannada. Kanaka Dasa used his poems to teach important lessons. In his famous story 'Ramadhanya Charite,' he described a clever debate between rich rice and humble ragi. While rice was considered fancy, Kanaka Dasa showed that the simple ragi was actually superior because it sustained the hardworking poor and was loved by God. Through his writings like 'Mohanatarangini' and 'Nalacharitre,' he used simple stories to explain complex ideas, proving that wisdom belongs to everyone, regardless of where they come from or what job they do in society.", "ತಿಮ್ಮಪ್ಪನು ಮುಂದೆ ಜ್ಞಾನಿ ವ್ಯಾಸರಾಯರ ಭಕ್ತ ಶಿಷ್ಯನಾಗಿ ಕನಕದಾಸ ಎಂಬ ಮಹಾನ್ ಸಂತರಾದರು. ಅವರು ಜನಸಾಮಾನ್ಯರ ಭಾಷೆಯಾದ ಕನ್ನಡದಲ್ಲಿ 'ಕೀರ್ತನೆ' ಎಂಬ ಸುಂದರ ಹಾಡುಗಳನ್ನು ಬರೆಯಲು ಪ್ರಾರಂಭಿಸಿದರು. ಕನಕದಾಸರು ತಮ್ಮ ಕವಿತೆಗಳ ಮೂಲಕ ಪ್ರಮುಖ ಪಾಠಗಳನ್ನು ಕಲಿಸಿದರು. ಅವರ ಪ್ರಸಿದ್ಧ ಕೃತಿಯಾದ ‘ರಾಮಧಾನ್ಯ ಚರಿತೆ’ಯಲ್ಲಿ, ಶ್ರೀಮಂತ ಅಕ್ಕಿ ಮತ್ತು ವಿನಮ್ರ ರಾಗಿಯ ನಡುವಿನ ಚತುರ ಚರ್ಚೆಯನ್ನು ವಿವರಿಸಿದ್ದಾರೆ. ಅಕ್ಕಿಯನ್ನು ಶ್ರೀಮಂತವೆಂದು ಪರಿಗಣಿಸಲಾಗಿದ್ದರೂ, ಸರಳವಾದ ರಾಗಿಯೇ ಶ್ರೇಷ್ಠವಾದುದು ಎಂದು ಕನಕದಾಸರು ತೋರಿಸಿಕೊಟ್ಟರು, ಏಕೆಂದರೆ ಅದು ಕಷ್ಟಪಟ್ಟು ದುಡಿಯುವ ಬಡವರನ್ನು ಪೋಷಿಸುತ್ತದೆ ಮತ್ತು ದೇವರಿಗೆ ಪ್ರಿಯವಾಗಿದೆ. 'ಮೋಹನತರಂಗಿಣಿ' ಮತ್ತು 'ನಳಚರಿತ್ರೆ'ಯಂತಹ ಕೃತಿಗಳ ಮೂಲಕ, ಅವರು ಸರಳ ಕಥೆಗಳ ಮೂಲಕ ಕಠಿಣ ವಿಚಾರಗಳನ್ನು ವಿವರಿಸಿದರು, ಬುದ್ಧಿವಂತಿಕೆಯು ಎಲ್ಲರಿಗೂ ಸೇರಿದ್ದು ಎಂದು ಸಾಬೀತುಪಡಿಸಿದರು.", "✍️"],
        ["Among his many talents, Kanaka Dasa was famous for creating 'Mundige' or riddle-songs. These were clever puzzles that looked simple on the outside but held deep spiritual meanings inside. He challenged people to think beyond what they could see with their eyes. He walked from village to town, singing with his tanpura, teaching people that God does not look at a person’s caste or wealth. Instead, God looks at the purity of one's soul. Many leaders and scholars were amazed by his intelligence and his ability to solve difficult problems with gentle words. Even when some people treated him unkindly because of his humble background, he remained calm and continued to sing about peace, love, and the importance of seeing everyone as equals.", "ಕನಕದಾಸರು ತಮ್ಮ ಅನೇಕ ಪ್ರತಿಭೆಗಳ ನಡುವೆ 'ಮುಂಡಿಗೆ' ಅಥವಾ ಒಗಟು-ಹಾಡುಗಳನ್ನು ರಚಿಸಲು ಪ್ರಸಿದ್ಧರಾಗಿದ್ದರು. ಇವು ಹೊರನೋಟಕ್ಕೆ ಸರಳವಾಗಿ ಕಂಡರೂ ಒಳಗೆ ಆಳವಾದ ಆಧ್ಯಾತ್ಮಿಕ ಅರ್ಥಗಳನ್ನು ಹೊಂದಿದ್ದ ಚತುರ ಒಗಟುಗಳಾಗಿದ್ದವು. ಕಣ್ಣಿಗೆ ಕಾಣುವುದಕ್ಕಿಂತ ಆಚೆಗೆ ಯೋಚಿಸುವಂತೆ ಅವರು ಜನರಿಗೆ ಸವಾಲು ಹಾಕಿದರು. ಅವರು ತಮ್ಮ ತಂಬೂರಿಯೊಂದಿಗೆ ಹಳ್ಳಿ ಹಳ್ಳಿಗೂ ಸಂಚರಿಸಿ, ದೇವರು ಮನುಷ್ಯನ ಜಾತಿ ಅಥವಾ ಸಂಪತ್ತನ್ನು ನೋಡುವುದಿಲ್ಲ ಎಂದು ಜನರಿಗೆ ಬೋಧಿಸಿದರು. ಬದಲಾಗಿ, ದೇವರು ಮನುಷ್ಯನ ಆತ್ಮದ ಶುದ್ಧತೆಯನ್ನು ನೋಡುತ್ತಾನೆ ಎಂದರು. ಅವರ ಬುದ್ಧಿವಂತಿಕೆ ಮತ್ತು ಕಠಿಣ ಸಮಸ್ಯೆಗಳನ್ನು ಶಾಂತ ಮಾತುಗಳಿಂದ ಪರಿಹರಿಸುವ ಸಾಮರ್ಥ್ಯವನ್ನು ಕಂಡು ಅನೇಕ ನಾಯಕರು ಮತ್ತು ವಿದ್ವಾಂಸರು ಆಶ್ಚರ್ಯಚಕಿತರಾದರು. ಅವರ ಹಿನ್ನೆಲೆಯಿಂದಾಗಿ ಕೆಲವು ಜನರು ಅವರೊಂದಿಗೆ ಅಸಭ್ಯವಾಗಿ ನಡೆದುಕೊಂಡರೂ, ಅವರು ಶಾಂತವಾಗಿದ್ದರು ಮತ್ತು ಪ್ರೀತಿ ಹಾಗೂ ಸಮಾನತೆಯ ಬಗ್ಗೆ ಹಾಡುವುದನ್ನು ಮುಂದುವರಿಸಿದರು.", "🧩"],
        ["The most miraculous moment of his life happened in the town of Udupi. Kanaka Dasa went to the Krishna temple to pray, but he was stopped at the gates and denied entry because he was from a lower caste. He did not get angry or fight; instead, he went to the back of the temple and sang with tears in his eyes, calling out to Lord Krishna with pure devotion. Suddenly, a miracle occurred! The stone wall cracked, and the idol of Lord Krishna, which normally faced east, slowly turned around to face the west. A small window opened in the wall so that Kanaka Dasa could finally see his beloved Lord. This window is still called 'Kanakana Kindi,' and it reminds everyone that true devotion can move mountains and even turn stone statues.", "ಅವರ ಜೀವನದ ಅತ್ಯಂತ ಪವಾಡದ ಕ್ಷಣ ಉಡುಪಿಯಲ್ಲಿ ಸಂಭವಿಸಿತು. ಕನಕದಾಸರು ಕೃಷ್ಣನ ದೇವಸ್ಥಾನಕ್ಕೆ ಪ್ರಾರ್ಥಿಸಲು ಹೋದರು, ಆದರೆ ಅವರು ಹಿಂದುಳಿದ ಸಮುದಾಯದವರಾದ ಕಾರಣ ದ್ವಾರದಲ್ಲಿ ಅವರನ್ನು ತಡೆದು ಒಳಗೆ ಬಿಡಲಿಲ್ಲ. ಅವರು ಕೋಪಗೊಳ್ಳಲಿಲ್ಲ ಅಥವಾ ಜಗಳವಾಡಲಿಲ್ಲ; ಬದಲಾಗಿ, ಅವರು ದೇವಾಲಯದ ಹಿಂಭಾಗಕ್ಕೆ ಹೋಗಿ ಕಣ್ಣೀರು ಹಾಕುತ್ತಾ, ಪರಿಶುದ್ಧ ಭಕ್ತಿಯಿಂದ ಕೃಷ್ಣನನ್ನು ಕೂಗುತ್ತಾ ಹಾಡಿದರು. ಆಗ ಇದ್ದಕ್ಕಿದ್ದಂತೆ ಒಂದು ಪವಾಡ ನಡೆಯಿತು! ಕಲ್ಲಿನ ಗೋಡೆಯಲ್ಲಿ ಬಿರುಕು ಬಿಟ್ಟಿತು ಮತ್ತು ಸಾಮಾನ್ಯವಾಗಿ ಪೂರ್ವಕ್ಕೆ ಮುಖ ಮಾಡುತ್ತಿದ್ದ ಕೃಷ್ಣನ ವಿಗ್ರಹವು ನಿಧಾನವಾಗಿ ಪಶ್ಚಿಮಕ್ಕೆ ತಿರುಗಿತು. ಗೋಡೆಯಲ್ಲೊಂದು ಸಣ್ಣ ಕಿಟಕಿ ತೆರೆದುಕೊಂಡಿತು, ಅದರ ಮೂಲಕ ಕನಕದಾಸರು ಕೊನೆಗೂ ತಮ್ಮ ಪ್ರೀತಿಯ ದೇವರನ್ನು ನೋಡಲು ಸಾಧ್ಯವಾಯಿತು. ಈ ಕಿಟಕಿಯನ್ನು ಇಂದಿಗೂ 'ಕನಕನ ಕಿಂಡಿ' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ ಮತ್ತು ನಿಜವಾದ ಭಕ್ತಿಯು ಕಲ್ಲನ್ನು ಸಹ ಕರಗಿಸುತ್ತದೆ ಎಂದು ಇದು ನೆನಪಿಸುತ್ತದೆ.", "🪟"],
        ["Today, Kanaka Dasa is remembered as the Saint-Poet of Equality. His life spanned a full hundred years, and in that time, he changed how people thought about each other. Every year, Karnataka celebrates his legacy to honor his contributions to music, literature, and social justice. Children learn his songs in school, and people visit the 'Kanakana Kindi' in Udupi to remember that everyone is equal in the eyes of the Divine. His story teaches us that it doesn’t matter where we are born; what matters is how we treat others and the goodness we bring into the world. Kanaka Dasa remains a bright star in the history of India, shining a light on a world where kindness and devotion are the most important qualities of all.", "ಇಂದು, ಕನಕದಾಸರನ್ನು ಸಮಾನತೆಯ ಶ್ರೇಷ್ಠ ಸಂತ-ಕವಿ ಎಂದು ನೆನಪಿಸಿಕೊಳ್ಳಲಾಗುತ್ತದೆ. ನೂರು ವರ್ಷಗಳ ಕಾಲ ಬದುಕಿದ ಅವರು, ಜನರು ಪರಸ್ಪರ ಹೇಗೆ ಭಾವಿಸಬೇಕು ಎಂಬುದನ್ನು ಬದಲಾಯಿಸಿದರು. ಸಂಗೀತ, ಸಾಹಿತ್ಯ ಮತ್ತು ಸಾಮಾಜಿಕ ನ್ಯಾಯಕ್ಕೆ ಅವರ ಕೊಡುಗೆಯನ್ನು ಗೌರವಿಸಲು ಪ್ರತಿ ವರ್ಷ ಕರ್ನಾಟಕವು ಅವರ ಸ್ಮರಣಾರ್ಥ ಉತ್ಸವವನ್ನು ಆಚರಿಸುತ್ತದೆ. ಮಕ್ಕಳು ಶಾಲೆಯಲ್ಲಿ ಅವರ ಹಾಡುಗಳನ್ನು ಕಲಿಯುತ್ತಾರೆ ಮತ್ತು ದೇವರ ದೃಷ್ಟಿಯಲ್ಲಿ ಎಲ್ಲರೂ ಸಮಾನರು ಎಂಬುದನ್ನು ನೆನಪಿಸಿಕೊಳ್ಳಲು ಜನರು ಉಡುಪಿಯ 'ಕನಕನ ಕಿಂಡಿ'ಗೆ ಭೇಟಿ ನೀಡುತ್ತಾರೆ. ನಾವು ಎಲ್ಲಿ ಹುಟ್ಟಿದ್ದೇವೆ ಎಂಬುದು ಮುಖ್ಯವಲ್ಲ; ನಾವು ಇತರರನ್ನು ಹೇಗೆ ನಡೆಸಿಕೊಳ್ಳುತ್ತೇವೆ ಮತ್ತು ಜಗತ್ತಿಗೆ ನಾವು ನೀಡುವ ಒಳ್ಳೆಯತನ ಮುಖ್ಯ ಎಂಬ ಪಾಠವನ್ನು ಅವರ ಜೀವನವು ನಮಗೆ ಕಲಿಸುತ್ತದೆ. ಕನಕದಾಸರು ಭಾರತದ ಇತಿಹಾಸದಲ್ಲಿ ಪ್ರಕಾಶಮಾನವಾದ ನಕ್ಷತ್ರವಾಗಿ ಉಳಿದಿದ್ದಾರೆ, ದಯೆ ಮತ್ತು ಭಕ್ತಿಯೇ ಅತ್ಯಂತ ಪ್ರಮುಖ ಗುಣಗಳು ಎಂಬ ಬೆಳಕನ್ನು ಹರಡುತ್ತಿದ್ದಾರೆ.", "🌟"]
      ],
      quiz: [
        ["He was a saint-poet of…", "ಭಾಷೆ?", ["Kannada", "Tamil", "Telugu"], ["ಕನ್ನಡ", "ತಮಿಳು", "ತೆಲುಗು"], 0],
        ["His message?", "ಸಂದೇಶ?", ["Equality", "War", "Wealth"], ["ಸಮಾನತೆ", "ಯುದ್ಧ", "ಸಂಪತ್ತು"], 0],
      
        ['Real name?', 'ನಿಜ ಹೆಸರು?', ['Thimmappa Nayaka', 'Naranappa', 'Puttappa'], ['ತಿಮ್ಮಪ್ಪ ನಾಯಕ', 'ನಾರಣಪ್ಪ', 'ಪುಟ್ಟಪ್ಪ'], 0],
        ['Community?', 'ಸಮುದಾಯ?', ['Kuruba', 'Vokkaliga', 'Lingayat'], ['ಕುರುಬ', 'ಒಕ್ಕಲಿಗ', 'ಲಿಂಗಾಯತ'], 0],
        ['Born in village…', 'ಗ್ರಾಮ?', ['Bada', 'Hampi', 'Bidar'], ['ಬಾಡ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['His teacher (guru)?', 'ಗುರು?', ['Vyasaraya', 'Madhva', 'Basava'], ['ವ್ಯಾಸರಾಯ', 'ಮಧ್ವ', 'ಬಸವ'], 0],
        ['His songs are called…', 'ಹಾಡುಗಳು?', ['Kirtanas', 'Vachanas', 'Shlokas'], ['ಕೀರ್ತನೆ', 'ವಚನ', 'ಶ್ಲೋಕ'], 0],
        ['Famous riddle poems?', 'ಒಗಟು?', ['Mundige', 'Tripadi', 'Choupadi'], ['ಮುಂಡಿಗೆ', 'ತ್ರಿಪದಿ', 'ಚೌಪದಿ'], 0],
        ['Famous Udupi miracle window?', 'ಉಡುಪಿ?', ['Kanakana Kindi', 'Mukhya Dwara', 'Side Door'], ['ಕನಕನ ಕಿಂಡಿ', 'ಮುಖ್ಯ ದ್ವಾರ', 'ಪಕ್ಕದ ಬಾಗಿಲು'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Haveri', 'Mysuru', 'Bidar'], ['ಹಾವೇರಿ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
      ],
      memorial: ["Kanaka Dasa Memorial", "ಕನಕದಾಸ ಸ್ಮಾರಕ", "Bada, Haveri", "ಬಾಡ, ಹಾವೇರಿ", "His birthplace temple.", "ಜನ್ಮಸ್ಥಳ ದೇವಾಲಯ.", "Kanaka Dasa memorial Bada Haveri"],
    })],
  },
  {
    id: "kalaburagi", name: { en: "Kalaburagi", kn: "ಕಲಬುರಗಿ" }, emoji: "🕌",
    heroes: [mkHero({
      id: "sharana-basaveshwara", emoji: "🪔",
      name: ["Sharana Basaveshwara", "ಶರಣ ಬಸವೇಶ್ವರ"],
      title: ["Saint of Service & Compassion", "ಸೇವೆ-ಕರುಣೆಯ ಸಂತ"],
      era: "1707 – 1773",
      pages: [
        ["In the 18th century, a special child named Sharana Basaveshwara was born in the northern part of Karnataka. Many people believed he was a reincarnation of the great teacher Basavanna, sent back to Earth to spread love and kindness. Growing up in the dry, sun-wrenched lands of Kalaburagi, he possessed a gentle heart that felt the pain of others. Even as a small boy, he would look at the world with curiosity and deep wisdom, wondering how he could help people find peace. His childhood was not about games, but about understanding the true meaning of devotion and discovering how a single person could change the lives of thousands through simple, honest living.", "೧೮ನೇ ಶತಮಾನದಲ್ಲಿ, ಕರ್ನಾಟಕದ ಉತ್ತರ ಭಾಗದಲ್ಲಿ ಶರಣ ಬಸವೇಶ್ವರ ಎಂಬ ವಿಶೇಷ ಮಗು ಜನಿಸಿತು. ಇವರು ಮಹಾನ್ ಗುರು ಬಸವಣ್ಣನವರ ಪುನರ್ಜನ್ಮ ಎಂದು ಅನೇಕ ಜನರು ನಂಬಿದ್ದರು, ಇವರು ಪ್ರೀತಿ ಮತ್ತು ದಯೆಯನ್ನು ಹರಡಲು ಭೂಮಿಗೆ ಬಂದವರು ಎಂದು ಭಾವಿಸಲಾಗಿತ್ತು. ಕಲಬುರಗಿಯ ಬಿಸಿಲಿನ ನಾಡಿನಲ್ಲಿ ಬೆಳೆದ ಇವರು, ಇತರರ ನೋವನ್ನು ಅರಿಯುವ ಮೃದು ಹೃದಯವನ್ನು ಹೊಂದಿದ್ದರು. ಚಿಕ್ಕ ಬಾಲಕನಾಗಿದ್ದಾಗಲೂ, ಇವರು ಜಗತ್ತನ್ನು ಕುತೂಹಲ ಮತ್ತು ಆಳವಾದ ಜ್ಞಾನದಿಂದ ನೋಡುತ್ತಿದ್ದರು. ತಾವು ಜನರ ನೆಮ್ಮದಿಗೆ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು ಎಂದು ಸದಾ ಯೋಚಿಸುತ್ತಿದ್ದರು. ಇವರ ಬಾಲ್ಯವು ಕೇವಲ ಆಟವಾಡಲು ಸೀಮಿತವಾಗಿರದೆ, ಭಕ್ತಿಯ ನಿಜವಾದ ಅರ್ಥವನ್ನು ಅರ್ಥಮಾಡಿಕೊಳ್ಳುವ ಮತ್ತು ಸರಳ ಜೀವನದ ಮೂಲಕ ಸಾವಿರಾರು ಜನರ ಬದುಕನ್ನು ಹೇಗೆ ಬದಲಾಯಿಸಬಹುದು ಎಂಬ ಹುಡುಕಾಟದಲ್ಲಿತ್ತು.", "✨"],
        ["As he grew older, Sharana Basaveshwara began to teach the people of Gulbarga two very important lessons that are still remembered today. The first was 'Kayaka,' which means that work is worship. He taught that any honest labor, whether it is farming the land or sweeping the streets, is a sacred act if done with a pure heart. He didn't want people to sit idle; he wanted everyone to work hard and find dignity in their efforts. By doing their daily tasks well, people could find God within their own actions. This simple philosophy transformed the region, as everyone from small children to elders began to see their everyday work as a beautiful offering to the divine.", "ಶರಣ ಬಸವೇಶ್ವರರು ಬೆಳೆಯುತ್ತಾ ಹೋದಂತೆ, ಗುಲ್ಬರ್ಗದ ಜನರಿಗೆ ಇಂದಿಗೂ ನೆನಪಿರುವ ಎರಡು ಪ್ರಮುಖ ಪಾಠಗಳನ್ನು ಬೋಧಿಸಲು ಪ್ರಾರಂಭಿಸಿದರು. ಮೊದಲನೆಯದು 'ಕಾಯಕ', ಅಂದರೆ ಕೆಲಸವೇ ಕೈಲಾಸ. ಯಾವುದೇ ಪ್ರಾಮಾಣಿಕ ಕೆಲಸವನ್ನು ಶುದ್ಧ ಹೃದಯದಿಂದ ಮಾಡಿದರೆ ಅದು ಪವಿತ್ರವಾದುದು ಎಂದು ಅವರು ಕಲಿಸಿದರು. ಜನರು ಸೋಮಾರಿಗಳಾಗಿ ಕುಳಿತುಕೊಳ್ಳುವುದನ್ನು ಅವರು ಇಷ್ಟಪಡುತ್ತಿರಲಿಲ್ಲ; ಪ್ರತಿಯೊಬ್ಬರೂ ಕಷ್ಟಪಟ್ಟು ಕೆಲಸ ಮಾಡಬೇಕೆಂದು ಮತ್ತು ತಮ್ಮ ಶ್ರಮದಲ್ಲಿ ಘನತೆಯನ್ನು ಕಾಣಬೇಕೆಂದು ಅವರು ಆಶಿಸಿದ್ದರು. ತಮ್ಮ ದೈನಂದಿನ ಕೆಲಸಗಳನ್ನು ಉತ್ತಮವಾಗಿ ಮಾಡುವುದರ ಮೂಲಕ, ಜನರು ತಮ್ಮ ಕ್ರಿಯೆಗಳಲ್ಲಿಯೇ ದೇವರನ್ನು ಕಾಣಬಹುದು ಎಂದು ಅವರು ಸಾರಿದರು. ಈ ಸರಳ ತತ್ವವು ಇಡೀ ಪ್ರದೇಶವನ್ನು ಬದಲಾಯಿಸಿತು, ಸಣ್ಣ ಮಕ್ಕಳಿಂದ ಹಿಡಿದು ವೃದ್ಧರವರೆಗೆ ಎಲ್ಲರೂ ತಮ್ಮ ದೈನಂದಿನ ಕೆಲಸವನ್ನು ಭಗವಂತನಿಗೆ ನೀಡುವ ಸುಂದರ ಅರ್ಪಣೆಯಾಗಿ ನೋಡಲು ಪ್ರಾರಂಭಿಸಿದರು.", "🌾"],
        ["The second great lesson he taught was 'Dasoha,' the act of selfless service and giving food to the hungry. Sharana Basaveshwara believed that no one should ever go to sleep with an empty stomach. He opened his doors to everyone, regardless of who they were or where they came from. He shared meals with the poor and the lonely, showing that true spirituality lies in feeding and caring for our fellow human beings. His kitchen was always busy, and his heart was even bigger. Through Dasoha, he taught children that sharing what we have is the greatest joy of all. This practice of community feeding brought people together, creating a large, loving family where everyone looked out for one another.", "ಅವರು ಕಲಿಸಿದ ಎರಡನೇ ಮಹಾನ್ ಪಾಠ 'ದಾಸೋಹ', ಅಂದರೆ ನಿಸ್ವಾರ್ಥ ಸೇವೆ ಮತ್ತು ಹಸಿದವರಿಗೆ ಅನ್ನ ನೀಡುವುದು. ಯಾರೂ ಹಸಿದ ಹೊಟ್ಟೆಯಿಂದ ಮಲಗಬಾರದು ಎಂದು ಶರಣ ಬಸವೇಶ್ವರರು ನಂಬಿದ್ದರು. ಅವರು ಯಾರು, ಎಲ್ಲಿಂದ ಬಂದವರು ಎಂಬ ಭೇದವಿಲ್ಲದೆ ಎಲ್ಲರಿಗೂ ತಮ್ಮ ಬಾಗಿಲನ್ನು ತೆರೆದರು. ಅವರು ಬಡವರು ಮತ್ತು ಒಂಟಿಗಳೊಂದಿಗೆ ಆಹಾರವನ್ನು ಹಂಚಿಕೊಂಡರು, ಸಹಜೀವಿಗಳಿಗೆ ಆಹಾರ ನೀಡುವುದು ಮತ್ತು ಕಾಳಜಿ ವಹಿಸುವುದೇ ನಿಜವಾದ ಆಧ್ಯಾತ್ಮಿಕತೆ ಎಂದು ತೋರಿಸಿಕೊಟ್ಟರು. ಅವರ ದಾಸೋಹದ ಮನೆ ಸದಾ ಚಟುವಟಿಕೆಯಿಂದ ಕೂಡಿರುತ್ತಿತ್ತು ಮತ್ತು ಅವರ ಹೃದಯ ಅದಕ್ಕಿಂತಲೂ ದೊಡ್ಡದಾಗಿತ್ತು. ನಮ್ಮಲ್ಲಿರುವುದನ್ನು ಹಂಚಿಕೊಳ್ಳುವುದೇ ಎಲ್ಲಕ್ಕಿಂತ ದೊಡ್ಡ ಸಂತೋಷ ಎಂದು ಅವರು ಮಕ್ಕಳಿಗೆ ಕಲಿಸಿದರು. ಈ ಸಮುದಾಯ ಭೋಜನದ ಪದ್ಧತಿಯು ಜನರನ್ನು ಒಗ್ಗೂಡಿಸಿತು ಮತ್ತು ಒಬ್ಬರಿಗೊಬ್ಬರು ಕಾಳಜಿ ವಹಿಸುವ ದೊಡ್ಡ ಪ್ರೀತಿಯ ಕುಟುಂಬವನ್ನು ಸೃಷ್ಟಿಸಿತು.", "🍲"],
        ["Sharana Basaveshwara spent his entire life, from 1707 to 1773, serving the people of North Karnataka. He became a beacon of hope during difficult times, always ready with a kind word and a helping hand. His fame as a saint of compassion spread far and wide, and people started calling him the 'Saint of Services.' He lived a life of total simplicity, never asking for anything for himself but always seeking more ways to help the needy. By the time he reached the end of his journey, he had built a foundation of peace and selfless service that would last for centuries. His samadhi temple in Kalaburagi stands today as a magnificent monument to his lifelong dedication to humanity.", "ಶರಣ ಬಸವೇಶ್ವರರು ೧೭೦೭ ರಿಂದ ೧೭೭೩ ರವರೆಗೆ ತಮ್ಮ ಇಡೀ ಜೀವನವನ್ನು ಉತ್ತರ ಕರ್ನಾಟಕದ ಜನರ ಸೇವೆಗಾಗಿ ಕಳೆದರು. ಕಷ್ಟದ ಸಮಯದಲ್ಲಿ ಅವರು ಭರವಸೆಯ ಬೆಳಕಾದರು, ಯಾವಾಗಲೂ ದಯೆಯ ಮಾತು ಮತ್ತು ಸಹಾಯದ ಹಸ್ತದೊಂದಿಗೆ ಸಿದ್ಧರಿರುತ್ತಿದ್ದರು. ಕರುಣೆಯ ಸಂತನಾಗಿ ಅವರ ಖ್ಯಾತಿಯು ದೂರದವರೆಗೆ ಹರಡಿತು ಮತ್ತು ಜನರು ಅವರನ್ನು 'ಸೇವೆಯ ಸಂತ' ಎಂದು ಕರೆಯಲು ಪ್ರಾರಂಭಿಸಿದರು. ಅವರು ಸಂಪೂರ್ಣ ಸರಳತೆಯ ಜೀವನವನ್ನು ನಡೆಸಿದರು, ತಮಗಾಗಿ ಏನನ್ನೂ ಕೇಳದೆ ಯಾವಾಗಲೂ ಅಗತ್ಯವಿರುವವರಿಗೆ ಸಹಾಯ ಮಾಡುವ ಮಾರ್ಗಗಳನ್ನು ಹುಡುಕುತ್ತಿದ್ದರು. ತಮ್ಮ ಜೀವನದ ಪಯಣದ ಅಂತ್ಯದ ವೇಳೆಗೆ, ಅವರು ಶತಮಾನಗಳ ಕಾಲ ಬಾಳಿಕೆ ಬರುವ ಶಾಂತಿ ಮತ್ತು ನಿಸ್ವಾರ್ಥ ಸೇವೆಯ ಬಲವಾದ ಅಡಿಪಾಯವನ್ನು ಹಾಕಿದ್ದರು. ಕಲಬುರಗಿಯಲ್ಲಿರುವ ಅವರ ಸಮಾಧಿ ದೇವಸ್ಥಾನವು ಮಾನವಕುಲಕ್ಕೆ ಅವರು ನೀಡಿದ ಜೀವಮಾನದ ಸಮರ್ಪಣೆಯ ಭವ್ಯ ಸ್ಮಾರಕವಾಗಿ ಇಂದಿಗೂ ನಿಂತಿದೆ.", "🛕"],
        ["Today, thousands of children and families visit the Sharana Basaveshwara Temple to pay their respects. Every year, a massive festival called a 'Jatre' is held, where lakhs of pilgrims gather to celebrate his life. They light colorful lamps and pull the grand temple chariot, remembering the saint who taught the world that work is sacred and sharing is divine. Even though he lived a long time ago, his spirit stays alive whenever we help a friend or work hard at school. He remains a hero of Karnataka because he showed us that the best way to love God is by loving and serving the people around us. His legacy continues to inspire kindness in every heart that hears his beautiful story.", "ಇಂದು, ಸಾವಿರಾರು ಮಕ್ಕಳು ಮತ್ತು ಕುಟುಂಬಗಳು ಶರಣ ಬಸವೇಶ್ವರ ದೇವಸ್ಥಾನಕ್ಕೆ ಭೇಟಿ ನೀಡಿ ಗೌರವ ಸಲ್ಲಿಸುತ್ತಾರೆ. ಪ್ರತಿ ವರ್ಷ ದೊಡ್ಡ 'ಜಾತ್ರೆ' ನಡೆಯುತ್ತದೆ, ಅಲ್ಲಿ ಲಕ್ಷಾಂತರ ಭಕ್ತರು ಅವರ ಜೀವನವನ್ನು ಆಚರಿಸಲು ಸೇರುತ್ತಾರೆ. ಜನರು ಬಣ್ಣಬಣ್ಣದ ದೀಪಗಳನ್ನು ಬೆಳಗಿಸುತ್ತಾರೆ ಮತ್ತು ಭವ್ಯವಾದ ರಥವನ್ನು ಎಳೆಯುತ್ತಾರೆ, ಕಾಯಕವೇ ಕೈಲಾಸ ಮತ್ತು ದಾಸೋಹವೇ ದೈವತ್ವ ಎಂದು ಕಲಿಸಿದ ಸಂತನನ್ನು ನೆನೆಯುತ್ತಾರೆ. ಅವರು ಬಹಳ ಹಿಂದೆಯೇ ಬದುಕಿದ್ದರೂ, ನಾವು ಸ್ನೇಹಿತರಿಗೆ ಸಹಾಯ ಮಾಡಿದಾಗ ಅಥವಾ ಶಾಲೆಯಲ್ಲಿ ಕಷ್ಟಪಟ್ಟು ಕೆಲಸ ಮಾಡಿದಾಗ ಅವರ ಚೇತನವು ಜೀವಂತವಾಗಿರುತ್ತದೆ. ದೇವರನ್ನು ಪ್ರೀತಿಸುವ ಅತ್ಯುತ್ತಮ ಮಾರ್ಗವೆಂದರೆ ನಮ್ಮ ಸುತ್ತಮುತ್ತಲಿನ ಜನರನ್ನು ಪ್ರೀತಿಸುವುದು ಮತ್ತು ಸೇವೆ ಮಾಡುವುದು ಎಂದು ಅವರು ನಮಗೆ ತೋರಿಸಿದ ಕಾರಣ ಅವರು ಕರ್ನಾಟಕದ ವೀರರಾಗಿದ್ದಾರೆ. ಅವರ ಪರಂಪರೆಯು ಅವರ ಸುಂದರ ಕಥೆಯನ್ನು ಕೇಳುವ ಪ್ರತಿಯೊಬ್ಬರ ಹೃದಯದಲ್ಲಿ ದಯೆಯನ್ನು ಪ್ರೇರೇಪಿಸುತ್ತಲೇ ಇರುತ್ತದೆ.", "🕯️"]
      ],
      quiz: [
        ["He served the…", "ಯಾರಿಗೆ?", ["Poor", "Kings", "Soldiers"], ["ಬಡವರಿಗೆ", "ರಾಜರು", "ಸೈನಿಕರು"], 0],
        ["Shrine is in…", "ಸಮಾಧಿ?", ["Kalaburagi", "Bidar", "Hampi"], ["ಕಲಬುರಗಿ", "ಬೀದರ್", "ಹಂಪಿ"], 0],
      
        ['Tradition?', 'ಪರಂಪರೆ?', ['Lingayat', 'Jain', 'Sikh'], ['ಲಿಂಗಾಯತ', 'ಜೈನ', 'ಸಿಖ್'], 0],
        ['Famous for serving…', 'ಸೇವೆ?', ['The poor', 'Soldiers', 'Kings'], ['ಬಡವರು', 'ಸೈನಿಕ', 'ರಾಜ'], 0],
        ['Shrine city?', 'ಸಮಾಧಿ ನಗರ?', ['Kalaburagi', 'Bidar', 'Hampi'], ['ಕಲಬುರಗಿ', 'ಬೀದರ್', 'ಹಂಪಿ'], 0],
        ["'Sharana' means…", 'ಶರಣ?', ['Devotee', 'King', 'Soldier'], ['ಭಕ್ತ', 'ರಾಜ', 'ಸೈನಿಕ'], 0],
        ['Annual fair held in his name?', 'ಜಾತ್ರೆ?', ['Yes', 'No', 'Sometimes'], ['ಹೌದು', 'ಇಲ್ಲ', 'ಕೆಲವೊಮ್ಮೆ'], 0],
        ['Region of Karnataka?', 'ಪ್ರದೇಶ?', ['Kalyana Karnataka', 'Coastal', 'Malnad'], ['ಕಲ್ಯಾಣ ಕರ್ನಾಟಕ', 'ಕರಾವಳಿ', 'ಮಲೆನಾಡು'], 0],
        ['He believed in…', 'ನಂಬಿಕೆ?', ['Service to humanity', 'War', 'Wealth'], ['ಮಾನವ ಸೇವೆ', 'ಯುದ್ಧ', 'ಸಂಪತ್ತು'], 0],
        ['His message inspires…', 'ಸ್ಫೂರ್ತಿ?', ['Devotion & service', 'Greed', 'Anger'], ['ಭಕ್ತಿ ಸೇವೆ', 'ಲೋಭ', 'ಕೋಪ'], 0],
      ],
      memorial: ["Sharana Basaveshwara Temple", "ಶರಣ ಬಸವೇಶ್ವರ ದೇವಾಲಯ", "Kalaburagi", "ಕಲಬುರಗಿ", "A grand temple at the heart of Kalaburagi.", "ಭವ್ಯ ದೇವಾಲಯ.", "Sharana Basaveshwara Temple Kalaburagi"],
    })],
  },
  {
    id: "kodagu", name: { en: "Kodagu", kn: "ಕೊಡಗು" }, emoji: "🌧️",
    heroes: [mkHero({
      id: "field-marshal-cariappa", emoji: "🎖️",
      name: ["Field Marshal K. M. Cariappa", "ಫೀಲ್ಡ್ ಮಾರ್ಷಲ್ ಕಾರ್ಯಪ್ಪ"],
      title: ["First Indian Army Chief", "ಮೊದಲ ಭಾರತೀಯ ಸೇನಾ ಮುಖ್ಯಸ್ಥ"],
      era: "1899 – 1993",
      pages: [
        ["Long ago, in the beautiful, misty hills of Kodagu in Karnataka, a brave boy named Kodandera Madappa Cariappa was born in a village called Shanivarsanthe. Growing up in the lush green landscapes of Madikeri, he was known for his discipline and love for his land. Young Cariappa was energetic and possessed a strong spirit, shaped by the brave traditions of his community. Even as a child, he dreamt of protecting his people and serving his country with honor. His journey from these quiet hills would one day lead him to become a legend, showing every child in Karnataka that with courage and dedication, any person from a small village can reach the highest peaks of success.", "ಬಹಳ ಹಿಂದೆಯೇ, ಕರ್ನಾಟಕದ ಕೊಡಗಿನ ಸುಂದರವಾದ ಬೆಟ್ಟಗಳಲ್ಲಿ, ಶನಿವಾರಸಂತೆ ಎಂಬ ಹಳ್ಳಿಯಲ್ಲಿ ಕೊಡಂದೇರ ಮಡಪ್ಪ ಕಾರ್ಯಪ್ಪ ಎಂಬ ಧೀರ ಹುಡುಗ ಜನಿಸಿದನು. ಮಡಿಕೇರಿಯ ಹಸಿರು ಪರಿಸರದಲ್ಲಿ ಬೆಳೆದ ಅವರು ತಮ್ಮ ಶಿಸ್ತು ಮತ್ತು ನಾಡಿನ ಮೇಲಿನ ಪ್ರೇಮಕ್ಕೆ ಹೆಸರುವಾಸಿಯಾಗಿದ್ದರು. ಯುವ ಕಾರ್ಯಪ್ಪ ಅವರು ಚಟುವಟಿಕೆಯಿಂದ ಕೂಡಿದ್ದರು ಮತ್ತು ತಮ್ಮ ಸಮುದಾಯದ ಶೌರ್ಯದ ಸಂಪ್ರದಾಯಗಳಿಂದ ಪ್ರಭಾವಿತರಾಗಿದ್ದರು. ಬಾಲ್ಯದಲ್ಲೇ ಅವರು ತಮ್ಮ ಜನರನ್ನು ರಕ್ಷಿಸುವ ಮತ್ತು ಗೌರವದಿಂದ ದೇಶದ ಸೇವೆ ಮಾಡುವ ಕನಸು ಕಂಡಿದ್ದರು. ಈ ಶಾಂತ ಬೆಟ್ಟಗಳಿಂದ ಪ್ರಾರಂಭವಾದ ಅವರ ಪ್ರಯಾಣವು ಒಂದು ದಿನ ಅವರನ್ನು ಮಹಾನ್ ವ್ಯಕ್ತಿಯನ್ನಾಗಿ ಮಾಡಿತು. ಧೈರ್ಯ ಮತ್ತು ಸಮರ್ಪಣಾ ಮನೋಭಾವವಿದ್ದರೆ ಸಣ್ಣ ಹಳ್ಳಿಯ ವ್ಯಕ್ತಿಯೂ ಯಶಸ್ಸಿನ ಉನ್ನತ ಶಿಖರಗಳನ್ನು ತಲುಪಬಹುದು ಎಂದು ಅವರು ಕರ್ನಾಟಕದ ಪ್ರತಿಯೊಬ್ಬ ಮಗುವಿಗೂ ತೋರಿಸಿಕೊಟ್ಟರು.", "⛰️"],
        ["As he grew older, Cariappa’s determination led him to join the army in 1919. At that time, India was still under British rule, and it was not easy for an Indian to rise to high positions. However, Cariappa worked harder than everyone else. He was the first Indian officer to undergo a prestigious training course in the United Kingdom, proving that Indians were second to none in leadership and strategy. He earned the respect of his peers through his impeccable dress, sharp manners, and deep intelligence. By learning everything he could about military tactics, he prepared himself for a future where he would lead his own countrymen toward a new era of freedom and strength.", "ಅವರು ಬೆಳೆಯುತ್ತಿದ್ದಂತೆ, ಕಾರ್ಯಪ್ಪ ಅವರ ದೃಢಸಂಕಲ್ಪವು 1919 ರಲ್ಲಿ ಅವರನ್ನು ಸೈನ್ಯಕ್ಕೆ ಸೇರುವಂತೆ ಮಾಡಿತು. ಆ ಸಮಯದಲ್ಲಿ ಭಾರತವು ಬ್ರಿಟಿಷರ ಆಳ್ವಿಕೆಯಲ್ಲಿತ್ತು ಮತ್ತು ಭಾರತೀಯರು ಉನ್ನತ ಹುದ್ದೆಗೇರುವುದು ಸುಲಭವಾಗಿರಲಿಲ್ಲ. ಆದಾಗ್ಯೂ, ಕಾರ್ಯಪ್ಪ ಅವರು ಎಲ್ಲರಿಗಿಂತ ಹೆಚ್ಚು ಶ್ರಮವಹಿಸಿ ಕೆಲಸ ಮಾಡಿದರು. ಯುನೈಟೆಡ್ ಕಿಂಗ್‌ಡಮ್‌ನಲ್ಲಿ ಪ್ರತಿಷ್ಠಿತ ತರಬೇತಿ ಪಡೆದ ಮೊದಲ ಭಾರತೀಯ ಅಧಿಕಾರಿ ಇವರಾಗಿದ್ದರು, ಭಾರತೀಯರು ನಾಯಕತ್ವ ಮತ್ತು ತಂತ್ರಜ್ಞಾನದಲ್ಲಿ ಯಾರಿಗೂ ಕಡಿಮೆ ಇಲ್ಲ ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು. ತಮ್ಮ ಅಚ್ಚುಕಟ್ಟಾದ ಉಡುಗೆ, ಚುರುಕಾದ ನಡವಳಿಕೆ ಮತ್ತು ಆಳವಾದ ಬುದ್ಧಿವಂತಿಕೆಯಿಂದ ಅವರು ಸಹೋದ್ಯೋಗಿಗಳ ಗೌರವ ಗಳಿಸಿದರು. ಮಿಲಿಟರಿ ತಂತ್ರಗಳ ಬಗ್ಗೆ ಎಲ್ಲವನ್ನೂ ಕಲಿಯುವ ಮೂಲಕ, ಅವರು ಸ್ವತಂತ್ರ ಭಾರತದ ಸೈನ್ಯವನ್ನು ಮುನ್ನಡೆಸಲು ತಮ್ಮನ್ನು ಸಿದ್ಧಪಡಿಸಿಕೊಂಡರು.", "💂"],
        ["The greatest test of his leadership came during the difficult years of 1947 and 1948. When India faced conflict in the Kashmir region, Cariappa was on the front lines, expertly directing the Indian forces to defend the borders. He was a leader who stood with his soldiers, giving them strength and hope during the cold winters and tough battles. His bravery and smart decisions saved many lives and protected the nation’s integrity. He believed that a soldier’s duty was always to the country first. Even when his own son, Air Marshal Nanda Cariappa, was later taken as a prisoner of war in 1965, he remained a true patriot, showing that for a commander, his duty to the law and the nation is above personal feelings.", "1947 ಮತ್ತು 1948 ರ ಕಷ್ಟದ ವರ್ಷಗಳಲ್ಲಿ ಅವರ ನಾಯಕತ್ವಕ್ಕೆ ದೊಡ್ಡ ಪರೀಕ್ಷೆ ಎದುರಾಯಿತು. ಕಾಶ್ಮೀರ ಪ್ರದೇಶದಲ್ಲಿ ಭಾರತವು ಸಂಘರ್ಷವನ್ನು ಎದುರಿಸಿದಾಗ, ಕಾರ್ಯಪ್ಪ ಅವರು ಮುಂಚೂಣಿಯಲ್ಲಿದ್ದು, ಗಡಿಗಳನ್ನು ರಕ್ಷಿಸಲು ಭಾರತೀಯ ಪಡೆಗಳನ್ನು ಸಮರ್ಥವಾಗಿ ಮುನ್ನಡೆಸಿದರು. ಅವರು ಚಳಿಗಾಲದ ಕಠಿಣ ಯುದ್ಧಗಳ ಸಮಯದಲ್ಲಿ ತಮ್ಮ ಸೈನಿಕರಿಗೆ ಶಕ್ತಿ ಮತ್ತು ಭರವಸೆಯನ್ನು ನೀಡಿದ ನಾಯಕರಾಗಿದ್ದರು. ಅವರ ಶೌರ್ಯ ಮತ್ತು ಬುದ್ಧಿವಂತ ನಿರ್ಧಾರಗಳು ಅನೇಕ ಜೀವಗಳನ್ನು ಉಳಿಸಿದವು ಮತ್ತು ರಾಷ್ಟ್ರದ ಸಮಗ್ರತೆಯನ್ನು ರಕ್ಷಿಸಿದವು. ಸೈನಿಕನ ಕರ್ತವ್ಯ ಯಾವಾಗಲೂ ದೇಶಕ್ಕೆ ಮೊದಲ ಆದ್ಯತೆ ಎಂದು ಅವರು ನಂಬಿದ್ದರು. ನಂತರ 1965 ರ ಯುದ್ಧದಲ್ಲಿ ಅವರ ಸ್ವಂತ ಮಗ ಏರ್ ಮಾರ್ಷಲ್ ನಂದಾ ಕಾರ್ಯಪ್ಪ ಯುದ್ಧ ಕೈದಿಯಾದಾಗಲೂ ಸಹ, ಅವರು ಒಬ್ಬ ಕಮಾಂಡರ್ ಆಗಿ ದೇಶದ ಮೇಲಿನ ಕರ್ತವ್ಯವೇ ವೈಯಕ್ತಿಕ ಭಾವನೆಗಳಿಗಿಂತ ಮಿಗಿಲು ಎಂದು ತೋರಿಸಿಕೊಟ್ಟರು.", "⚔️"],
        ["The most historic moment of his career arrived on January 15, 1949. On this grand day, he became the very first Indian to be appointed as the Commander-in-Chief of the Indian Army. This was a proud moment for every Indian, as the command of the army finally passed into Indian hands. Because of his incredible service and leadership, people began to call him ‘Kipper’ with affection. He was later honored with the highest rank of Field Marshal in 1986, becoming only the second person in Indian history to receive this five-star title. His life proved that discipline and love for one’s motherland could turn a young boy from Kodagu into one of the most respected generals in the whole world.", "ಜನವರಿ 15, 1949 ರಂದು ಅವರ ವೃತ್ತಿಜೀವನದ ಅತ್ಯಂತ ಐತಿಹಾಸಿಕ ಕ್ಷಣ ಬಂದಿತು. ಈ ಮಹಾನ್ ದಿನದಂದು, ಅವರು ಭಾರತೀಯ ಭೂಸೇನೆಯ ಪ್ರಧಾನ ಕಮಾಂಡರ್ ಆಗಿ ನೇಮಕಗೊಂಡ ಮೊದಲ ಭಾರತೀಯರಾದರು. ಸೈನ್ಯದ ನೇತೃತ್ವವು ಅಂತಿಮವಾಗಿ ಭಾರತೀಯರ ಕೈಗೆ ಬಂದಿದ್ದರಿಂದ ಇದು ಪ್ರತಿಯೊಬ್ಬ ಭಾರತೀಯನಿಗೂ ಹೆಮ್ಮೆಯ ಕ್ಷಣವಾಗಿತ್ತು. ಅವರ ಅದ್ಭುತ ಸೇವೆ ಮತ್ತು ನಾಯಕತ್ವಕ್ಕಾಗಿ ಜನರು ಅವರನ್ನು ಪ್ರೀತಿಯಿಂದ ‘ಕಿಪ್ಪರ್’ ಎಂದು ಕರೆಯುತ್ತಿದ್ದರು. ನಂತರ 1986 ರಲ್ಲಿ ಅವರಿಗೆ 'ಫೀಲ್ಡ್ ಮಾರ್ಷಲ್' ಎಂಬ ಅತ್ಯುನ್ನತ ಪದವಿಯನ್ನು ನೀಡಿ ಗೌರವಿಸಲಾಯಿತು, ಈ ಪಂಚತಾರಾ ಗೌರವ ಪಡೆದ ಭಾರತೀಯ ಇತಿಹಾಸದ ಎರಡನೇ ವ್ಯಕ್ತಿ ಇವರಾಗಿದ್ದಾರೆ. ಶಿಸ್ತು ಮತ್ತು ಮಾತೃಭೂಮಿಯ ಮೇಲಿನ ಪ್ರೀತಿಯು ಕೊಡಗಿನ ಒಬ್ಬ ಯುವಕನನ್ನು ವಿಶ್ವದ ಗೌರವಾನ್ವಿತ ಜನರಲ್‌ಗಳಲ್ಲಿ ಒಬ್ಬನನ್ನಾಗಿ ಮಾಡಬಹುದು ಎಂದು ಅವರ ಜೀವನವು ಸಾಬೀತುಪಡಿಸಿತು.", "🎖️"],
        ["Today, we celebrate January 15th every year as Army Day to remember the moment Field Marshal Cariappa took charge. His legacy lives on in every brave soldier who guards our borders. In Karnataka, we remember him as the ‘Son of the Soil’ who brought eternal glory to our state. He taught us that true leadership means being humble, honest, and courageous. Whenever you see the Indian flag flying high, remember the boy from the hills of Kodagu who worked tirelessly to keep it that way. Field Marshal Cariappa remains an inspiration for all children, reminding us to dream big and always serve our nation with a heart full of pride and bravery.", "ಇಂದು, ಫೀಲ್ಡ್ ಮಾರ್ಷಲ್ ಕಾರ್ಯಪ್ಪ ಅವರು ಅಧಿಕಾರ ವಹಿಸಿಕೊಂಡ ದಿನದ ನೆನಪಿಗಾಗಿ ನಾವು ಪ್ರತಿ ವರ್ಷ ಜನವರಿ 15 ರಂದು 'ಸೇನಾ ದಿನ'ವನ್ನು ಆಚರಿಸುತ್ತೇವೆ. ನಮ್ಮ ಗಡಿಗಳನ್ನು ಕಾಯುವ ಪ್ರತಿಯೊಬ್ಬ ಧೀರ ಸೈನಿಕನಲ್ಲಿ ಅವರ ಪರಂಪರೆ ಜೀವಂತವಾಗಿದೆ. ಕರ್ನಾಟಕದಲ್ಲಿ ಅವರನ್ನು ನಮ್ಮ ರಾಜ್ಯಕ್ಕೆ ಶಾಶ್ವತ ಕೀರ್ತಿ ತಂದ 'ಮಣ್ಣಿನ ಮಗ' ಎಂದು ನಾವು ನೆನಪಿಸಿಕೊಳ್ಳುತ್ತೇವೆ. ನೈಜ ನಾಯಕತ್ವ ಎಂದರೆ ವಿನಯತೆ, ಪ್ರಾಮಾಣಿಕತೆ ಮತ್ತು ಧೈರ್ಯ ಎಂದು ಅವರು ನಮಗೆ ಕಲಿಸಿಕೊಟ್ಟರು. ಭಾರತದ ಧ್ವಜವು ಎತ್ತರದಲ್ಲಿ ಹಾರಾಡುವುದನ್ನು ನೀವು ನೋಡಿದಾಗಲೆಲ್ಲಾ, ಅದನ್ನು ಹಾಗೆಯೇ ಇರಿಸಲು ದಣಿವರಿಯಿಲ್ಲದೆ ಶ್ರಮಿಸಿದ ಕೊಡಗಿನ ಆ ಹುಡುಗನನ್ನು ನೆನಪಿಸಿಕೊಳ್ಳಿ. ಫೀಲ್ಡ್ ಮಾರ್ಷಲ್ ಕಾರ್ಯಪ್ಪ ಅವರು ಎಲ್ಲಾ ಮಕ್ಕಳಿಗೆ ಸ್ಪೂರ್ತಿಯಾಗಿದ್ದಾರೆ, ದೊಡ್ಡ ಕನಸುಗಳನ್ನು ಕಾಣಲು ಮತ್ತು ಯಾವಾಗಲೂ ಹೆಮ್ಮೆ ಮತ್ತು ಶೌರ್ಯದಿಂದ ನಮ್ಮ ದೇಶದ ಸೇವೆ ಮಾಡಲು ಅವರು ನಮಗೆ ಪ್ರೇರೇಪಿಸುತ್ತಾರೆ.", "🇮🇳"]
      ],
      quiz: [
        ["He led which force?", "ಯಾವ ಪಡೆ?", ["Indian Army", "Navy", "Air Force"], ["ಸೇನೆ", "ನೌಕಾ", "ವಾಯು"], 0],
        ["He was the FIRST…", "ಮೊದಲ?", ["Indian Army Chief", "President", "PM"], ["ಸೇನಾ ಮುಖ್ಯಸ್ಥ", "ರಾಷ್ಟ್ರಪತಿ", "ಪ್ರಧಾನಿ"], 0],
      
        ['Force he led?', 'ಪಡೆ?', ['Indian Army', 'Navy', 'Air Force'], ['ಸೇನೆ', 'ನೌಕಾ', 'ವಾಯು'], 0],
        ['First Indian to be…', 'ಮೊದಲಿಗ?', ['Army Chief', 'President', 'PM'], ['ಸೇನಾ ಮುಖ್ಯಸ್ಥ', 'ರಾಷ್ಟ್ರಪತಿ', 'ಪ್ರಧಾನಿ'], 0],
        ['From which district?', 'ಜಿಲ್ಲೆ?', ['Kodagu', 'Mysuru', 'Bidar'], ['ಕೊಡಗು', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Highest rank held?', 'ಉನ್ನತ ಪದವಿ?', ['Field Marshal', 'Captain', 'Major'], ['ಫೀಲ್ಡ್ ಮಾರ್ಷಲ್', 'ಕ್ಯಾಪ್ಟನ್', 'ಮೇಜರ್'], 0],
        ['Took over Indian Army in…', 'ಯಾವ ವರ್ಷ?', ['1949', '1947', '1971'], ['೧೯೪೯', '೧೯೪೭', '೧೯೭೧'], 0],
        ['Nickname?', 'ಅಡ್ಡಹೆಸರು?', ['Kipper', 'Tiger', 'Lion'], ['ಕಿಪ್ಪರ್', 'ಹುಲಿ', 'ಸಿಂಹ'], 0],
        ['Army Day commemorates him on…', 'ಸೇನಾ ದಿನ?', ['15 Jan', '26 Jan', '15 Aug'], ['ಜ.೧೫', 'ಜ.೨೬', 'ಆ.೧೫'], 0],
        ['He fought in war of…', 'ಯುದ್ಧ?', ['1947 Kashmir', 'Kalinga', 'Plassey'], ['೧೯೪೭ ಕಾಶ್ಮೀರ', 'ಕಳಿಂಗ', 'ಪ್ಲಾಸಿ'], 0],
      ],
      memorial: ["Cariappa Memorial", "ಕಾರ್ಯಪ್ಪ ಸ್ಮಾರಕ", "Madikeri, Kodagu", "ಮಡಿಕೇರಿ", "His ancestral home museum.", "ಸೇನಾ ವಸ್ತುಸಂಗ್ರಹಾಲಯ.", "Cariappa memorial Madikeri"],
    })],
  },
  {
    id: "kolar", name: { en: "Kolar", kn: "ಕೋಲಾರ" }, emoji: "🪙",
    heroes: [mkHero({
      id: "kgf-miners", emoji: "⛏️",
      name: ["The Miners of Kolar Gold Fields", "ಕೆಜಿಎಫ್ ಗಣಿಗಾರರು"],
      title: ["The Brave Workers of KGF", "ಕೆಜಿಎಫ್ ಕಾರ್ಮಿಕರು"],
      era: "1880 – 2001",
      pages: [
        ["In the heart of Karnataka lies a land once famous as the Golden City. Starting in 1880, thousands of brave workers arrived at the Kolar Gold Fields to find treasure buried deep underground. These miners came from all over Karnataka and nearby Tamil Nadu, building a new home together. For over a century, their hard work turned a quiet district into one of the most important mining hubs in the entire world. These men were not just laborers; they were the pioneers who helped build the foundation of our state's industrial history. Under the management of John Taylor and Sons, they began a journey that would last for generations. Each day, they showed incredible courage as they prepared to enter the earth, hoping to bring wealth to the surface and provide a better future for their families.", "ಕರ್ನಾಟಕದ ಹೃದಯಭಾಗದಲ್ಲಿ ಒಂದು ಕಾಲದಲ್ಲಿ ಚಿನ್ನದ ನಗರಿ ಎಂದು ಪ್ರಸಿದ್ಧಿಯಾಗಿದ್ದ ಪ್ರದೇಶವಿದೆ. 1880ರಲ್ಲಿ ಪ್ರಾರಂಭಿಸಿ, ಸಾವಿರಾರು ಧೈರ್ಯಶಾಲಿ ಕಾರ್ಮಿಕರು ಭೂಮಿಯ ಆಳದಲ್ಲಿ ಹೂತುಹೋಗಿರುವ ನಿಧಿಯನ್ನು ಹುಡುಕಲು ಕೋಲಾರ ಚಿನ್ನದ ಗಣಿಗೆ ಆಗಮಿಸಿದರು. ಈ ಗಣಿಗಾರರು ಕರ್ನಾಟಕ ಮತ್ತು ನೆರೆಯ ತಮಿಳುನಾಡಿನಾದ್ಯಂತ ಬಂದವರು, ಎಲ್ಲರೂ ಸೇರಿ ಒಂದು ಹೊಸ ಮನೆಯನ್ನು ನಿರ್ಮಿಸಿದರು. ಒಂದು ಶತಮಾನಕ್ಕೂ ಹೆಚ್ಚು ಕಾಲ, ಅವರ ಕಠಿಣ ಪರಿಶ್ರಮವು ಒಂದು ಶಾಂತ ಜಿಲ್ಲೆಯನ್ನು ಇಡೀ ವಿಶ್ವದ ಪ್ರಮುಖ ಗಣಿಗಾರಿಕೆ ಕೇಂದ್ರವನ್ನಾಗಿ ಬದಲಾಯಿಸಿತು. ಈ ಮನುಷ್ಯರು ಕೇವಲ ಕಾರ್ಮಿಕರಲ್ಲ; ಅವರು ನಮ್ಮ ರಾಜ್ಯದ ಕೈಗಾರಿಕಾ ಇತಿಹಾಸದ ಅಡಿಪಾಯವನ್ನು ಹಾಕಲು ಸಹಾಯ ಮಾಡಿದ ಪ್ರವರ್ತಕರು. ಜಾನ್ ಟೇಲರ್ ಅಂಡ್ ಸನ್ಸ್ ನಿರ್ವಹಣೆಯಲ್ಲಿ, ಅವರು ತಲೆಮಾರುಗಳವರೆಗೆ ಉಳಿಯುವ ಪ್ರಯಾಣವನ್ನು ಪ್ರಾರಂಭಿಸಿದರು. ಪ್ರತಿದಿನ, ಅವರು ಭೂಮಿಯೊಳಗೆ ಪ್ರವೇಶಿಸಲು ಸಿದ್ಧರಾದಾಗ ಅದ್ಭುತ ಧೈರ್ಯವನ್ನು ತೋರಿಸುತ್ತಿದ್ದರು.", "⛏️"],
        ["Did you know that KGF was the very first town in India to get electricity? In 1902, a special hydroelectric project was built at Shivanasamudra Falls just to power the giant machines in the mines. While most of India was still using oil lamps, the Kolar Gold Fields were glowing with bright electric lights. This happened because the mines were becoming so deep that they needed powerful fans and lifts to keep the workers safe and moving. It was a marvel of technology for that era, showing how important the miners' work was to the country. The hum of electricity became the heartbeat of the town, powering the drills that chiseled through the hard rock. This progress made Kolar a modern wonder, attracting visitors from far and wide to see the glowing city and its deep gold mines.", "ಭಾರತದಲ್ಲಿ ವಿದ್ಯುತ್ ಪಡೆದ ಮೊದಲ ಪಟ್ಟಣ ಕೆಜಿಎಫ್ ಎಂದು ನಿಮಗೆ ತಿಳಿದಿದೆಯೇ? 1902 ರಲ್ಲಿ, ಗಣಿಗಳಲ್ಲಿನ ದೈತ್ಯ ಯಂತ್ರಗಳಿಗೆ ಶಕ್ತಿ ತುಂಬಲು ಶಿವನಸಮುದ್ರ ಜಲಪಾತದಲ್ಲಿ ವಿಶೇಷ ಜಲವಿದ್ಯುತ್ ಯೋಜನೆಯನ್ನು ನಿರ್ಮಿಸಲಾಯಿತು. ಭಾರತದ ಹೆಚ್ಚಿನ ಭಾಗಗಳು ಇನ್ನೂ ಎಣ್ಣೆ ದೀಪಗಳನ್ನು ಬಳಸುತ್ತಿದ್ದಾಗ, ಕೋಲಾರ ಚಿನ್ನದ ಗಣಿಗಳು ಪ್ರಕಾಶಮಾನವಾದ ವಿದ್ಯುತ್ ದೀಪಗಳಿಂದ ಬೆಳಗುತ್ತಿದ್ದವು. ಗಣಿಗಳು ಎಷ್ಟು ಆಳವಾಗಿದ್ದವು ಎಂದರೆ ಕಾರ್ಮಿಕರನ್ನು ಸುರಕ್ಷಿತವಾಗಿಡಲು ಶಕ್ತಿಯುತ ಫ್ಯಾನ್‌ಗಳು ಮತ್ತು ಲಿಫ್ಟ್‌ಗಳ ಅಗತ್ಯವಿದ್ದರಿಂದ ಇದು ಸಂಭವಿಸಿತು. ಆ ಕಾಲದ ತಂತ್ರಜ್ಞಾನದ ಅದ್ಭುತವಿದು, ಗಣಿಗಾರರ ಕೆಲಸವು ದೇಶಕ್ಕೆ ಎಷ್ಟು ಮುಖ್ಯವಾಗಿತ್ತು ಎಂಬುದನ್ನು ಇದು ತೋರಿಸುತ್ತದೆ. ವಿದ್ಯುತ್ ಶಬ್ದವು ಪಟ್ಟಣದ ಹೃದಯಬಡಿತವಾಯಿತು, ಗಟ್ಟಿಯಾದ ಬಂಡೆಯನ್ನು ಕೊರೆಯುವ ಡ್ರಿಲ್‌ಗಳಿಗೆ ಶಕ್ತಿ ನೀಡಿತು. ಈ ಪ್ರಗತಿಯು ಕೋಲಾರವನ್ನು ಆಧುನಿಕ ಅದ್ಭುತವನ್ನಾಗಿ ಮಾಡಿತು.", "⚡"],
        ["Working in the Kolar Gold Fields was one of the toughest jobs in the world. These mines reached depths of over 3 kilometers, making them some of the deepest holes ever dug by humans. Down there, the air was incredibly hot, and the pressure from the rocks above was immense. The brave miners faced many dangers every single shift, including sudden rock-bursts where the walls would explode from the weight of the earth. They also breathed in thick dust, which caused a lung disease called silicosis over time. Despite these scary conditions, the workers stayed strong and disciplined. They worked in shifts around the clock, hearing the constant sounds of heavy machinery and falling stones. Their resilience in such a dark and dangerous environment is why we remember them as heroes who sacrificed their health for the nation’s wealth.", "ಕೋಲಾರ ಚಿನ್ನದ ಗಣಿಗಳಲ್ಲಿ ಕೆಲಸ ಮಾಡುವುದು ವಿಶ್ವದ ಅತ್ಯಂತ ಕಠಿಣ ಕೆಲಸಗಳಲ್ಲಿ ಒಂದಾಗಿತ್ತು. ಈ ಗಣಿಗಳು 3 ಕಿಲೋಮೀಟರ್‌ಗಿಂತಲೂ ಹೆಚ್ಚು ಆಳವನ್ನು ತಲುಪಿದ್ದವು, ಇದು ಮಾನವರು ಅಗೆದ ಅತ್ಯಂತ ಆಳವಾದ ಗುಳಿಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ. ಅಲ್ಲಿ ಕೆಳಗೆ, ಗಾಳಿಯು ತುಂಬಾ ಬಿಸಿಯಾಗಿತ್ತು ಮತ್ತು ಮೇಲಿನ ಬಂಡೆಗಳಿಂದ ಒತ್ತಡವು ವಿಪರೀತವಾಗಿತ್ತು. ಧೈರ್ಯಶಾಲಿ ಗಣಿಗಾರರು ಪ್ರತಿ ಶಿಫ್ಟ್‌ನಲ್ಲಿಯೂ ಅನೇಕ ಅಪಾಯಗಳನ್ನು ಎದುರಿಸುತ್ತಿದ್ದರು, ಇದರಲ್ಲಿ ಭೂಮಿಯ ತೂಕದಿಂದ ಗೋಡೆಗಳು ಸ್ಫೋಟಗೊಳ್ಳುವ ಹಠಾತ್ ಬಂಡೆ-ಕುಸಿತಗಳು ಸೇರಿವೆ. ಅವರು ದಟ್ಟವಾದ ಧೂಳನ್ನು ಉಸಿರಾಡುತ್ತಿದ್ದರು, ಇದು ಕಾಲಾನಂತರದಲ್ಲಿ ಸಿಲಿಕೋಸಿಸ್ ಎಂಬ ಶ್ವಾಸಕೋಶದ ಕಾಯಿಲೆಗೆ ಕಾರಣವಾಯಿತು. ಇಂತಹ ಭಯಾನಕ ಪರಿಸ್ಥಿತಿಗಳ ನಡುವೆಯೂ ಕಾರ್ಮಿಕರು ದೃಢವಾಗಿ ಮತ್ತು ಶಿಸ್ತಿನಿಂದ ಉಳಿದರು. ಇಂತಹ ಕತ್ತಲೆ ಮತ್ತು ಅಪಾಯಕಾರಿ ವಾತಾವರಣದಲ್ಲಿ ಅವರ ಸ್ಥಿತಿಸ್ಥಾಪಕತ್ವವು ಅವರನ್ನು ನಾವು ವೀರರೆಂದು ನೆನಪಿಸಿಕೊಳ್ಳಲು ಕಾರಣವಾಗಿದೆ.", "🌋"],
        ["The miners created a vibrant and unique culture within the KGF township. People from different backgrounds lived together in tiny houses called 'lines,' sharing meals and celebrating festivals as one big family. Because of the British influence and the mixture of many languages, the town developed its own style of English and a beautiful blend of Kannada and Tamil customs. There were schools, hospitals, and social clubs that made KGF feel like a world of its own. Children of the miners grew up watching their fathers head to the shafts every morning, proud of the gold being sent to the national treasury. The community was tight-knit, supporting one another through hard times and celebrating the small joys of life. This unique culture made the Kolar Gold Fields a melting pot of traditions that still exists in the memories of the people who lived there.", "ಗಣಿಗಾರರು ಕೆಜಿಎಫ್ ಪಟ್ಟಣದಲ್ಲಿ ಒಂದು ರೋಮಾಂಚಕ ಮತ್ತು ವಿಶಿಷ್ಟ ಸಂಸ್ಕೃತಿಯನ್ನು ಸೃಷ್ಟಿಸಿದರು. ವಿವಿಧ ಹಿನ್ನೆಲೆಯ ಜನರು 'ಲೈನ್ಸ್' ಎಂದು ಕರೆಯಲ್ಪಡುವ ಸಣ್ಣ ಮನೆಗಳಲ್ಲಿ ಒಟ್ಟಿಗೆ ವಾಸಿಸುತ್ತಿದ್ದರು, ಊಟವನ್ನು ಹಂಚಿಕೊಳ್ಳುತ್ತಿದ್ದರು ಮತ್ತು ಹಬ್ಬಗಳನ್ನು ಒಂದು ದೊಡ್ಡ ಕುಟುಂಬದಂತೆ ಆಚರಿಸುತ್ತಿದ್ದರು. ಬ್ರಿಟಿಷ್ ಪ್ರಭಾವ ಮತ್ತು ಅನೇಕ ಭಾಷೆಗಳ ಮಿಶ್ರಣದಿಂದಾಗಿ, ಪಟ್ಟಣವು ತನ್ನದೇ ಆದ ಇಂಗ್ಲಿಷ್ ಶೈಲಿಯನ್ನು ಮತ್ತು ಕನ್ನಡ ಮತ್ತು ತಮಿಳು ಪದ್ಧತಿಗಳ ಸುಂದರ ಮಿಶ್ರಣವನ್ನು ಅಭಿವೃದ್ಧಿಪಡಿಸಿತು. ಅಲ್ಲಿ ಶಾಲೆಗಳು, ಆಸ್ಪತ್ರೆಗಳು ಮತ್ತು ಸಾಮಾಜಿಕ ಕ್ಲಬ್‌ಗಳಿದ್ದವು, ಅವು ಕೆಜಿಎಫ್ ಅನ್ನು ತನ್ನದೇ ಆದ ಪ್ರತ್ಯೇಕ ಜಗತ್ತನ್ನಾಗಿ ಮಾಡಿದವು. ಗಣಿಗಾರರ ಮಕ್ಕಳು ಪ್ರತಿದಿನ ಬೆಳಿಗ್ಗೆ ತಮ್ಮ ತಂದೆ ಗಣಿಯೊಳಗೆ ಹೋಗುವುದನ್ನು ನೋಡುತ್ತಾ ಬೆಳೆದರು. ಈ ವಿಶಿಷ್ಟ ಸಂಸ್ಕೃತಿಯು ಕೋಲಾರ ಚಿನ್ನದ ಗಣಿಗಳನ್ನು ಸಂಪ್ರದಾಯಗಳ ಸಂಗಮವನ್ನಾಗಿ ಮಾಡಿತು, ಇದು ಅಲ್ಲಿ ವಾಸಿಸುತ್ತಿದ್ದ ಜನರ ನೆನಪುಗಳಲ್ಲಿ ಇಂದಿಗೂ ಜೀವಂತವಾಗಿದೆ.", "🏙️"],
        ["In 2001, after 121 years of operation, the Kolar Gold Fields were finally closed because the gold became too difficult and expensive to reach. By then, the miners had extracted over 900 tonnes of gold for India. Even though the machinery has stopped and the deep tunnels are now filled with water, the legacy of the Brave Workers of KGF lives on. We honor them for their incredible strength and for the sacrifices they made to help India grow. Today, the tall headgears of the mine shafts stand like silent monuments in the Kolar district, reminding us of the thousands of men who once worked far beneath our feet. Their story teaches us about hard work, bravery, and the importance of remembering the people who labor behind the scenes to build our country's history and future.", "121 ವರ್ಷಗಳ ಕಾರ್ಯಾಚರಣೆಯ ನಂತರ, 2001 ರಲ್ಲಿ, ಚಿನ್ನವನ್ನು ತಲುಪುವುದು ತುಂಬಾ ಕಷ್ಟಕರ ಮತ್ತು ದುಬಾರಿಯಾದ ಕಾರಣ ಕೋಲಾರ ಚಿನ್ನದ ಗಣಿಗಳನ್ನು ಅಂತಿಮವಾಗಿ ಮುಚ್ಚಲಾಯಿತು. ಅಷ್ಟರ ಹೊತ್ತಿಗೆ, ಗಣಿಗಾರರು ಭಾರತಕ್ಕಾಗಿ 900 ಟನ್‌ಗಳಿಗಿಂತ ಹೆಚ್ಚು ಚಿನ್ನವನ್ನು ಹೊರತೆಗೆದಿದ್ದರು. ಈಗ ಯಂತ್ರೋಪಕರಣಗಳು ಸ್ಥಗಿತಗೊಂಡಿದ್ದರೂ ಮತ್ತು ಆಳವಾದ ಸುರಂಗಗಳು ನೀರಿನಿಂದ ತುಂಬಿದ್ದರೂ, ಕೆಜಿಎಫ್‌ನ ಧೈರ್ಯಶಾಲಿ ಕಾರ್ಮಿಕರ ಪರಂಪರೆಯು ಉಳಿದಿದೆ. ಭಾರತವು ಬೆಳೆಯಲು ಸಹಾಯ ಮಾಡಲು ಅವರು ಮಾಡಿದ ಅದ್ಭುತ ಶಕ್ತಿ ಮತ್ತು ತ್ಯಾಗಕ್ಕಾಗಿ ನಾವು ಅವರನ್ನು ಗೌರವಿಸುತ್ತೇವೆ. ಇಂದು, ಗಣಿ ಶಾಫ್ಟ್‌ಗಳ ಎತ್ತರದ ಹೆಡ್‌ಗೇರ್‌ಗಳು ಕೋಲಾರ ಜಿಲ್ಲೆಯಲ್ಲಿ ಮೌನ ಸ್ಮಾರಕಗಳಂತೆ ನಿಂತಿವೆ. ಅವರ ಕಥೆಯು ನಮಗೆ ಕಠಿಣ ಪರಿಶ್ರಮ, ಶೌರ್ಯ ಮತ್ತು ನಮ್ಮ ದೇಶದ ಇತಿಹಾಸವನ್ನು ನಿರ್ಮಿಸಲು ತೆರೆಯ ಮರೆಯಲ್ಲಿ ಶ್ರಮಿಸುವ ಜನರನ್ನು ನೆನಪಿಸಿಕೊಳ್ಳುವ ಪ್ರಾಮುಖ್ಯತೆಯನ್ನು ಕಲಿಸುತ್ತದೆ.", "🥇"]
      ],
      quiz: [
        ["KGF stands for…", "ಕೆಜಿಎಫ್?", ["Kolar Gold Fields", "Green Forest", "Gas Field"], ["ಚಿನ್ನದ ಗಣಿ", "ಹಸಿರು ಕಾಡು", "ಅನಿಲ"], 0],
        ["They dug for…", "ಏನು?", ["Gold", "Silver", "Coal"], ["ಚಿನ್ನ", "ಬೆಳ್ಳಿ", "ಕಲ್ಲಿದ್ದಲು"], 0],
      
        ['KGF is in district…', 'ಜಿಲ್ಲೆ?', ['Kolar', 'Mysuru', 'Bidar'], ['ಕೋಲಾರ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Mineral mined?', 'ಖನಿಜ?', ['Gold', 'Iron', 'Coal'], ['ಚಿನ್ನ', 'ಕಬ್ಬಿಣ', 'ಕಲ್ಲಿದ್ದಲು'], 0],
        ['Nickname of KGF?', 'ಅಡ್ಡಹೆಸರು?', ['Little England', 'Big India', 'New York'], ['ಲಿಟಲ್ ಇಂಗ್ಲೆಂಡ್', 'ಬಿಗ್ ಇಂಡಿಯಾ', 'ನ್ಯೂಯಾರ್ಕ್'], 0],
        ['Mines first opened by…', 'ಆರಂಭಿಸಿದವರು?', ['British', 'Mughals', 'Marathas'], ['ಬ್ರಿಟಿಷ್', 'ಮೊಘಲ್', 'ಮರಾಠ'], 0],
        ['Mines closed around…', 'ಮುಚ್ಚಿದ ವರ್ಷ?', ['2001', '1947', '1990'], ['೨೦೦೧', '೧೯೪೭', '೧೯೯೦'], 0],
        ['Famous for very…', 'ಆಳ?', ['Deep shafts', 'Wide rivers', 'Tall trees'], ['ಆಳವಾದ ಸುರಂಗ', 'ವಿಶಾಲ ನದಿ', 'ಎತ್ತರ ಮರ'], 0],
        ['Region in Karnataka?', 'ಪ್ರದೇಶ?', ['South', 'North', 'Coast'], ['ದಕ್ಷಿಣ', 'ಉತ್ತರ', 'ಕರಾವಳಿ'], 0],
        ['Workers were…', 'ಕಾರ್ಮಿಕ?', ['Brave miners', 'Soldiers', 'Sailors'], ['ಧೈರ್ಯಶಾಲಿ ಗಣಿಗಾರ', 'ಸೈನಿಕ', 'ನಾವಿಕ'], 0],
      ],
      memorial: ["KGF Mining Heritage", "ಕೆಜಿಎಫ್ ಪರಂಪರೆ", "Kolar Gold Fields", "ಕೆಜಿಎಫ್", "Old mining shafts tell their story.", "ಹಳೆ ಗಣಿಗಳು.", "Kolar Gold Fields KGF"],
    })],
  },
  {
    id: "koppal", name: { en: "Koppal", kn: "ಕೊಪ್ಪಳ" }, emoji: "🗿",
    heroes: [mkHero({
      id: "gavi-siddeshwara", emoji: "🪔",
      name: ["Gavi Siddeshwara Swamiji", "ಗವಿ ಸಿದ್ದೇಶ್ವರ ಸ್ವಾಮೀಜಿ"],
      title: ["Saint of the Cave Math", "ಗವಿ ಮಠದ ಸಂತ"],
      era: "Modern era",
      pages: [
        ["In the historic town of Koppal, there is a special place called Gavi Math. This math is built around an ancient, peaceful cave where long ago, great saints meditated. Today, the most respected leader of this holy place is Gavi Siddeshwara Swamiji. He belongs to the Lingayat tradition, which teaches that all people are equal and should be treated with kindness. Known as the 'Saint of the Cave Math,' Swamiji spends his days helping thousands of people. He lives a simple life but has very big dreams for the children of Karnataka. Because of his hard work, the cave temple has become a light of hope for everyone who visits it. He reminds us that even in the modern era, the old values of peace and service are the most important things we can keep in our hearts.", "ಕೊಪ್ಪಳದ ಐತಿಹಾಸಿಕ ಪಟ್ಟಣದಲ್ಲಿ ಗವಿಮಠ ಎಂಬ ವಿಶೇಷ ಸ್ಥಳವಿದೆ. ಈ ಮಠವನ್ನು ಪುರಾತನವಾದ, ಶಾಂತಿಯುತವಾದ ಗುಹೆಯ ಸುತ್ತಲೂ ನಿರ್ಮಿಸಲಾಗಿದೆ, ಅಲ್ಲಿ ಹಿಂದಿನ ಕಾಲದಲ್ಲಿ ಮಹಾನ್ ಸಂತರಾದವರು ತಪಸ್ಸು ಮಾಡಿದ್ದರು. ಇಂದು ಈ ಪವಿತ್ರ ಸ್ಥಳದ ಅತ್ಯಂತ ಗೌರವಾನ್ವಿತ ನಾಯಕರು ಶ್ರೀ ಗವಿಸಿದ್ಧೇಶ್ವರ ಸ್ವಾಮೀಜಿಯವರು. ಇವರು ಲಿಂಗಾಯತ ಸಂಪ್ರದಾಯಕ್ಕೆ ಸೇರಿದವರಾಗಿದ್ದು, ಎಲ್ಲ ಜನರನ್ನು ಸಮಾನವಾಗಿ ಕಾಣಬೇಕು ಮತ್ತು ದಯೆಯಿಂದ ನಡೆಸಿಕೊಳ್ಳಬೇಕು ಎಂದು ಬೋಧಿಸುತ್ತಾರೆ. 'ಗವಿಮಠದ ಸಂತರ' ಎಂದೇ ಖ್ಯಾತರಾಗಿರುವ ಸ್ವಾಮೀಜಿಯವರು ಸಾವಿರಾರು ಜನರಿಗೆ ಸಹಾಯ ಮಾಡುತ್ತಾ ತಮ್ಮ ದಿನಗಳನ್ನು ಕಳೆಯುತ್ತಾರೆ. ಅವರು ಸರಳ ಜೀವನವನ್ನು ನಡೆಸುತ್ತಾರಾದರೂ, ಕರ್ನಾಟಕದ ಮಕ್ಕಳಿಗಾಗಿ ದೊಡ್ಡ ಕನಸುಗಳನ್ನು ಹೊಂದಿದ್ದಾರೆ. ಅವರ ಕಠಿಣ ಪರಿಶ್ರಮದಿಂದಾಗಿ, ಈ ಗುಹಾಲಯವು ಭೇಟಿ ನೀಡುವ ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಭರವಸೆಯ ಬೆಳಕಾಗಿದೆ. ಆಧುನಿಕ ಯುಗದಲ್ಲೂ ಶಾಂತಿ ಮತ್ತು ಸೇವೆಯ ಹಳೆಯ ಮೌಲ್ಯಗಳೇ ಪ್ರಮುಖವಾದುದು ಎಂದು ಅವರು ನಮಗೆ ನೆನಪಿಸುತ್ತಾರೆ.", "🪔"],
        ["One of the most amazing things about Gavi Siddeshwara Swamiji is how he feeds anyone who is hungry. At the Gavi Math, there is a massive 'Prasada Nilaya' or free hostel. Every single day, thousands of students from villages and tribal areas come here to eat and stay for free. Swamiji believes that a hungry child cannot learn well, so he makes sure no one ever leaves without a meal. This tradition of 'Dasoha' or sharing food has been going on for many years, but Swamiji has made it grow even bigger. Whether you are rich or poor, or whatever your background may be, you are always welcome to sit and eat together. It is a beautiful sight to see so many children being cared for by the kind monks of the Math.", "ಶ್ರೀ ಗವಿಸಿದ್ಧೇಶ್ವರ ಸ್ವಾಮೀಜಿಯವರ ಬಗ್ಗೆ ಅತ್ಯಂತ ಅದ್ಭುತವಾದ ವಿಷಯವೆಂದರೆ ಅವರು ಹಸಿದ ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ಅನ್ನದಾನ ಮಾಡುವುದು. ಗವಿಮಠದಲ್ಲಿ ದಾಸೋಹ ನಿಲಯ ಅಥವಾ ಉಚಿತ ವಸತಿ ನಿಲಯವಿದೆ. ಪ್ರತಿದಿನ ಹಳ್ಳಿಗಳು ಮತ್ತು ಬುಡಕಟ್ಟು ಪ್ರದೇಶಗಳ ಸಾವಿರಾರು ವಿದ್ಯಾರ್ಥಿಗಳು ಇಲ್ಲಿ ಉಚಿತವಾಗಿ ಊಟ ಮಾಡಲು ಮತ್ತು ಉಳಿದುಕೊಳ್ಳಲು ಬರುತ್ತಾರೆ. ಹಸಿದ ಮಗು ಚೆನ್ನಾಗಿ ಕಲಿಯಲು ಸಾಧ್ಯವಿಲ್ಲ ಎಂದು ಸ್ವಾಮೀಜಿ ನಂಬುತ್ತಾರೆ, ಆದ್ದರಿಂದ ಯಾರೂ ಊಟವಿಲ್ಲದೆ ಮಠದಿಂದ ಹೊರಹೋಗದಂತೆ ಅವರು ನೋಡಿಕೊಳ್ಳುತ್ತಾರೆ. ಈ ದಾಸೋಹ ಅಥವಾ ಅನ್ನ ಹಂಚುವ ಸಂಪ್ರದಾಯವು ಹಲವು ವರ್ಷಗಳಿಂದ ನಡೆಯುತ್ತಿದೆ, ಆದರೆ ಸ್ವಾಮೀಜಿಯವರು ಇದನ್ನು ಇನ್ನಷ್ಟು ದೊಡ್ಡದಾಗಿ ಬೆಳೆಸಿದ್ದಾರೆ. ನೀವು ಶ್ರೀಮಂತರಾಗಿರಲಿ ಅಥವಾ ಬಡವರಾಗಿರಲಿ, ನಿಮ್ಮ ಹಿನ್ನೆಲೆ ಏನೇ ಇರಲಿ, ಇಲ್ಲಿ ಎಲ್ಲರೂ ಒಟ್ಟಾಗಿ ಕುಳಿತು ಊಟ ಮಾಡಲು ಯಾವಾಗಲೂ ಸ್ವಾಗತವಿದೆ.", "🍲"],
        ["Swamiji knows that education is the key to a bright future for every child. He has started many schools and colleges through the Math to help rural children get a good education. Many of these students come from very poor families or remote tribal areas where schools are hard to find. Because of Swamiji’s help, these children get tools like books, uniforms, and a safe place to study. He also cares deeply about healthcare and organized many medical camps to help the sick. By building schools and hospitals, Swamiji is making sure that the children of Koppal and nearby districts grow up to be healthy and smart leaders. He teaches the students that through hard work and good character, they can achieve anything they want in life.", "ಪ್ರತಿಯೊಂದು ಮಗುವಿನ ಉಜ್ವಲ ಭವಿಷ್ಯಕ್ಕೆ ಶಿಕ್ಷಣವೇ ಪ್ರಮುಖ ಅಸ್ತ್ರ ಎಂದು ಸ್ವಾಮೀಜಿ ತಿಳಿದಿದ್ದಾರೆ. ಗ್ರಾಮೀಣ ಮಕ್ಕಳಿಗೆ ಉತ್ತಮ ಶಿಕ್ಷಣ ದೊರೆಯುವಂತೆ ಮಾಡಲು ಅವರು ಮಠದ ಮೂಲಕ ಹಲವು ಶಾಲೆ ಮತ್ತು ಕಾಲೇಜುಗಳನ್ನು ಪ್ರಾರಂಭಿಸಿದ್ದಾರೆ. ಈ ವಿದ್ಯಾರ್ಥಿಗಳಲ್ಲಿ ಅನೇಕರು ಅತ್ಯಂತ ಬಡ ಕುಟುಂಬಗಳಿಂದ ಅಥವಾ ಶಾಲೆಗಳು ಸಿಗದ ದೂರದ ಬುಡಕಟ್ಟು ಪ್ರದೇಶಗಳಿಂದ ಬಂದವರು. ಸ್ವಾಮೀಜಿಯವರ ಸಹಾಯದಿಂದ, ಈ ಮಕ್ಕಳಿಗೆ ಪುಸ್ತಕಗಳು, ಸಮವಸ್ತ್ರಗಳು ಮತ್ತು ಓದಲು ಸುರಕ್ಷಿತ ಸ್ಥಳದಂತಹ ಸೌಲಭ್ಯಗಳು ಸಿಗುತ್ತಿವೆ. ಅವರು ಆರೋಗ್ಯ ರಕ್ಷಣೆಯ ಬಗ್ಗೆಯೂ ಅಪಾರ ಕಾಳಜಿಯನ್ನು ಹೊಂದಿದ್ದು, ಅನಾರೋಗ್ಯ ಪೀಡಿತರಿಗೆ ಸಹಾಯ ಮಾಡಲು ಅನೇಕ ವೈದ್ಯಕೀಯ ಶಿಬಿರಗಳನ್ನು ಆಯೋಜಿಸಿದ್ದಾರೆ. ಶಾಲೆ ಮತ್ತು ಆಸ್ಪತ್ರೆಗಳನ್ನು ನಿರ್ಮಿಸುವ ಮೂಲಕ, ಸ್ವಾಮೀಜಿಯವರು ಕೊಪ್ಪಳ ಮತ್ತು ಹತ್ತಿರದ ಜಿಲ್ಲೆಗಳ ಮಕ್ಕಳು ಆರೋಗ್ಯವಂತರಾಗಿ ಮತ್ತು ಬುದ್ಧಿವಂತರಾಗಿ ಬೆಳೆಯುವುದನ್ನು ಖಚಿತಪಡಿಸುತ್ತಿದ್ದಾರೆ.", "🏫"],
        ["Every year, a giant festival called the 'Gavi Siddeshwara Jatre' takes place in Koppal. It is one of the biggest fairs in all of South India! Thousands of pilgrims travel from different states like Karnataka, Andhra Pradesh, and Maharashtra to be a part of this celebration. The streets become full of colorful decorations, music, and happy people. Even though it is a religious festival, it actually brings people of all castes and religions together like one big family. During the jatre, Swamiji gives inspiring speeches about why we should help our neighbors and protect our environment. He often encourages people to plant trees and save water, showing that being a saint also means taking care of Mother Earth. It is a time of great joy where everyone learns to live in harmony.", "ಪ್ರತಿ ವರ್ಷ ಕೊಪ್ಪಳದಲ್ಲಿ 'ಗವಿಸಿದ್ಧೇಶ್ವರ ಜಾತ್ರೆ' ಎಂಬ ಬೃಹತ್ ಉತ್ಸವ ನಡೆಯುತ್ತದೆ. ಇದು ಇಡೀ ದಕ್ಷಿಣ ಭಾರತದಲ್ಲೇ ಅತ್ಯಂತ ದೊಡ್ಡ ಜಾತ್ರೆಗಳಲ್ಲಿ ಒಂದಾಗಿದೆ! ಕರ್ನಾಟಕ, ಆಂಧ್ರಪ್ರದೇಶ ಮತ್ತು ಮಹಾರಾಷ್ಟ್ರದಂತಹ ವಿವಿಧ ರಾಜ್ಯಗಳಿಂದ ಸಾವಿರಾರು ಯಾತ್ರಿಕರು ಈ ಸಂಭ್ರಮದಲ್ಲಿ ಪಾಲ್ಗೊಳ್ಳಲು ಬರುತ್ತಾರೆ. ಬೀದಿಗಳೆಲ್ಲಾ ವರ್ಣರಂಜಿತ ಅಲಂಕಾರಗಳು, ಸಂಗೀತ ಮತ್ತು ಸಂತೋಷದ ಜನರಿಂದ ತುಂಬಿರುತ್ತವೆ. ಇದೊಂದು ಧಾರ್ಮಿಕ ಹಬ್ಬವಾಗಿದ್ದರೂ, ಇದು ಎಲ್ಲಾ ಜಾತಿ ಮತ್ತು ಧರ್ಮದ ಜನರನ್ನು ಒಂದು ದೊಡ್ಡ ಕುಟುಂಬದಂತೆ ಒಗ್ಗೂಡಿಸುತ್ತದೆ. ಜಾತ್ರೆಯ ಸಮಯದಲ್ಲಿ, ಸ್ವಾಮೀಜಿಯವರು ನಾವು ನೆರೆಹೊರೆಯವರಿಗೆ ಏಕೆ ಸಹಾಯ ಮಾಡಬೇಕು ಮತ್ತು ಪರಿಸರವನ್ನು ಹೇಗೆ ರಕ್ಷಿಸಬೇಕು ಎಂಬುದರ ಬಗ್ಗೆ ಸ್ಪೂರ್ತಿದಾಯಕ ಭಾಷಣಗಳನ್ನು ನೀಡುತ್ತಾರೆ. ಅವರು ಗಿಡಗಳನ್ನು ನೆಡಲು ಮತ್ತು ನೀರನ್ನು ಉಳಿಸಲು ಜನರನ್ನು ಪ್ರೋತ್ಸಾಹಿಸುತ್ತಾರೆ, ಇದು ಸಂತನಾಗಿರುವುದು ಎಂದರೆ ಭೂತಾಯಿಯನ್ನು ಕಾಳಜಿ ಮಾಡುವುದು ಕೂಡ ಹೌದು ಎಂದು ತೋರಿಸಿಕೊಡುತ್ತದೆ.", "🎡"],
        ["The story of Gavi Siddeshwara Swamiji teaches us that the greatest power in the world is the power of service. By treating everyone with the same love, regardless of where they come from, he has become a true hero for the people of Karnataka. He shows us that being a saint is not just about praying in a cave, but about working hard every day to make other people’s lives better. Whether it is through free food, schools, or protecting nature, Swamiji’s life is an example for every young person to follow. As you grow up, remember the lessons of the Cave Math: be kind, share what you have, and always help those in need. Just like Swamiji, you too can bring light and happiness to the world around you with your good deeds.", "ಶ್ರೀ ಗವಿಸಿದ್ಧೇಶ್ವರ ಸ್ವಾಮೀಜಿಯವರ ಕಥೆಯು ವಿಶ್ವದ ಅತಿದೊಡ್ಡ ಶಕ್ತಿ ಎಂದರೆ ಅದು ಸೇವೆಯ ಶಕ್ತಿ ಎಂದು ನಮಗೆ ಕಲಿಸುತ್ತದೆ. ಎಲ್ಲರನ್ನೂ ಒಂದೇ ಪ್ರೀತಿಯಿಂದ ಕಾಣುವ ಮೂಲಕ, ಅವರು ಕರ್ನಾಟಕದ ಜನರ ಪಾಲಿನ ನಿಜವಾದ ನಾಯಕರಾಗಿದ್ದಾರೆ. ಸಂತನಾಗಿರುವುದು ಎಂದರೆ ಕೇವಲ ಗುಹೆಯಲ್ಲಿ ಪ್ರಾರ್ಥಿಸುವುದು ಮಾತ್ರವಲ್ಲ, ಬದಲಾಗಿ ಇತರ ಜನರ ಜೀವನವನ್ನು ಉತ್ತಮಗೊಳಿಸಲು ಪ್ರತಿದಿನ ಶ್ರಮಿಸುವುದು ಎಂದು ಅವರು ನಮಗೆ ತೋರಿಸಿಕೊಟ್ಟಿದ್ದಾರೆ. ಉಚಿತ ಆಹಾರವಾಗಲಿ, ಶಾಲೆಗಳಾಗಲಿ ಅಥವಾ ಪ್ರಕೃತಿಯನ್ನು ರಕ್ಷಿಸುವುದಾಗಲಿ, ಸ್ವಾಮೀಜಿಯವರ ಜೀವನವು ಪ್ರತಿಯೊಬ್ಬ ಯುವಕರಿಗೂ ಅನುಸರಿಸಬೇಕಾದ ಮಾದರಿಯಾಗಿದೆ. ನೀವು ಬೆಳೆಯುತ್ತಿದ್ದಂತೆ ಗವಿಮಠದ ಪಾಠಗಳನ್ನು ನೆನಪಿಡಿ: ದಯೆ ತೋರಿರಿ, ನಿಮ್ಮಲ್ಲಿರುವುದನ್ನು ಹಂಚಿಕೊಳ್ಳಿ ಮತ್ತು ಅಗತ್ಯವಿರುವವರಿಗೆ ಯಾವಾಗಲೂ ಸಹಾಯ ಮಾಡಿ. ಸ್ವಾಮೀಜಿಯಂತೆಯೇ, ನೀವು ಸಹ ನಿಮ್ಮ ಸತ್ಕರ್ಮಗಳ ಮೂಲಕ ನಿಮ್ಮ ಸುತ್ತಲಿನ ಜಗತ್ತಿಗೆ ಬೆಳಕು ಮತ್ತು ಸಂತೋಷವನ್ನು ತರಬಹುದು.", "🌟"]
      ],
      quiz: [
        ["His math is at…", "ಮಠ?", ["Koppal", "Hubballi", "Mysuru"], ["ಕೊಪ್ಪಳ", "ಹುಬ್ಬಳ್ಳಿ", "ಮೈಸೂರು"], 0],
        ["He gave children…", "ಮಕ್ಕಳಿಗೆ?", ["Food & education", "Toys", "Coins"], ["ಊಟ ಶಿಕ್ಷಣ", "ಆಟಿಕೆ", "ನಾಣ್ಯ"], 0],
      
        ['His math is at?', 'ಮಠ?', ['Koppal', 'Hampi', 'Bidar'], ['ಕೊಪ್ಪಳ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['He served children with?', 'ಮಕ್ಕಳಿಗೆ?', ['Food & education', 'Toys', 'Coins'], ['ಊಟ-ಶಿಕ್ಷಣ', 'ಆಟಿಕೆ', 'ನಾಣ್ಯ'], 0],
        ['He was a saint of…', 'ಪಂಥ?', ['Lingayat', 'Vaishnava', 'Jain'], ['ಲಿಂಗಾಯತ', 'ವೈಷ್ಣವ', 'ಜೈನ'], 0],
        ['Annual fair is called…', 'ಜಾತ್ರೆ?', ['Gavisiddeshwara Jatra', 'Mysuru Dasara', 'Hampi Utsava'], ['ಗವಿಸಿದ್ಧೇಶ್ವರ ಜಾತ್ರೆ', 'ಮೈಸೂರು ದಸರಾ', 'ಹಂಪಿ ಉತ್ಸವ'], 0],
        ['Math built around a…', 'ಯಾವುದರ ಸುತ್ತ?', ['Cave', 'Lake', 'Forest'], ['ಗವಿ', 'ಸರೋವರ', 'ಕಾಡು'], 0],
        ['Region?', 'ಪ್ರದೇಶ?', ['Kalyana Karnataka', 'Malnad', 'Coast'], ['ಕಲ್ಯಾಣ ಕರ್ನಾಟಕ', 'ಮಲೆನಾಡು', 'ಕರಾವಳಿ'], 0],
        ['People love him for…', 'ಪ್ರೀತಿ?', ['Selfless service', 'Wars', 'Wealth'], ['ನಿಸ್ವಾರ್ಥ ಸೇವೆ', 'ಯುದ್ಧ', 'ಸಂಪತ್ತು'], 0],
        ["'Gavi' means…", 'ಗವಿ?', ['Cave', 'River', 'Hill'], ['ಗುಹೆ', 'ನದಿ', 'ಬೆಟ್ಟ'], 0],
      ],
      memorial: ["Gavi Math", "ಗವಿ ಮಠ", "Koppal", "ಕೊಪ್ಪಳ", "A spiritual centre carved into ancient caves.", "ಗವಿಗಳ ಆಧ್ಯಾತ್ಮಿಕ ಕೇಂದ್ರ.", "Gavi Math Koppal"],
    })],
  },
  {
    id: "mandya", name: { en: "Mandya", kn: "ಮಂಡ್ಯ" }, emoji: "🌾",
    heroes: [mkHero({
      id: "k-v-shankaregowda", emoji: "🌾",
      name: ["K. V. Shankaregowda", "ಕೆ. ವಿ. ಶಂಕರೇಗೌಡ"],
      title: ["Friend of the Farmers", "ರೈತರ ಮಿತ್ರ"],
      era: "1908 – 1979",
      pages: [
        ["In the heart of Mandya, Karnataka, lived a man named K. V. Shankaregowda who loved his soil and his people. Born in 1908, he grew up during a time when India was fighting for its freedom. While many people sought fame, he chose a simple life centered around the needs of rural folks. Because he always wore white khadi and lived very modestly, everyone affectionately called him 'Mandya Gandhi.' He believed that the strength of our country lived in its hardworking farmers. From a young age, he dedicated his energy to making sure that those who tilled the land were respected and supported. Shankaregowda was not just a politician; he was a true social worker who walked among the villages, listening to stories of hardship and dreaming of a brighter, greener future for every family in Mandya.", "ಕರ್ನಾಟಕದ ಮಂಡ್ಯ ಜಿಲ್ಲೆಯಲ್ಲಿ ಕೆ. ವಿ. ಶಂಕರೇಗೌಡ ಎಂಬ ಮಹಾನ್ ವ್ಯಕ್ತಿ ವಾಸಿಸುತ್ತಿದ್ದರು. ಇವರು ತಮ್ಮ ನೆಲ ಮತ್ತು ಜನರನ್ನು ಅಪಾರವಾಗಿ ಪ್ರೀತಿಸುತ್ತಿದ್ದರು. ೧೯೦೮ ರಲ್ಲಿ ಜನಿಸಿದ ಇವರು ಭಾರತದ ಸ್ವಾತಂತ್ರ್ಯ ಹೋರಾಟದ ಸಮಯದಲ್ಲಿ ಬೆಳೆದರು. ಅನೇಕರು ಪ್ರಸಿದ್ಧಿಗಾಗಿ ಹಂಬಲಿಸಿದರೆ, ಇವರು ಗ್ರಾಮೀಣ ಜನರ ಅವಶ್ಯಕತೆಗಳಿಗಾಗಿ ಸರಳ ಜೀವನವನ್ನು ಆರಿಸಿಕೊಂಡರು. ಇವರು ಯಾವಾಗಲೂ ಬಿಳಿ ಖಾದಿ ಧರಿಸಿ ಸರಳವಾಗಿ ಬದುಕಿದ್ದರಿಂದ, ಜನರೆಲ್ಲರೂ ಇವರನ್ನು ಪ್ರೀತಿಯಿಂದ 'ಮಂಡ್ಯದ ಗಾಂಧಿ' ಎಂದು ಕರೆಯುತ್ತಿದ್ದರು. ಇವರು ರೈತರಲ್ಲೇ ದೇಶದ ಶಕ್ತಿಯಿದೆ ಎಂದು ನಂಬಿದ್ದರು. ಚಿಕ್ಕ ವಯಸ್ಸಿನಿಂದಲೇ ಇವರು ರೈತರ ಗೌರವಕ್ಕಾಗಿ ಶ್ರಮಿಸಿದರು. ಶಂಕರೇಗೌಡರು ಕೇವಲ ರಾಜಕಾರಣಿಯಲ್ಲದೆ, ಹಳ್ಳಿ ಹಳ್ಳಿಗಳಿಗೆ ಹೋಗಿ ಜನರ ಕಷ್ಟಗಳನ್ನು ಆಲಿಸುವ ಮತ್ತು ಮಂಡ್ಯದ ಪ್ರತಿ ಕುಟುಂಬದ ಕನಸುಗಳನ್ನು ನನಸು ಮಾಡುವ ಸಮಾಜ ಸೇವಕರಾಗಿದ್ದರು.", "🚜"],
        ["Shankaregowda saw a massive change when the Krishna Raja Sagara dam began providing water to the dry lands of Mandya. However, he knew that water alone wasn't enough; the farmers needed a way to earn a steady income. To solve this, he played a pivotal role in establishing the Mysore Sugar Company, popularly known as Mysugar. This was framed as a cooperative effort where the farmers themselves were the stars of the industry. By creating a place where sugarcane could be processed into sugar locally, he ensured that the profits stayed with the community. This brilliant move transformed Mandya from a quiet district into the sugarcane and sugar capital of Karnataka. His vision helped thousands of families turn their hard work into sweet success, proving that cooperation is the best tool for development.", "ಕೃಷ್ಣರಾಜ ಸಾಗರ ಅಣೆಕಟ್ಟು ನಿರ್ಮಾಣವಾಗಿ ಮಂಡ್ಯದ ಭೂಮಿಗೆ ನೀರು ಬಂದಾಗ ಶಂಕರೇಗೌಡರು ಒಂದು ದೊಡ್ಡ ಬದಲಾವಣೆಯನ್ನೇ ಕಂಡರು. ಕೇವಲ ನೀರಿದ್ದರೆ ಸಾಲದು, ರೈತರಿಗೆ ಆದಾಯದ ಮಾರ್ಗವೂ ಬೇಕು ಎಂದು ಅವರು ಅರಿತಿದ್ದರು. ಇದಕ್ಕಾಗಿಯೇ ಅವರು 'ಮೈಸೂರು ಶುಗರ್ ಕಂಪನಿ' (ಮೈಶುಗರ್) ಸ್ಥಾಪಿಸುವಲ್ಲಿ ಪ್ರಮುಖ ಪಾತ್ರ ವಹಿಸಿದರು. ಇದು ರೈತರೇ ಮಾಲೀಕರಾಗಿರುವ ಸಹಕಾರಿ ಸಂಸ್ಥೆಯಾಗಿತ್ತು. ಕಬ್ಬನ್ನು ಸ್ಥಳೀಯವಾಗಿ ಸಕ್ಕರೆಯನ್ನಾಗಿ ಪರಿವರ್ತಿಸುವ ಘಟಕವನ್ನು ಸ್ಥಾಪಿಸುವ ಮೂಲಕ, ಅದರ ಲಾಭವು ರೈತರಿಗೇ ಸಿಗುವಂತೆ ಮಾಡಿದರು. ಈ ಅದ್ಭುತ ಕೆಲಸದಿಂದಾಗಿ ಮಂಡ್ಯವು ಕರ್ನಾಟಕದ 'ಸಕ್ಕರೆ ನಾಡು' ಎಂದು ಹೆಸರುವಾಸಿಯಾಯಿತು. ಸಾವಿರಾರು ರೈತ ಕುಟುಂಬಗಳ ಶ್ರಮಕ್ಕೆ ಸಿಹಿ ಫಲ ಸಿಗುವಂತೆ ಮಾಡಿದ ಇವರ ದೂರದೃಷ್ಟಿಯು, ಸಹಕಾರವೇ ಅಭಿವೃದ್ಧಿಯ ಮೂಲಮಂತ್ರ ಎಂದು ಸಾಬೀತುಪಡಿಸಿತು.", "🌾"],
        ["While he was busy building industries for farmers, Shankaregowda never forgot the power of education. He firmly believed that the children of farmers deserved the best schools and colleges. In 1962, he took a bold step by founding the People's Education Society (PES) Trust. He wanted to provide high-quality learning opportunities right in Mandya so that village students wouldn't have to travel far to the big cities. Today, this trust has grown into the famous PES University and many other institutions that teach thousands of students every year. He looked at every child as a future leader and worked tirelessly to build classrooms where minds could grow. By building these schools, he gave the youth of Karnataka the greatest gift possible—the gift of knowledge and the chance to build their own bright careers.", "ರೈತರಿಗಾಗಿ ಕೈಗಾರಿಕೆಗಳನ್ನು ಕಟ್ಟುವಲ್ಲಿ ನಿರತರಾಗಿದ್ದರೂ, ಶಂಕರೇಗೌಡರು ಶಿಕ್ಷಣದ ಶಕ್ತಿಯನ್ನು ಎಂದಿಗೂ ಮರೆಯಲಿಲ್ಲ. ರೈತರ ಮಕ್ಕಳಿಗೆ ಅತ್ಯುತ್ತಮ ಶಾಲೆ ಮತ್ತು ಕಾಲೇಜುಗಳು ಸಿಗಬೇಕೆಂದು ಅವರು ದೃಢವಾಗಿ ನಂಬಿದ್ದರು. ೧೯೬೨ ರಲ್ಲಿ ಅವರು 'ಪೀಪಲ್ಸ್ ಎಜುಕೇಶನ್ ಸೊಸೈಟಿ' (ಪಿ.ಇ.ಎಸ್) ಸಂಸ್ಥೆಯನ್ನು ಸ್ಥಾಪಿಸುವ ಮೂಲಕ ಧೈರ್ಯದ ಹೆಜ್ಜೆ ಇಟ್ಟರು. ಹಳ್ಳಿಯ ವಿದ್ಯಾರ್ಥಿಗಳು ಶಿಕ್ಷಣಕ್ಕಾಗಿ ದೊಡ್ಡ ನಗರಗಳಿಗೆ ಹೋಗಬಾರದು ಎಂಬುದು ಅವರ ಆಸೆಯಾಗಿತ್ತು. ಇಂದು ಈ ಸಂಸ್ಥೆಯು ಪ್ರಸಿದ್ಧ ಪಿ.ಇ.ಎಸ್ ವಿಶ್ವವಿದ್ಯಾಲಯವಾಗಿ ಬೆಳೆದಿದ್ದು, ಪ್ರತಿ ವರ್ಷ ಸಾವಿರಾರು ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಜ್ಞಾನ ನೀಡುತ್ತಿದೆ. ಪ್ರತಿಯೊಂದು ಮಗುವನ್ನು ಅವರು ಭಾವಿ ನಾಯಕನಂತೆ ನೋಡುತ್ತಿದ್ದರು. ಈ ಶಿಕ್ಷಣ ಸಂಸ್ಥೆಗಳ ಮೂಲಕ ಅವರು ಕರ್ನಾಟಕದ ಯುವಜನತೆಗೆ ಜ್ಞಾನ ಮತ್ತು ಉತ್ತಮ ವೃತ್ತಿಜೀವನವನ್ನು ರೂಪಿಸಿಕೊಳ್ಳುವ ದೊಡ್ಡ ಉಡುಗೊರೆಯನ್ನು ನೀಡಿದರು.", "🎓"],
        ["As a freedom fighter, Shankaregowda participated in many protests to help India gain independence from British rule. He was a man of great courage who stood up for what was right, even when it was difficult. After independence, he served as a member of the Legislative Council and even became a Minister for Education. Despite holding such high positions, he never changed his simple ways. He was always seen in his iconic khadi clothes, symbols of self-reliance and national pride. He used his political power to bring more resources to rural areas, focusing on health, farming, and learning. He taught everyone that being a leader means being a servant of the people. His life was a living example of how politics could be used honestly to bring positive change and make a real difference in the world.", "ಸ್ವಾತಂತ್ರ್ಯ ಹೋರಾಟಗಾರರಾಗಿ, ಶಂಕರೇಗೌಡರು ಬ್ರಿಟಿಷರಿಂದ ಭಾರತವನ್ನು ಮುಕ್ತಗೊಳಿಸಲು ಅನೇಕ ಚಳವಳಿಗಳಲ್ಲಿ ಪಾಲ್ಗೊಂಡಿದ್ದರು. ಕಷ್ಟದ ಸಮಯದಲ್ಲಿಯೂ ಸರಿಯಾದದ್ದಕ್ಕಾಗಿ ಧ್ವನಿ ಎತ್ತುವ ಧೈರ್ಯಶಾಲಿ ಇವರಾಗಿದ್ದರು. ಸ್ವಾತಂತ್ರ್ಯದ ನಂತರ, ಅವರು ವಿಧಾನ ಪರಿಷತ್ತಿನ ಸದಸ್ಯರಾಗಿ ಮತ್ತು ಶಿಕ್ಷಣ ಸಚಿವರಾಗಿಯೂ ಸೇವೆ ಸಲ್ಲಿಸಿದರು. ಅಂತಹ ಉನ್ನತ ಹಂತ ತಲುಪಿದ್ದರೂ, ಅವರ ಸರಳತೆಯಲ್ಲಿ ಯಾವುದೇ ಬದಲಾವಣೆ ಇರಲಿಲ್ಲ. ಸ್ವಾವಲಂಬನೆ ಮತ್ತು ರಾಷ್ಟ್ರೀಯತೆಯ ಸಂಕೇತವಾದ ಖಾದಿ ಉಡುಪಿನಲ್ಲಿಯೇ ಅವರು ಸದಾ ಕಾಣಿಸಿಕೊಳ್ಳುತ್ತಿದ್ದರು. ತಮ್ಮ ರಾಜಕೀಯ ಅಧಿಕಾರವನ್ನು ಗ್ರಾಮೀಣ ಜನರ ಆರೋಗ್ಯ, ಕೃಷಿ ಮತ್ತು ಶಿಕ್ಷಣದ ಸುಧಾರಣೆಗಾಗಿ ಬಳಸಿದರು. ನಾಯಕನಾಗುವುದು ಎಂದರೆ ಜನರ ಸೇವಕನಾಗುವುದು ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು. ರಾಜಕೀಯವನ್ನು ಪ್ರಾಮಾಣಿಕವಾಗಿ ಬಳಸಿ ಸಮಾಜದಲ್ಲಿ ಹೇಗೆ ಬದಲಾವಣೆ ತರಬಹುದು ಎಂಬುದಕ್ಕೆ ಅವರ ಜೀವನವೇ ಒಂದು ದೊಡ್ಡ ಸಾಕ್ಷಿಯಾಗಿದೆ.", "🇮🇳"],
        ["K. V. Shankaregowda passed away in 1979, but his legacy lives on in every rustling sugarcane leaf and every classroom across Mandya. He is remembered as a hero who bridged the gap between tradition and progress. His life stories teach us that one person with a big heart and a clear vision can lift an entire community. Whether it was the sweetness of the sugar factories or the brightness of the universities, his contributions made life better for millions. Today, as students graduate and farmers harvest their crops, they still remember the 'Friend of the Farmers.' We can honor him by being simple, working hard for others, and always valuing education. He proved that true greatness is found in service and that a life lived for others is the sweetest and most meaningful life of all.", "ಕೆ. ವಿ. ಶಂಕರೇಗೌಡರು ೧೯೭೯ ರಲ್ಲಿ ಕಾಲವಾದರು, ಆದರೆ ಅವರ ಸಾಧನೆಗಳು ಮಂಡ್ಯದ ಕಬ್ಬಿನ ಗದ್ದೆಗಳಲ್ಲಿ ಮತ್ತು ಶಾಲೆಗಳಲ್ಲಿ ಇಂದಿಗೂ ಅಮರವಾಗಿವೆ. ಸಂಪ್ರದಾಯ ಮತ್ತು ಪ್ರಗತಿಯನ್ನು ಜೋಡಿಸಿದ ವೀರನಾಗಿ ಅವರನ್ನು ಸ್ಮರಿಸಲಾಗುತ್ತದೆ. ದೊಡ್ಡ ಮನಸ್ಸು ಮತ್ತು ಸ್ಪಷ್ಟ ದೂರದೃಷ್ಟಿ ಉಳ್ಳ ಒಬ್ಬ ವ್ಯಕ್ತಿಯು ಇಡೀ ಸಮುದಾಯವನ್ನೇ ಹೇಗೆ ಬೆಳೆಸಬಹುದು ಎಂಬುದಕ್ಕೆ ಇವರ ಜೀವನವೇ ನಮಗೆ ಪಾಠ. ಸಕ್ಕರೆ ಕಾರ್ಖಾನೆ ಇರಲಿ ಅಥವಾ ವಿಶ್ವವಿದ್ಯಾಲಯಗಳಿರಲಿ, ಇವರ ಕೊಡುಗೆಗಳು ಲಕ್ಷಾಂತರ ಜನರ ಜೀವನವನ್ನು ಹಸನುಗೊಳಿಸಿವೆ. ಇಂದು ವಿದ್ಯಾರ್ಥಿಗಳು ಪದವಿ ಪಡೆಯುವಾಗ ಮತ್ತು ರೈತರು ಬೆಳೆ ಕಟಾವು ಮಾಡುವಾಗ ಈ 'ರೈತ ಮಿತ್ರ'ನನ್ನು ನೆನೆಯುತ್ತಾರೆ. ಸರಳವಾಗಿ ಬದುಕುವ ಮೂಲಕ ಮತ್ತು ಇತರರಿಗಾಗಿ ಶ್ರಮಿಸುವ ಮೂಲಕ ನಾವು ಅವರಿಗೆ ಗೌರವ ಸಲ್ಲಿಸಬಹುದು. ಸೇವೆ ಮತ್ತು ಸಮಾಜಕ್ಕಾಗಿ ಬದುಕುವ ಜೀವನವೇ ಅತ್ಯಂತ ಸಿಹಿಯಾದ ಮತ್ತು ಅರ್ಥಪೂರ್ಣವಾದ ಜೀವನ ಎಂದು ಅವರು ಸಾಬೀತುಪಡಿಸಿದರು.", "🏛️"]
      ],
      quiz: [
        ["Nicknamed…", "ಅಡ್ಡಹೆಸರು?", ["Mandya Gandhi", "Mandya Tiger", "Mandya King"], ["ಮಂಡ್ಯ ಗಾಂಧಿ", "ಹುಲಿ", "ರಾಜ"], 0],
        ["Helped which crop?", "ಬೆಳೆ?", ["Sugarcane", "Tea", "Cotton"], ["ಕಬ್ಬು", "ಚಹಾ", "ಹತ್ತಿ"], 0],
      
        ['Nickname?', 'ಅಡ್ಡಹೆಸರು?', ['Mandya Gandhi', 'Mandya Tiger', 'Mandya King'], ['ಮಂಡ್ಯ ಗಾಂಧಿ', 'ಹುಲಿ', 'ರಾಜ'], 0],
        ['Crop he supported?', 'ಬೆಳೆ?', ['Sugarcane', 'Tea', 'Cotton'], ['ಕಬ್ಬು', 'ಚಹಾ', 'ಹತ್ತಿ'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Mandya', 'Mysuru', 'Bidar'], ['ಮಂಡ್ಯ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['He was a follower of…', 'ಅನುಯಾಯಿ?', ['Gandhi', 'Subhash', 'Nehru'], ['ಗಾಂಧಿ', 'ಸುಭಾಷ್', 'ನೆಹರೂ'], 0],
        ['Helped which class?', 'ಯಾವ ವರ್ಗ?', ['Farmers', 'Soldiers', 'Traders'], ['ರೈತರು', 'ಸೈನಿಕ', 'ವ್ಯಾಪಾರಿ'], 0],
        ['Worked for sugar…', 'ಕಾರ್ಖಾನೆ?', ['Factory cooperative', 'Hospital', 'School'], ['ಸಹಕಾರಿ ಸಕ್ಕರೆ ಕಾರ್ಖಾನೆ', 'ಆಸ್ಪತ್ರೆ', 'ಶಾಲೆ'], 0],
        ['Region around river?', 'ನದಿ?', ['Kaveri', 'Krishna', 'Tunga'], ['ಕಾವೇರಿ', 'ಕೃಷ್ಣಾ', 'ತುಂಗಾ'], 0],
        ['He is remembered as friend of…', 'ಸ್ನೇಹಿತ?', ['Farmers', 'Kings', 'Poets'], ['ರೈತರು', 'ರಾಜ', 'ಕವಿ'], 0],
      ],
      memorial: ["Shankaregowda Memorial", "ಶಂಕರೇಗೌಡ ಸ್ಮಾರಕ", "Mandya town", "ಮಂಡ್ಯ", "Statue and hall in central Mandya.", "ಮಂಡ್ಯದ ಪ್ರತಿಮೆ.", "KV Shankaregowda Mandya"],
    })],
  },
  {
    id: "raichur", name: { en: "Raichur", kn: "ರಾಯಚೂರು" }, emoji: "🏜️",
    heroes: [mkHero({
      id: "raichur-fort-builders", emoji: "🏰",
      name: ["The Builders of Raichur Fort", "ರಾಯಚೂರು ಕೋಟೆಯ ನಿರ್ಮಾತೃಗಳು"],
      title: ["Heroes of Stone & Strength", "ಕಲ್ಲು-ಶಕ್ತಿಯ ವೀರರು"],
      era: "12th – 14th Century",
      pages: [
        ["Long ago, in the late 13th century, a great vision took shape on a massive granite hill in Raichur. Between the mighty Krishna and Tungabhadra rivers, King Rudra of the Kakatiya dynasty decided to build a mountain of strength. In the year 1294, the first stones were laid, marking the birth of the Raichur Fort. The builders were not just laborers; they were artists of stone who understood the wind, the earth, and the hard granite. They dreamt of a structure that would stand for centuries, protecting the people from all directions. This was the beginning of a legendary landmark that would see many empires rise and fall, starting with the careful hands of those original visionary architects who saw a fortress hidden within the rough rocks.", "ಬಹಳ ಕಾಲದ ಹಿಂದೆ, 13ನೇ ಶತಮಾನದ ಕೊನೆಯಲ್ಲಿ, ರಾಯಚೂರಿನ ಬೃಹತ್ ಗ್ರಾನೈಟ್ ಬೆಟ್ಟದ ಮೇಲೆ ಒಂದು ಅದ್ಭುತ ದರ್ಶನವು ರೂಪುಗೊಂಡಿತು. ಪ್ರಬಲವಾದ ಕೃಷ್ಣಾ ಮತ್ತು ತುಂಗಭದ್ರಾ ನದಿಗಳ ನಡುವೆ, ಕಾಕತೀಯ ರಾಜವಂಶದ ರಾಜ ರುದ್ರನು ಶಕ್ತಿಯ ಶಿಖರವೊಂದನ್ನು ನಿರ್ಮಿಸಲು ನಿರ್ಧರಿಸಿದನು. ಕ್ರಿ.ಶ. 1294 ರಲ್ಲಿ, ರಾಯಚೂರು ಕೋಟೆಯ ಜನನವನ್ನು ಗುರುತಿಸುವ ಮೊದಲ ಕಲ್ಲುಗಳನ್ನು ಹಾಕಲಾಯಿತು. ಈ ನಿರ್ಮಾಣಕಾರರು ಕೇವಲ ಕಾರ್ಮಿಕರಲ್ಲ; ಅವರು ಗಾಳಿ, ಭೂಮಿ ಮತ್ತು ಗಟ್ಟಿಯಾದ ಗ್ರಾನೈಟ್ ಅನ್ನು ಅರ್ಥಮಾಡಿಕೊಂಡ ಕಲ್ಲಿನ ಕಲಾವಿದರಾಗಿದ್ದರು. ಅವರು ಶತಮಾನಗಳ ಕಾಲ ನಿಂತು, ಎಲ್ಲಾ ದಿಕ್ಕುಗಳಿಂದ ಜನರನ್ನು ರಕ್ಷಿಸುವ ಒಂದು ಭವ್ಯ ಕಟ್ಟಡದ ಕನಸು ಕಂಡಿದ್ದರು. ಒರಟು ಬಂಡೆಗಳೊಳಗೆ ಅಡಗಿರುವ ಕೋಟೆಯನ್ನು ಕಂಡ ಮೂಲ ದೂರದೃಷ್ಟಿಯ ವಾಸ್ತುಶಿಲ್ಪಿಗಳ ಕೈಗಳಿಂದ ಈ ಪೌರಾಣಿಕ ಐತಿಹಾಸಿಕ ತಾಣದ ಆರಂಭವಾಯಿತು.", "🏰"],
        ["As time passed, the fort grew stronger under the hands of talented builders from different kingdoms. The builders learned to carve massive blocks of stone so perfectly that they fit together without any mortar. These cyclopean walls were a marvel of engineering, showing the incredible muscle and mind of the people of Karnataka. Each stone was dressed and polished, layered one upon another to create a shield that no enemy could easily break. The builders spent years mastering the craft of moving these heavy rocks up the steep hill. They studied the landscape and used the natural granite hillock as a foundation, making the fort an inseparable part of the earth itself, symbolizing the eternal strength of the region and its hardworking people.", "ಕಾಲ ಉರುಳಿದಂತೆ, ವಿವಿಧ ಸಾಮ್ರಾಜ್ಯಗಳ ಪ್ರತಿಭಾವಂತ ನಿರ್ಮಾಣಕಾರರ ಕೈಯಲ್ಲಿ ಕೋಟೆಯು ಹೆಚ್ಚು ಬಲಗೊಂಡಿತು. ಈ ಬಿಲ್ಡರ್‌ಗಳು ಬೃಹತ್ ಕಲ್ಲಿನ ಬ್ಲಾಕ್‌ಗಳನ್ನು ಎಷ್ಟು ಪರಿಪೂರ್ಣವಾಗಿ ಕೆತ್ತಲು ಕಲಿತರೆಂದರೆ, ಅವು ಯಾವುದೇ ಗಾರೆ ಇಲ್ಲದೆ ಒಂದಕ್ಕೊಂದು ಸೇರಿಕೊಳ್ಳುತ್ತಿದ್ದವು. ಈ ಸೈಕ್ಲೋಪಿಯನ್ ಗೋಡೆಗಳು ಎಂಜಿನಿಯರಿಂಗ್‌ನ ಅದ್ಭುತವಾಗಿದ್ದವು, ಇದು ಕರ್ನಾಟಕದ ಜನರ ಅದ್ಭುತ ಸ್ನಾಯುಶಕ್ತಿ ಮತ್ತು ಬುದ್ಧಿವಂತಿಕೆಯನ್ನು ತೋರಿಸುತ್ತದೆ. ಪ್ರತಿಯೊಂದು ಕಲ್ಲನ್ನು ಕೆತ್ತಿ ಹೊಳಪುಗೊಳಿಸಲಾಯಿತು, ಯಾವುದೇ ವೈರಿ ಸುಲಭವಾಗಿ ಭೇದಿಸಲಾಗದ ಗುರಾಣಿಯನ್ನು ರಚಿಸಲು ಒಂದರ ಮೇಲೊಂದು ಪದರಗಳನ್ನು ಜೋಡಿಸಲಾಯಿತು. ಬಿಲ್ಡರ್‌ಗಳು ಈ ಭಾರೀ ಬಂಡೆಗಳನ್ನು ಕಡಿದಾದ ಬೆಟ್ಟದ ಮೇಲೆ ಸಾಗಿಸುವ ಕಲೆಯನ್ನು ಕರಗತ ಮಾಡಿಕೊಳ್ಳಲು ವರ್ಷಗಳ ಕಾಲ ಕಳೆದರು. ಅವರು ಭೂದೃಶ್ಯವನ್ನು ಅಭ್ಯಸಿಸಿದರು ಮತ್ತು ನೈಸರ್ಗಿಕ ಗ್ರಾನೈಟ್ ಬೆಟ್ಟವನ್ನೇ ಅಡಿಪಾಯವಾಗಿ ಬಳಸಿದರು.", "🏗️"],
        ["The fort became a canvas for history, where different cultures left their unique marks. After the Kakatiyas, the builders of the Vijayanagara, Bahmani, and Adil Shahi empires added their own layers of beauty and protection. They built magnificent gates that welcomed travelers and stood tall against invaders. On these walls, they carved inscriptions in Persian and Kannada, telling stories of bravery, taxes, and daily life. The builders ensured that the fort was not just a military post but a center of communication and art. Every archway and inscription added a new chapter to the story of Raichur. These craftsmen were the bridge between different eras, blending diverse styles into a single, cohesive masterpiece of stone that represented the melting pot of cultures in the heart of the Deccan.", "ಕೋಟೆಯು ಇತಿಹಾಸದ ಕ್ಯಾನ್ವಾಸ್ ಆಗಿ ಮಾರ್ಪಟ್ಟಿತು, ಅಲ್ಲಿ ವಿವಿಧ ಸಂಸ್ಕೃತಿಗಳು ತಮ್ಮ ವಿಶಿಷ್ಟ ಗುರುತುಗಳನ್ನು ಬಿಟ್ಟಿವೆ. ಕಾಕತೀಯರ ನಂತರ, ವಿಜಯನಗರ, ಬಹಮನಿ ಮತ್ತು ಆದಿಲ್ ಶಾಹಿ ಸಾಮ್ರಾಜ್ಯಗಳ ನಿರ್ಮಾಣಕಾರರು ಸೌಂದರ್ಯ ಮತ್ತು ರಕ್ಷಣೆಯ ತಮ್ಮದೇ ಆದ ಪದರಗಳನ್ನು ಸೇರಿಸಿದರು. ಅವರು ಪ್ರಯಾಣಿಕರನ್ನು ಸ್ವಾಗತಿಸುವ ಮತ್ತು ಆಕ್ರಮಣಕಾರರ ವಿರುದ್ಧ ಎತ್ತರವಾಗಿ ನಿಲ್ಲುವ ಭವ್ಯವಾದ ದ್ವಾರಗಳನ್ನು ನಿರ್ಮಿಸಿದರು. ಈ ಗೋಡೆಗಳ ಮೇಲೆ, ಅವರು ಪರ್ಷಿಯನ್ ಮತ್ತು ಕನ್ನಡ ಭಾಷೆಗಳಲ್ಲಿ ಶಾಸನಗಳನ್ನು ಕೆತ್ತಿದರು, ಶೌರ್ಯ, ತೆರಿಗೆಗಳು ಮತ್ತು ದೈನಂದಿನ ಜೀವನದ ಕಥೆಗಳನ್ನು ವಿವರಿಸಿದರು. ಕೋಟೆಯು ಕೇವಲ ಮಿಲಿಟರಿ ನೆಲೆಯಾಗಿರದೆ ಸಂವಹನ ಮತ್ತು ಕಲೆಯ ಕೇಂದ್ರವಾಗಿದೆ ಎಂದು ಬಿಲ್ಡರ್‌ಗಳು ಖಚಿತಪಡಿಸಿದರು. ಪ್ರತಿಯೊಂದು ಕಮಾನು ಮತ್ತು ಶಾಸನವು ರಾಯಚೂರಿನ ಕಥೆಗೆ ಹೊಸ ಅಧ್ಯಾಯವನ್ನು ಸೇರಿಸಿತು. ಈ ಕುಶಲಕರ್ಮಿಗಳು ವಿವಿಧ ಕಾಲಘಟ್ಟಗಳ ನಡುವಿನ ಸೇತುವೆಯಾಗಿದ್ದರು.", "📜"],
        ["The greatest test for the builders' work came in the year 1520 during the famous Battle of Raichur. The mighty King Krishnadevaraya of Vijayanagara led a massive army to reclaim this strategic fort from the Bijapur Sultanate. The air was filled with the sound of cannons and the dust of thousands of soldiers. Because the builders had made the walls so thick and the gates so strong, the battle became a legendary struggle of endurance and strategy. The fortress stood firm against heavy bombardment, proving that the skill of the stone-masons was as important as the bravery of the soldiers. Eventually, Krishnadevaraya’s forces triumphed, and the fort became a symbol of his greatest victory, showcasing the peak achievement of medieval Indian military architecture and the indomitable spirit of those who built it.", "ನಿರ್ಮಾಣಕಾರರ ಕೆಲಸಕ್ಕೆ ದೊಡ್ಡ ಪರೀಕ್ಷೆ ಬಂದಿದ್ದು 1520 ರ ಪ್ರಸಿದ್ಧ ರಾಯಚೂರು ಯುದ್ಧದ ಸಮಯದಲ್ಲಿ. ವಿಜಯನಗರದ ಪ್ರಬಲ ರಾಜ ಕೃಷ್ಣದೇವರಾಯನು ಬಿಜಾಪುರ ಸುಲ್ತಾನರಿಂದ ಈ ಆಯಕಟ್ಟಿನ ಕೋಟೆಯನ್ನು ಮರಳಿ ಪಡೆಯಲು ಬೃಹತ್ ಸೈನ್ಯವನ್ನು ಮುನ್ನಡೆಸಿದನು. ಗಾಳಿಯು ಫಿರಂಗಿಗಳ ಸದ್ದು ಮತ್ತು ಸಾವಿರಾರು ಸೈನಿಕರ ಧೂಳಿನಿಂದ ತುಂಬಿತ್ತು. ಬಿಲ್ಡರ್‌ಗಳು ಗೋಡೆಗಳನ್ನು ತುಂಬಾ ದಪ್ಪವಾಗಿ ಮತ್ತು ದ್ವಾರಗಳನ್ನು ಬಲವಾಗಿ ಮಾಡಿದ್ದರಿಂದ, ಯುದ್ಧವು ಸಹಿಷ್ಣುತೆ ಮತ್ತು ತಂತ್ರದ ಪೌರಾಣಿಕ ಹೋರಾಟವಾಯಿತು. ಕೋಟೆಯು ಭಾರಿ ಬಾಂಬ್ ದಾಳಿಯ ವಿರುದ್ಧ ದೃಢವಾಗಿ ನಿಂತಿತು, ಕಲ್ಲು ಕೆಲಸಗಾರರ ಕೌಶಲ್ಯವು ಸೈನಿಕರ ಶೌರ್ಯದಷ್ಟೇ ಮುಖ್ಯ ಎಂದು ಸಾಬೀತುಪಡಿಸಿತು. ಅಂತಿಮವಾಗಿ, ಕೃಷ್ಣದೇವರಾಯನ ಸೈನ್ಯವು ಜಯಗಳಿಸಿತು ಮತ್ತು ಕೋಟೆಯು ಅವನ ಅತ್ಯಂತ ದೊಡ್ಡ ವಿಜಯದ ಸಂಕೇತವಾಯಿತು.", "⚔️"],
        ["Today, the Raichur Fort stands as a silent sentinel of Karnataka's glorious past, inviting children and visitors to walk through its ancient gates. Although some parts are now ruins, the massive dressed stones still tell the tale of the heroes of stone and strength. It reminds us of a time when architects and laborers worked together to create something larger than themselves. When you visit Raichur, you can touch the same granite blocks laid by King Rudra's men hundreds of years ago. The inscriptions still speak in Kannada and Persian, preserving the bilingual heritage of the region. The legacy of the builders lives on in every stone, teaching us that true strength comes from careful craftsmanship, unity across different cultures, and the determination to build things that last for all eternity.", "ಇಂದು, ರಾಯಚೂರು ಕೋಟೆಯು ಕರ್ನಾಟಕದ ವೈಭವದ ಗತಕಾಲದ ಮೂಕ ಸಾಕ್ಷಿಯಾಗಿ ನಿಂತಿದ್ದು, ಮಕ್ಕಳು ಮತ್ತು ಸಂದರ್ಶಕರನ್ನು ತನ್ನ ಪ್ರಾಚೀನ ದ್ವಾರಗಳ ಮೂಲಕ ನಡೆಯಲು ಆಹ್ವಾನಿಸುತ್ತದೆ. ಕೆಲವು ಭಾಗಗಳು ಈಗ ಅವಶೇಷಗಳಾಗಿದ್ದರೂ, ಬೃಹತ್ ಕೆತ್ತಿದ ಕಲ್ಲುಗಳು ಇಂದಿಗೂ ಕಲ್ಲು ಮತ್ತು ಶಕ್ತಿಯ ವೀರರ ಕಥೆಯನ್ನು ಹೇಳುತ್ತವೆ. ವಾಸ್ತುಶಿಲ್ಪಿಗಳು ಮತ್ತು ಕಾರ್ಮಿಕರು ತಮಗಿಂತ ದೊಡ್ಡದಾದ ಯಾವುದನ್ನಾದರೂ ಸೃಷ್ಟಿಸಲು ಒಟ್ಟಾಗಿ ಕೆಲಸ ಮಾಡಿದ ಸಮಯವನ್ನು ಇದು ನಮಗೆ ನೆನಪಿಸುತ್ತದೆ. ನೀವು ರಾಯಚೂರಿಗೆ ಭೇಟಿ ನೀಡಿದಾಗ, ನೂರಾರು ವರ್ಷಗಳ ಹಿಂದೆ ರಾಜ ರುದ್ರನ ಸೈನಿಕರು ಹಾಕಿದ ಅದೇ ಗ್ರಾನೈಟ್ ಬ್ಲಾಕ್‌ಗಳನ್ನು ನೀವು ಸ್ಪರ್ಶಿಸಬಹುದು. ಶಾಸನಗಳು ಇಂದಿಗೂ ಕನ್ನಡ ಮತ್ತು ಪರ್ಷಿಯನ್ ಭಾಷೆಯಲ್ಲಿ ಮಾತನಾಡುತ್ತವೆ. ನಿರ್ಮಾಣಕಾರರ ಪರಂಪರೆಯು ಪ್ರತಿ ಕಲ್ಲಿನಲ್ಲೂ ಜೀವಂತವಾಗಿದೆ, ನಿಜವಾದ ಶಕ್ತಿಯು ಎಚ್ಚರಿಕೆಯ ಕುಶಲಕರ್ಮ ಮತ್ತು ವಿವಿಧ ಸಂಸ್ಕೃತಿಗಳ ಏಕತೆಯಿಂದ ಬರುತ್ತದೆ ಎಂದು ನಮಗೆ ಕಲಿಸುತ್ತದೆ.", "🇮🇳"]
      ],
      quiz: [
        ["The fort is in…", "ಎಲ್ಲಿ?", ["Raichur", "Bidar", "Hampi"], ["ರಾಯಚೂರು", "ಬೀದರ್", "ಹಂಪಿ"], 0],
        ["Built on a…", "ಎಲ್ಲಿ?", ["Rocky hill", "Beach", "Forest"], ["ಬಂಡೆಗುಡ್ಡ", "ಕಡಲತೀರ", "ಕಾಡು"], 0],
      
        ['Fort located in?', 'ಎಲ್ಲಿ?', ['Raichur', 'Bidar', 'Hampi'], ['ರಾಯಚೂರು', 'ಬೀದರ್', 'ಹಂಪಿ'], 0],
        ['Built on what land?', 'ಸ್ಥಳ?', ['Rocky hill', 'Beach', 'Forest'], ['ಬಂಡೆಗುಡ್ಡ', 'ಕಡಲತೀರ', 'ಕಾಡು'], 0],
        ['Region?', 'ಪ್ರದೇಶ?', ['Kalyana Karnataka', 'Coast', 'Malnad'], ['ಕಲ್ಯಾಣ ಕರ್ನಾಟಕ', 'ಕರಾವಳಿ', 'ಮಲೆನಾಡು'], 0],
        ['Fort lies between two rivers…', 'ಎರಡು ನದಿ?', ['Krishna & Tungabhadra', 'Kaveri & Tunga', 'Sharavati & Kali'], ['ಕೃಷ್ಣ-ತುಂಗಭದ್ರ', 'ಕಾವೇರಿ-ತುಂಗ', 'ಶರಾವತಿ-ಕಾಳಿ'], 0],
        ['Built mainly with…', 'ಯಾವುದರಿಂದ?', ['Stone', 'Mud', 'Wood'], ['ಕಲ್ಲು', 'ಮಣ್ಣು', 'ಮರ'], 0],
        ['Was a centre of?', 'ಕೇಂದ್ರ?', ['Power & trade', 'Farming only', 'Schools'], ['ಶಕ್ತಿ-ವ್ಯಾಪಾರ', 'ಕೇವಲ ಕೃಷಿ', 'ಶಾಲೆ'], 0],
        ['Many dynasties controlled it including…', 'ಯಾರ ನಿಯಂತ್ರಣ?', ['Vijayanagara', 'British', 'Mughals only'], ['ವಿಜಯನಗರ', 'ಬ್ರಿಟಿಷ್', 'ಕೇವಲ ಮೊಘಲ್'], 0],
        ['Builders are called?', 'ನಿರ್ಮಾಪಕರು?', ['Heroes', 'Sailors', 'Pilots'], ['ವೀರರು', 'ನಾವಿಕ', 'ಪೈಲಟ್'], 0],
      ],
      memorial: ["Raichur Fort", "ರಾಯಚೂರು ಕೋಟೆ", "Raichur city", "ರಾಯಚೂರು", "A massive medieval fort.", "ಮಧ್ಯಯುಗದ ಕೋಟೆ.", "Raichur Fort Karnataka"],
    })],
  },
  {
    id: "ramanagara", name: { en: "Ramanagara", kn: "ರಾಮನಗರ" }, emoji: "🪨",
    heroes: [mkHero({
      id: "magadi-kempegowda-ii", emoji: "🏯",
      name: ["Magadi Kempegowda II", "ಮಾಗಡಿ ಕೆಂಪೇಗೌಡ II"],
      title: ["Builder of Magadi", "ಮಾಗಡಿಯ ನಿರ್ಮಾತೃ"],
      era: "16th – 17th Century",
      pages: [
        ["In the vibrant heart of the 16th century, a young prince named Magadi Kempegowda II was born into the prestigious lineage of the Yelahanka Nada Prabhu family. As the grandson of the legendary Kempegowda I, the founder of Bengaluru, he grew up surrounded by stories of bravery and great city-building. From an early age, he was taught that a true leader is not defined by their sword alone, but by the prosperity they bring to their people. He watched his elders plan grand temples and wide roads, learning the intricate art of governance and architecture. He inherited a magnificent vision for the land, carrying the dreams of his grandfather forward with a heart full of courage and a mind ready for the challenges of leadership.", "16ನೇ ಶತಮಾನದ ರೋಮಾಂಚಕ ಕಾಲದಲ್ಲಿ, ಮಾಗಡಿ ಕೆಂಪೇಗೌಡ II ಎಂಬ ಯುವ ರಾಜನು ಯಲಹಂಕ ನಾಡಪ್ರಭುಗಳ ಪ್ರತಿಷ್ಠಿತ ಕುಟುಂಬದಲ್ಲಿ ಜನಿಸಿದನು. ಬೆಂಗಳೂರಿನ ಸಂಸ್ಥಾಪಕ ಕೆಂಪೇಗೌಡರ ಮೊಮ್ಮಗನಾದ ಇವನು, ಶೌರ್ಯ ಮತ್ತು ನಗರ ನಿರ್ಮಾಣದ ಕಥೆಗಳ ನಡುವೆಯೇ ಬೆಳೆದನು. ಒಬ್ಬ ನಿಜವಾದ ನಾಯಕ ಕೇವಲ ಕತ್ತಿಯಿಂದ ಗುರುತಿಸಲ್ಪಡುವುದಿಲ್ಲ, ಬದಲಾಗಿ ಅವನು ತನ್ನ ಜನರಿಗೆ ತರುವ ಸಮೃದ್ಧಿಯಿಂದ ಗುರುತಿಸಲ್ಪಡುತ್ತಾನೆ ಎಂದು ಅವನು ಚಿಕ್ಕಂದಿನಿಂದಲೇ ಕಲಿತಿದ್ದನು. ತನ್ನ ಹಿರಿಯರು ಭವ್ಯವಾದ ದೇವಾಲಯಗಳನ್ನು ಮತ್ತು ವಿಶಾಲವಾದ ರಸ್ತೆಗಳನ್ನು ಯೋಜಿಸುವುದನ್ನು ನೋಡುತ್ತಾ, ಆಡಳಿತ ಮತ್ತು ವಾಸ್ತುಶಿಲ್ಪದ ಸಂಕೀರ್ಣ ಕಲೆಯನ್ನು ಅವನು ಕಲಿತನು. ಅವನು ತನ್ನ ಅಜ್ಜನ ಕನಸುಗಳನ್ನು ಮುಂದುವರಿಸುವ ದೊಡ್ಡ ದೃಷ್ಟಿಕೋನವನ್ನು ಮತ್ತು ಸವಾಲುಗಳನ್ನು ಎದುರಿಸುವ ಧೈರ್ಯವನ್ನು ಹೊಂದಿದ್ದನು.", "🏰"],
        ["When it was time for Kempegowda II to lead, the kingdom faced difficult times due to external threats. To protect his people and ensure their safety from the attacking forces of Bijapur, he made a strategic and wise decision to shift the capital. Moving from the open plains to the rugged, protective terrain of Magadi, he began a new chapter in his reign. He was not just a warrior but a visionary who understood that survival required adaptation. In the lush greenery of the Ramanagara region, he began laying the foundations for a secure future, ensuring that the legacy of his family would remain unbroken despite the shadows of war that loomed over the Deccan plateau.", "ಕೆಂಪೇಗೌಡ II ಆಡಳಿತಕ್ಕೆ ಬಂದಾಗ, ಹೊರಗಿನ ದಾಳಿಗಳಿಂದಾಗಿ ರಾಜ್ಯವು ಕಷ್ಟದ ಸಮಯವನ್ನು ಎದುರಿಸುತ್ತಿತ್ತು. ಬಿಜಾಪುರ ಸೈನ್ಯದ ದಾಳಿಯಿಂದ ತನ್ನ ಜನರನ್ನು ರಕ್ಷಿಸಲು, ಅವನು ರಾಜಧಾನಿಯನ್ನು ಸ್ಥಳಾಂತರಿಸುವ ಬುದ್ಧಿವಂತ ನಿರ್ಧಾರವನ್ನು ಮಾಡಿದನು. ಬಯಲು ಸೀಮೆಯಿಂದ ಮಾಗಡಿಯ ಗುಡ್ಡಗಾಡು ಪ್ರದೇಶಕ್ಕೆ ಸ್ಥಳಾಂತರಗೊಳ್ಳುವ ಮೂಲಕ ಅವನು ತನ್ನ ಆಳ್ವಿಕೆಯ ಹೊಸ ಅಧ್ಯಾಯವನ್ನು ಪ್ರಾರಂಭಿಸಿದನು. ಅವನು ಕೇವಲ ಒಬ್ಬ ಯೋಧನಾಗಿರದೆ, ಬದುಕುಳಿಯಲು ಬದಲಾವಣೆ ಅಗತ್ಯ ಎಂದು ಅರ್ಥಮಾಡಿಕೊಂಡ ದಾರ್ಶನಿಕನಾಗಿದ್ದನು. ರಾಮನಗರ ಜಿಲ್ಲೆಯ ಹಸಿರು ಪರಿಸರದಲ್ಲಿ, ಅವನು ಸುರಕ್ಷಿತ ಭವಿಷ್ಯಕ್ಕಾಗಿ ಅಡಿಪಾಯ ಹಾಕಲು ಪ್ರಾರಂಭಿಸಿದನು, ಇದರಿಂದಾಗಿ ಯುದ್ಧದ ನೆರಳಿನಲ್ಲೂ ತನ್ನ ವಂಶದ ಪರಂಪರೆ ಮುಂದುವರಿಯುವಂತೆ ಮಾಡಿದನು.", "🛡️"],
        ["As the 'Builder of Magadi', Kempegowda II focused his energy on creating impregnable defenses and beautiful monuments. He strengthened the fortifications at the massive stone hill of Savandurga, making it one of the most formidable fortresses in the region. Within the town of Magadi, he commissioned the construction of the elegant Someshwara temple, which stands today as a testament to his devotion and artistic taste. He believed that a city should be a place of both safety and spirit. While his soldiers patrolled the tall stone walls he erected, the local people found peace within the temple courtyards, celebrating the rich culture and traditions that their ruler worked so tirelessly to preserve for future generations.", "'ಮಾಗಡಿಯ ನಿರ್ಮಾತೃ' ಎಂದು ಹೆಸರಾದ ಕೆಂಪೇಗೌಡ II, ಅಭೇದ್ಯವಾದ ರಕ್ಷಣೆ ಮತ್ತು ಸುಂದರ ಸ್ಮಾರಕಗಳನ್ನು ನಿರ್ಮಿಸಲು ಶ್ರಮಿಸಿದನು. ಅವನು ಸಾವನದುರ್ಗದ ಬೃಹತ್ ಬೆಟ್ಟದ ಮೇಲೆ ಕೋಟೆಗಳನ್ನು ಬಲಪಡಿಸಿದನು, ಇದು ಆ ಪ್ರದೇಶದ ಅತ್ಯಂತ ಪ್ರಬಲ ಕೋಟೆಗಳಲ್ಲಿ ಒಂದಾಯಿತು. ಮಾಗಡಿ ಪಟ್ಟಣದಲ್ಲಿ, ಅವನು ಸುಂದರವಾದ ಸೋಮೇಶ್ವರ ದೇವಾಲಯವನ್ನು ನಿರ್ಮಿಸಿದನು, ಇದು ಇಂದು ಅವನ ಭಕ್ತಿ ಮತ್ತು ಕಲಾತ್ಮಕ ಅಭಿವ್ಯಕ್ತಿಗೆ ಸಾಕ್ಷಿಯಾಗಿದೆ. ಒಂದು ನಗರವು ಸುರಕ್ಷಿತ ಹಾಗೂ ಧಾರ್ಮಿಕವಾಗಿರಬೇಕು ಎಂದು ಅವನು ನಂಬಿದ್ದನು. ಸೈನಿಕರು ಅವನು ನಿರ್ಮಿಸಿದ ಎತ್ತರದ ಕಲ್ಲಿನ ಗೋಡೆಗಳನ್ನು ಕಾಯುತ್ತಿದ್ದರೆ, ಸ್ಥಳೀಯ ಜನರು ದೇವಾಲಯದ ಆವರಣದಲ್ಲಿ ಶಾಂತಿಯನ್ನು ಕಂಡುಕೊಂಡರು.", "🧱"],
        ["Perhaps his most famous achievement was fulfilling his grandfather’s grand plan for the future growth of Bengaluru. Kempegowda II erected four iconic watch towers in different directions to mark the intended boundaries of the city. These majestic towers, built with precision and grace, were signals of a growing metropolis. Furthermore, he continued the vital tradition of building tanks and lakes to provide water for farmers and citizens. He understood that water was life, and his engineering projects ensured that the land remained fertile even during the dry seasons. By balancing military strength with civil engineering, he earned the deep respect of his subjects and secured his place as one of the Karnataka region’s most capable and thoughtful administrators.", "ಬೆಂಗಳೂರಿನ ಭವಿಷ್ಯದ ಬೆಳವಣಿಗೆಗಾಗಿ ತನ್ನ ಅಜ್ಜ ಹಾಕಿದ್ದ ಯೋಜನೆಯನ್ನು ಪೂರ್ಣಗೊಳಿಸಿದ್ದು ಅವನ ಅತ್ಯಂತ ಪ್ರಸಿದ್ಧ ಸಾಧನೆಯಾಗಿದೆ. ಕೆಂಪೇಗೌಡ II ನಗರದ ಗಡಿಗಳನ್ನು ಗುರುತಿಸಲು ನಾಲ್ಕು ದಿಕ್ಕುಗಳಲ್ಲಿ ಐತಿಹಾಸಿಕ ಕಾವಲು ಗೋಪುರಗಳನ್ನು ನಿರ್ಮಿಸಿದನು. ಈ ಭವ್ಯ ಗೋಪುರಗಳು ಬೆಳೆಯುತ್ತಿರುವ ಮಹಾನಗರದ ಸಂಕೇತಗಳಾಗಿದ್ದವು. ಅಷ್ಟೇ ಅಲ್ಲದೆ, ರೈತರು ಮತ್ತು ನಾಗರಿಕರಿಗೆ ನೀರು ಒದಗಿಸಲು ಅವನು ಕೆರೆಗಳನ್ನು ನಿರ್ಮಿಸುವ ಸಂಪ್ರದಾಯವನ್ನು ಮುಂದುವರಿಸಿದನು. ನೀರೇ ಜೀವ ಎಂದು ಅರಿತಿದ್ದ ಅವನ ಇಂಜಿನಿಯರಿಂಗ್ ಕೆಲಸಗಳು, ಒಣ ಹವೆಯಲ್ಲೂ ಭೂಮಿ ಫಲವತ್ತಾಗಿರುವಂತೆ ನೋಡಿಕೊಂಡವು. ಮಿಲಿಟರಿ ಶಕ್ತಿ ಮತ್ತು ನಾಗರಿಕ ಸೌಕರ್ಯಗಳ ನಡುವೆ ಸಮತೋಲನ ಕಾಯ್ದುಕೊಳ್ಳುವ ಮೂಲಕ, ಅವನು ಒಬ್ಬ ಸಮರ್ಥ ಆಡಳಿತಗಾರನಾಗಿ ಜನರ ಗೌರವಕ್ಕೆ ಪಾತ್ರನಾದನು.", "🗼"],
        ["Today, the legacy of Magadi Kempegowda II lives on in the very landscape of Karnataka. Visitors to Bengaluru can still see the four stone towers, now standing amidst towering skyscrapers as reminders of a visionary past. The massive fort at Savandurga and the serene Someshwara temple in Magadi remain important historical sites that tell the story of his resilience. His dedication to water conservation through tank construction set a standard for local governance that lasted for centuries. Children in Ramanagara and beyond learn about his life as a reminder that true leadership means protecting one's heritage while building a gateway to the future. He remains an eternal hero of the soil, a builder whose works continue to shelter and inspire millions.", "ಇಂದು, ಮಾಗಡಿ ಕೆಂಪೇಗೌಡರ ಪರಂಪರೆಯು ಕರ್ನಾಟಕದ ಭೂಪಟದಲ್ಲಿ ಅಚ್ಚಳಿಯದೆ ಉಳಿದಿದೆ. ಬೆಂಗಳೂರಿಗೆ ಬರುವವರು ಇಂದಿಗೂ ಆ ನಾಲ್ಕು ಕಲ್ಲಿನ ಗೋಪುರಗಳನ್ನು ನೋಡಬಹುದು, ಅವು ಈಗ ಎತ್ತರದ ಕಟ್ಟಡಗಳ ನಡುವೆ ಗತಕಾಲದ ದಾರ್ಶನಿಕತೆಯ ನೆನಪಿನಂತೆ ನಿಂತಿವೆ. ಸಾವನದುರ್ಗದ ಬೃಹತ್ ಕೋಟೆ ಮತ್ತು ಮಾಗಡಿಯ ಸೋಮೇಶ್ವರ ದೇವಾಲಯವು ಅವನ ಧೈರ್ಯದ ಕಥೆಯನ್ನು ಹೇಳುವ ಪ್ರಮುಖ ಐತಿಹಾಸಿಕ ತಾಣಗಳಾಗಿವೆ. ಕೆರೆಗಳ ನಿರ್ಮಾಣದ ಮೂಲಕ ಅವರು ತೋರಿದ ಜಲ ಸಂರಕ್ಷಣೆಯ ಕಾಳಜಿಯು ಶತಮಾನಗಳವರೆಗೆ ಮಾದರಿಯಾಯಿತು. ರಾಮನಗರ ಮತ್ತು ಇತರ ಭಾಗಗಳ ಮಕ್ಕಳು ಅವನ ಜೀವನದ ಬಗ್ಗೆ ಕಲಿಯುತ್ತಾ, ಪರಂಪರೆಯನ್ನು ರಕ್ಷಿಸುತ್ತಲೇ ಭವಿಷ್ಯವನ್ನು ಕಟ್ಟುವುದೇ ನಿಜವಾದ ನಾಯಕತ್ವ ಎಂದು ಅರಿಯುತ್ತಾರೆ. ಅವರು ಈ ಮಣ್ಣಿನ ಶಾಶ್ವತ ವೀರರಾಗಿ ಇಂದಿಗೂ ಪ್ರೇರೇಪಿಸುತ್ತಿದ್ದಾರೆ.", "🌳"]
      ],
      quiz: [
        ["He ruled…", "ಆಳ್ವಿಕೆ?", ["Magadi", "Hampi", "Bidar"], ["ಮಾಗಡಿ", "ಹಂಪಿ", "ಬೀದರ್"], 0],
        ["Grandfather founded…", "ಅಜ್ಜ?", ["Bengaluru", "Mysuru", "Hubballi"], ["ಬೆಂಗಳೂರು", "ಮೈಸೂರು", "ಹುಬ್ಬಳ್ಳಿ"], 0],
      
        ['He ruled?', 'ಆಳ್ವಿಕೆ?', ['Magadi', 'Hampi', 'Bidar'], ['ಮಾಗಡಿ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['Grandfather founded…', 'ಅಜ್ಜ?', ['Bengaluru', 'Mysuru', 'Hubballi'], ['ಬೆಂಗಳೂರು', 'ಮೈಸೂರು', 'ಹುಬ್ಬಳ್ಳಿ'], 0],
        ['He built four famous…', 'ನಾಲ್ಕು?', ['Watch towers', 'Palaces', 'Bridges'], ['ಗೋಪುರಗಳು', 'ಅರಮನೆ', 'ಸೇತುವೆ'], 0],
        ['District today?', 'ಜಿಲ್ಲೆ?', ['Ramanagara', 'Mysuru', 'Bidar'], ['ರಾಮನಗರ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Empire he served?', 'ಸಾಮ್ರಾಜ್ಯ?', ['Vijayanagara', 'Mughal', 'British'], ['ವಿಜಯನಗರ', 'ಮೊಘಲ್', 'ಬ್ರಿಟಿಷ್'], 0],
        ['Towers helped to…', 'ಗೋಪುರ?', ['Mark city limits', 'Cook food', 'Store water'], ['ನಗರದ ಗಡಿ', 'ಅಡುಗೆ', 'ನೀರು ಸಂಗ್ರಹ'], 0],
        ['Magadi today is known for?', 'ಪ್ರಸಿದ್ಧಿ?', ['History & temples', 'Beaches', 'Snow'], ['ಇತಿಹಾಸ-ದೇವಾಲಯ', 'ಕಡಲತೀರ', 'ಹಿಮ'], 0],
        ['He continued legacy of?', 'ಪರಂಪರೆ?', ['Original Kempegowda', 'Tipu', 'Krishnadevaraya'], ['ಮೂಲ ಕೆಂಪೇಗೌಡ', 'ಟಿಪ್ಪು', 'ಕೃಷ್ಣದೇವರಾಯ'], 0],
      ],
      memorial: ["Savandurga Fort", "ಸಾವನದುರ್ಗ ಕೋಟೆ", "Magadi, Ramanagara", "ಮಾಗಡಿ", "Massive monolithic hill forts.", "ಬೆಟ್ಟದ ಕೋಟೆ.", "Savandurga Magadi Karnataka"],
    })],
  },
  {
    id: "tumakuru", name: { en: "Tumakuru", kn: "ತುಮಕೂರು" }, emoji: "🥥",
    heroes: [mkHero({
      id: "siddaganga-swamiji", emoji: "🪔",
      name: ["Sri Shivakumara Swamiji", "ಶ್ರೀ ಶಿವಕುಮಾರ ಸ್ವಾಮೀಜಿ"],
      title: ["The Walking God of Siddaganga", "ಸಿದ್ಧಗಂಗೆಯ ನಡೆದಾಡುವ ದೇವರು"],
      era: "1907 – 2019",
      pages: [
        ["In a peaceful village of Karnataka named Veerapura, a bright boy was born in 1907. Young Shivanna was very kind and loved to learn. He grew up seeing the beauty of the Tumakuru landscape and developed a heart full of compassion for everyone around him. Little did the villagers know that this curious child would one day become a great saint, changing the lives of thousands. His early days were filled with simple living and high thinking, setting the foundation for a life dedicated entirely to the service of humanity and the divine path of spirituality.", "ಕರ್ನಾಟಕದ ವೀರಪುರ ಎಂಬ ಶಾಂತಿಯುತ ಗ್ರಾಮದಲ್ಲಿ 1907ರಲ್ಲಿ ಒಬ್ಬ ಪ್ರಕಾಶಮಾನವಾದ ಬಾಲಕ ಜನಿಸಿದನು. ಯುವ ಶಿವಣ್ಣ ತುಂಬಾ ದಯಾಳು ಮತ್ತು ಕಲಿಯಲು ಬಹಳ ಆಸಕ್ತಿ ಹೊಂದಿದ್ದನು. ತುಮಕೂರಿನ ನೈಸರ್ಗಿಕ ಸೌಂದರ್ಯವನ್ನು ನೋಡುತ್ತಾ ಬೆಳೆದ ಅವನು, ತನ್ನ ಸುತ್ತಮುತ್ತಲಿನ ಎಲ್ಲರ ಬಗ್ಗೆ ಪ್ರೀತಿ ಮತ್ತು ಕರುಣೆಯನ್ನು ಬೆಳೆಸಿಕೊಂಡನು. ಈ ಕುತೂಹಲಕಾರಿ ಮಗು ಒಂದು ದಿನ ಮಹಾನ್ ಸಂತನಾಗಿ ಸಾವಿರಾರು ಜನರ ಜೀವನವನ್ನು ಬದಲಾಯಿಸುತ್ತದೆ ಎಂದು ಗ್ರಾಮಸ್ಥರಿಗೆ ತಿಳಿದಿರಲಿಲ್ಲ. ಅವನ ಆರಂಭಿಕ ದಿನಗಳು ಸರಳ ಜೀವನ ಮತ್ತು ಉನ್ನತ ಚಿಂತನೆಯಿಂದ ಕೂಡಿದ್ದವು, ಇದು ಮಾನವೀಯತೆ ಮತ್ತು ಆಧ್ಯಾತ್ಮಿಕತೆಗೆ ಮೀಸಲಾದ ಜೀವನಕ್ಕೆ ಅಡಿಪಾಯ ಹಾಕಿತು.", "☀️"],
        ["As he grew, Shivanna dedicated himself to deep study and spiritual discipline. He joined the Siddaganga Math in Tumakuru, a place that would soon become his home for decades. Recognizing his wisdom and pure heart, he was chosen to lead the institution. In 1930, he became the pontiff, starting a journey that would last for an incredible seventy-eight years. He walked with poise and simplicity, always wearing a calm smile. He believed that education was the greatest light a person could receive, and he made it his life’s mission to light lamps of knowledge in every young soul he encountered.", "ಅವನು ಬೆಳೆದಂತೆ, ಶಿವಣ್ಣ ಆಳವಾದ ಅಧ್ಯಯನ ಮತ್ತು ಆಧ್ಯಾತ್ಮಿಕ ಶಿಸ್ತಿಗೆ ತನ್ನನ್ನು ಅರ್ಪಿಸಿಕೊಂಡನು. ಅವನು ತುಮಕೂರಿನ ಸಿದ್ಧಗಂಗಾ ಮಠವನ್ನು ಸೇರಿದನು, ಇದು ಶೀಘ್ರದಲ್ಲೇ ದಶಕಗಳ ಕಾಲ ಅವನ ಮನೆಯಾಯಿತು. ಅವನ ಜ್ಞಾನ ಮತ್ತು ಶುದ್ಧ ಹೃದಯವನ್ನು ಗುರುತಿಸಿ, ಅವನನ್ನು ಸಂಸ್ಥೆಯ ನೇತೃತ್ವ ವಹಿಸಲು ಆಯ್ಕೆ ಮಾಡಲಾಯಿತು. 1930 ರಲ್ಲಿ, ಅವರು ಮಠಾಧೀಶರಾದರು, ಸುಮಾರು ಎಪ್ಪತ್ತೆಂಟು ವರ್ಷಗಳ ಕಾಲ ಸುದೀರ್ಘ ಪ್ರಯಾಣವನ್ನು ಪ್ರಾರಂಭಿಸಿದರು. ಅವರು ಶಾಂತ ನಗುವಿನೊಂದಿಗೆ ಸರಳವಾಗಿ ನಡೆಯುತ್ತಿದ್ದರು. ಶಿಕ್ಷಣವು ಒಬ್ಬ ವ್ಯಕ್ತಿಯು ಪಡೆಯಬಹುದಾದ ಅತ್ಯಂತ ದೊಡ್ಡ ಬೆಳಕು ಎಂದು ಅವರು ನಂಬಿದ್ದರು ಮತ್ತು ಪ್ರತಿಯೊಬ್ಬ ಯುವ ಆತ್ಮದಲ್ಲಿ ಜ್ಞಾನದ ದೀಪಗಳನ್ನು ಬೆಳಗಿಸುವುದನ್ನು ಅವರು ತಮ್ಮ ಜೀವನದ ಉದ್ದೇಶವನ್ನಾಗಿ ಮಾಡಿಕೊಂಡರು.", "📚"],
        ["The Swamiji introduced a wonderful concept called 'Tri-vidha Dasoha,' which means three kinds of giving. He promised that no child who came to his doors would ever go hungry, lack a place to sleep, or be denied an education. He built massive kitchens where healthy food was prepared every day for more than ten thousand children. Regardless of their caste, religion, or background, all children sat together as one family. This was a place of equality and love. Swamiji worked tirelessly, managing the vast institution with great care to ensure that every student felt safe, nourished, and encouraged to grow into a good citizen.", "ಸ್ವಾಮೀಜಿಯವರು 'ತ್ರಿವಿಧ ದಾಸೋಹ' ಎಂಬ ಅದ್ಭುತ ಪರಿಕಲ್ಪನೆಯನ್ನು ಪರಿಚಯಿಸಿದರು. ಇದರರ್ಥ ಅನ್ನ, ಅಕ್ಷರ ಮತ್ತು ಆಶ್ರಯ ಎಂಬ ಮೂರು ದಾನಗಳು. ತನ್ನ ಮನೆಬಾಗಿಲಿಗೆ ಬರುವ ಯಾವುದೇ ಮಗು ಹಸಿವಿನಿಂದ ಇರಬಾರದು, ಮಲಗಲು ಜಾಗವಿಲ್ಲದೆ ಇರಬಾರದು ಅಥವಾ ಶಿಕ್ಷಣದಿಂದ ವಂಚಿತವಾಗಬಾರದು ಎಂದು ಅವರು ಭರವಸೆ ನೀಡಿದರು. ಪ್ರತಿದಿನ ಹತ್ತು ಸಾವಿರಕ್ಕೂ ಹೆಚ್ಚು ಮಕ್ಕಳಿಗೆ ಪೌಷ್ಟಿಕ ಆಹಾರವನ್ನು ತಯಾರಿಸುವ ಬೃಹತ್ ಅಡುಗೆಮನೆಗಳನ್ನು ಅವರು ನಿರ್ಮಿಸಿದರು. ಜಾತಿ, ಧರ್ಮ ಅಥವಾ ಹಿನ್ನೆಲೆ ಏನೇ ಇರಲಿ, ಎಲ್ಲಾ ಮಕ್ಕಳು ಒಂದೇ ಕುಟುಂಬವಾಗಿ ಒಟ್ಟಾಗಿ ಕುಳಿತು ಫಲಾಹಾರ ಸೇವಿಸುತ್ತಿದ್ದರು. ಇದು ಸಮಾನತೆ ಮತ್ತು ಪ್ರೀತಿಯ ತಾಣವಾಗಿತ್ತು. ಪ್ರತಿಯೊಬ್ಬ ವಿದ್ಯಾರ್ಥಿಯು ಸುರಕ್ಷಿತವಾಗಿರಲು ಮತ್ತು ಉತ್ತಮ ನಾಗರಿಕರಾಗಿ ಬೆಳೆಯಲು ಸ್ವಾಮೀಜಿಯವರು ದಣಿವರಿಯಿಲ್ಲದೆ ಕೆಲಸ ಮಾಡಿದರು.", "🍲"],
        ["Because of his selfless work and his habit of walking among the people to help them, everyone in Karnataka began to call him 'Nadedaduva Devaru,' which means the 'Walking God.' His fame reached far and wide, and he received many honors including the Padma Bhushan in 2015, the Karnataka Ratna in 2007, and the Basava International Award. Even when he was over a hundred years old, he remained active, waking up early and performing his duties with the same energy as a young man. He lived to the amazing age of 111, proving that a life spent in service to others is the most beautiful life of all.", "ಅವರ ನಿಸ್ವಾರ್ಥ ಸೇವೆ ಮತ್ತು ಜನರಿಗೆ ಸಹಾಯ ಮಾಡಲು ಅವರ ಮಧ್ಯೆ ನಡೆಯುವ ಅಭ್ಯಾಸದಿಂದಾಗಿ, ಕರ್ನಾಟಕದ ಪ್ರತಿಯೊಬ್ಬರೂ ಅವರನ್ನು 'ನಡೆದಾಡುವ ದೇವರು' ಎಂದು ಕರೆಯಲು ಪ್ರಾರಂಭಿಸಿದರು. ಅವರ ಕೀರ್ತಿ ದೇಶವಿದೇಶಗಳಲ್ಲಿ ಹರಡಿತು ಮತ್ತು ಅವರು 2015 ರಲ್ಲಿ ಪದ್ಮಭೂಷಣ, 2007 ರಲ್ಲಿ ಕರ್ನಾಟಕ ರತ್ನ ಮತ್ತು ಬಸವ ಅಂತರಾಷ್ಟ್ರೀಯ ಪ್ರಶಸ್ತಿ ಸೇರಿದಂತೆ ಅನೇಕ ಗೌರವಗಳನ್ನು ಪಡೆದರು. ನೂರು ವರ್ಷ ದಾಟಿದ ನಂತರವೂ ಅವರು ಮುಂಜಾನೆ ಎದ್ದು ಯುವಕನಂತೆಯೇ ಕ್ರಿಯಾಶೀಲರಾಗಿ ತಮ್ಮ ಕಾರ್ಯಗಳನ್ನು ಮಾಡುತ್ತಿದ್ದರು. ಅವರು 111 ವರ್ಷಗಳ ಆಶ್ಚರ್ಯಕರ ವಯಸ್ಸಿನವರೆಗೆ ಬದುಕಿದ್ದರು, ಇತರರ ಸೇವೆಯಲ್ಲಿ ಕಳೆದ ಜೀವನವೇ ಅತ್ಯಂತ ಸುಂದರವಾದ ಜೀವನ ಎಂದು ಅವರು ಸಾಬೀತುಪಡಿಸಿದರು.", "🎖️"],
        ["Sri Shivakumara Swamiji passed away in 2019, but his spirit lives on in the hearts of the millions of students he educated. Today, the Siddaganga Math remains a beacon of hope and learning. Children are taught to be kind, hardworking, and to treat everyone as equals, just as the Swamiji did. Whenever we see someone helping a hungry person or teaching a child, we remember the Walking God. His story inspires us to be selfless and to remember that the greatest way to worship God is by serving our fellow human beings with a pure and loving heart.", "ಶ್ರೀ ಶಿವಕುಮಾರ ಸ್ವಾಮೀಜಿಯವರು 2019 ರಲ್ಲಿ ನಿಧನರಾದರು, ಆದರೆ ಅವರು ನೀಡಿದ ಶಿಕ್ಷಣದ ಮೂಲಕ ಲಕ್ಷಾಂತರ ವಿದ್ಯಾರ್ಥಿಗಳ ಹೃದಯದಲ್ಲಿ ಇಂದಿಗೂ ಜೀವಂತವಾಗಿದ್ದಾರೆ. ಇಂದು ಕೂಡ ಸಿದ್ಧಗಂಗಾ ಮಠವು ಭರವಸೆ ಮತ್ತು ಕಲಿಕೆಯ ಸಂಕೇತವಾಗಿ ಉಳಿದಿದೆ. ಸ್ವಾಮೀಜಿಯವರು ಮಾಡಿದಂತೆಯೇ ಮಕ್ಕಳು ದಯಾಳುವಾಗಿರಲು, ಕಷ್ಟಪಟ್ಟು ದುಡಿಯಲು ಮತ್ತು ಎಲ್ಲರನ್ನೂ ಸಮಾನವಾಗಿ ಕಾಣಲು ಇಲ್ಲಿ ಕಲಿಯುತ್ತಾರೆ. ಯಾರಾದರೂ ಹಸಿದವರಿಗೆ ಸಹಾಯ ಮಾಡುವುದನ್ನು ಅಥವಾ ಮಗುವಿಗೆ ಪಾಠ ಮಾಡುವುದನ್ನು ನೋಡಿದಾಗ ನಮಗೆ ಈ ನಡೆದಾಡುವ ದೇವರು ನೆನಪಾಗುತ್ತಾರೆ. ಅವರ ಕಥೆಯು ನಮಗೆ ನಿಸ್ವಾರ್ಥವಾಗಿರಲು ಮತ್ತು ಶುದ್ಧ ಹೃದಯದಿಂದ ಸಹ ಮಾನವರ ಸೇವೆ ಮಾಡುವುದೇ ದೇವರನ್ನು ಪೂಜಿಸುವ ಶ್ರೇಷ್ಠ ಮಾರ್ಗ ಎಂದು ನೆನಪಿಸುತ್ತದೆ.", "🙏"]
      ],
      quiz: [
        ["His math is at…", "ಮಠ?", ["Siddaganga", "Hampi", "Bidar"], ["ಸಿದ್ಧಗಂಗೆ", "ಹಂಪಿ", "ಬೀದರ್"], 0],
        ["He gave children…", "?", ["Free food & education", "Money only", "Toys"], ["ಊಟ-ಶಿಕ್ಷಣ", "ಹಣ", "ಆಟಿಕೆ"], 0],
      
        ['Math name?', 'ಮಠ?', ['Siddaganga', 'Hampi', 'Bidar'], ['ಸಿದ್ಧಗಂಗೆ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['He gave children?', 'ಮಕ್ಕಳಿಗೆ?', ['Free food & education', 'Money only', 'Toys'], ['ಊಟ-ಶಿಕ್ಷಣ', 'ಹಣ', 'ಆಟಿಕೆ'], 0],
        ['Nickname?', 'ಬಿರುದು?', ['Walking God', 'Tiger', 'Lion'], ['ನಡೆದಾಡುವ ದೇವರು', 'ಹುಲಿ', 'ಸಿಂಹ'], 0],
        ['He lived to age over?', 'ವಯಸ್ಸು?', ['100', '60', '80'], ['೧೦೦', '೬೦', '೮೦'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Tumakuru', 'Mysuru', 'Bidar'], ['ತುಮಕೂರು', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Awarded Padma…', 'ಪ್ರಶಸ್ತಿ?', ['Vibhushan', 'Shri', 'No award'], ['ವಿಭೂಷಣ', 'ಶ್ರೀ', 'ಇಲ್ಲ'], 0],
        ['Tradition?', 'ಪರಂಪರೆ?', ['Lingayat', 'Jain', 'Sikh'], ['ಲಿಂಗಾಯತ', 'ಜೈನ', 'ಸಿಖ್'], 0],
        ['Trikala…', 'ತ್ರಿಕಾಲ?', ['Dasoha', 'Yoga', 'Yagna'], ['ದಾಸೋಹ', 'ಯೋಗ', 'ಯಜ್ಞ'], 0],
      ],
      memorial: ["Siddaganga Math", "ಸಿದ್ಧಗಂಗಾ ಮಠ", "Siddaganga, Tumakuru", "ಸಿದ್ಧಗಂಗೆ", "A huge gurukula and free school.", "ಬೃಹತ್ ಗುರುಕುಲ.", "Siddaganga Math Tumakuru"],
    })],
  },
  {
    id: "udupi", name: { en: "Udupi", kn: "ಉಡುಪಿ" }, emoji: "🍛",
    heroes: [mkHero({
      id: "madhvacharya", emoji: "🛕",
      name: ["Madhvacharya", "ಮಧ್ವಾಚಾರ್ಯ"],
      title: ["Philosopher of Udupi", "ಉಡುಪಿಯ ತತ್ವಜ್ಞಾನಿ"],
      era: "1238 – 1317",
      pages: [
        ["Long ago, in the beautiful coastal village of Pajaka near Udupi, a special boy named Vasudeva was born in 1238. From his childhood, everyone noticed he was no ordinary child. He possessed incredible strength and a sharp mind that could understand complex ideas instantly. While other children played simple games, young Vasudeva was drawn to the mysteries of the universe and the grace of the divine. His parents realized that their son was destined for a spiritual journey that would change the world. Growing up amidst the lush greenery of coastal Karnataka, the curious boy spent his days learning and reflecting, preparing himself for a life dedicated to wisdom and truth.", "ಬಹಳ ಹಿಂದೆಯೇ, ಉಡುಪಿಯ ಹತ್ತಿರವಿರುವ ಸುಂದರವಾದ ಪಾಜಕ ಎಂಬ ಕರಾವಳಿ ಗ್ರಾಮದಲ್ಲಿ, ೧೨೩೮ ರಲ್ಲಿ ವಾಸುದೇವ ಎಂಬ ವಿಶೇಷ ಬಾಲಕನು ಜನಿಸಿದನು. ಬಾಲ್ಯದಿಂದಲೂ ಅವನೊಬ್ಬ ಅಸಾಮಾನ್ಯ ಬಾಲಕನೆಂದು ಎಲ್ಲರೂ ಗಮನಿಸಿದರು. ಅವನು ಅದ್ಭುತವಾದ ಶಕ್ತಿ ಮತ್ತು ಸಂಕೀರ್ಣ ವಿಚಾರಗಳನ್ನು ತಕ್ಷಣವೇ ಅರ್ಥಮಾಡಿಕೊಳ್ಳುವ ಚುರುಕಾದ ಬುದ್ಧಿಯನ್ನು ಹೊಂದಿದ್ದನು. ಇತರ ಮಕ್ಕಳು ಸಾಮಾನ್ಯ ಆಟಗಳನ್ನು ಆಡುವಾಗ, ಯುವ ವಾಸುದೇವನು ಬ್ರಹ್ಮಾಂಡದ ರಹಸ್ಯಗಳು ಮತ್ತು ದೈವಿಕ ಕೃಪೆಯತ್ತ ಆಕರ್ಷಿತನಾಗಿದ್ದನು. ತಮ್ಮ ಮಗನು ಜಗತ್ತನ್ನು ಬದಲಾಯಿಸುವ ಆಧ್ಯಾತ್ಮಿಕ ಪ್ರಯಾಣಕ್ಕಾಗಿ ಜನಿಸಿದ್ದಾನೆಂದು ಅವನ ಪೋಷಕರು ಅರಿತುಕೊಂಡರು. ಕರಾವಳಿ ಕರ್ನಾಟಕದ ಹಚ್ಚ ಹಸಿರಿನ ನಡುವೆ ಬೆಳೆದ ಈ ಕುತೂಹಲದ ಹುಡುಗನು ತನ್ನ ದಿನಗಳನ್ನು ಕಲಿಕೆ ಮತ್ತು ಚಿಂತನೆಯಲ್ಲಿ ಕಳೆಯುತ್ತಾ, ಜ್ಞಾನ ಮತ್ತು ಸತ್ಯಕ್ಕೆ ಸಮರ್ಪಿತವಾದ ಜೀವನಕ್ಕಾಗಿ ತನ್ನನ್ನು ಸಿದ್ಧಪಡಿಸಿಕೊಂಡನು.", "👶"],
        ["As he grew older, Vasudeva accepted the life of a monk and became known as Sri Madhvacharya. He traveled across the vast lands of India, engaging in deep discussions with many scholars. During this time, he developed his famous philosophy called Dvaita Vedanta. Unlike others who said everything is one, Madhvacharya taught a profound lesson: that God and the individual souls are eternally distinct and separate. He compared the relationship to a master and a servant, where devotion is the ultimate path to reach the divine. His teachings emphasized that everyone has a unique identity, and by serving the Lord with a pure heart, one could find true peace and liberation.", "ಅವನು ಬೆಳೆಯುತ್ತಾ ಹೋದಂತೆ, ವಾಸುದೇವನು ಸನ್ಯಾಸತ್ವವನ್ನು ಸ್ವೀಕರಿಸಿ ಶ್ರೀ ಮಧ್ವಾಚಾರ್ಯರೆಂದು ಪ್ರಸಿದ್ಧರಾದರು. ಅವರು ಭಾರತದ ವಿಶಾಲ ಭೂಭಾಗಗಳಲ್ಲಿ ಸಂಚರಿಸುತ್ತಾ, ಅನೇಕ ವಿದ್ವಾಂಸರೊಂದಿಗೆ ಆಳವಾದ ಚರ್ಚೆಗಳಲ್ಲಿ ತೊಡಗಿದರು. ಈ ಸಮಯದಲ್ಲಿ, ಅವರು 'ದ್ವೈತ ವೇದಾಂತ' ಎಂಬ ತಮ್ಮ ಪ್ರಸಿದ್ಧ ತತ್ವಶಾಸ್ತ್ರವನ್ನು ಅಭಿವೃದ್ಧಿಪಡಿಸಿದರು. ಎಲ್ಲವೂ ಒಂದೇ ಎಂದು ಹೇಳುವ ಇತರರಿಗಿಂತ ಭಿನ್ನವಾಗಿ, ಮಧ್ವಾಚಾರ್ಯರು ಒಂದು ಆಳವಾದ ಪಾಠವನ್ನು ಬೋಧಿಸಿದರು: ದೇವರು ಮತ್ತು ವೈಯಕ್ತಿಕ ಆತ್ಮಗಳು ಶಾಶ್ವತವಾಗಿ ಭಿನ್ನವಾಗಿವೆ. ಅವರು ಈ ಸಂಬಂಧವನ್ನು ಯಜಮಾನ ಮತ್ತು ಸೇವಕನಿಗೆ ಹೋಲಿಸಿದರು, ಅಲ್ಲಿ ಭಕ್ತಿಯೇ ದೈವವನ್ನು ತಲುಪಲು ಪರಮ ಮಾರ್ಗವಾಗಿದೆ. ಪ್ರತಿಯೊಬ್ಬರಿಗೂ ವಿಶಿಷ್ಟವಾದ ಗುರುತಿದೆ ಮತ್ತು ಶುದ್ಧ ಹೃದಯದಿಂದ ಭಗವಂತನನ್ನು ಸೇವಿಸುವ ಮೂಲಕ ನಿಜವಾದ ಶಾಂತಿ ಮತ್ತು ಮುಕ್ತಿಯನ್ನು ಪಡೆಯಬಹುದು ಎಂದು ಅವರ ಬೋಧನೆಗಳು ಒತ್ತಿಹೇಳಿದವು.", "📚"],
        ["Sri Madhvacharya was a prolific writer who wanted to share his wisdom with everyone. Throughout his life, he composed thirty-seven great works, which are collectively known as the Sarvamula Granthas. These included insightful commentaries on the Brahma Sutras, the Bhagavad Gita, and the ancient Upanishads. He used his clear and logical writing to explain the dual nature of the world, making complex spiritual concepts easier for people to understand. His books became a guiding light for students and seekers, helping them navigate the challenges of life with faith and clarity. Through his pen, he built a solid foundation for a tradition that would inspire millions of people for centuries to come.", "ಶ್ರೀ ಮಧ್ವಾಚಾರ್ಯರು ತಮ್ಮ ಜ್ಞಾನವನ್ನು ಎಲ್ಲರೊಂದಿಗೆ ಹಂಚಿಕೊಳ್ಳಲು ಬಯಸಿದ ಸಮೃದ್ಧ ಬರಹಗಾರರಾಗಿದ್ದರು. ತಮ್ಮ ಜೀವನದುದ್ದಕ್ಕೂ ಅವರು ಮೂವತ್ತೇಳು ಶ್ರೇಷ್ಠ ಕೃತಿಗಳನ್ನು ರಚಿಸಿದರು, ಇವುಗಳನ್ನು ಒಟ್ಟಾಗಿ 'ಸರ್ವಮೂಲ ಗ್ರಂಥಗಳು' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ. ಇವುಗಳಲ್ಲಿ ಬ್ರಹ್ಮಸೂತ್ರಗಳು, ಭಗವದ್ಗೀತೆ ಮತ್ತು ಪ್ರಾಚೀನ ಉಪನಿಷತ್ತುಗಳ ಮೇಲಿನ ಒಳನೋಟವುಳ್ಳ ವ್ಯಾಖ್ಯಾನಗಳು ಸೇರಿವೆ. ಜಗತ್ತಿನ ದ್ವೈತ ಸ್ವಭಾವವನ್ನು ವಿವರಿಸಲು ಅವರು ತಮ್ಮ ಸ್ಪಷ್ಟ ಮತ್ತು ತಾರ್ಕಿಕ ಬರವಣಿಗೆಯನ್ನು ಬಳಸಿದರು, ಇದು ಸಂಕೀರ್ಣ ಆಧ್ಯಾತ್ಮಿಕ ಪರಿಕಲ್ಪನೆಗಳನ್ನು ಜನರು ಸುಲಭವಾಗಿ ಅರ್ಥಮಾಡಿಕೊಳ್ಳುವಂತೆ ಮಾಡಿತು. ಅವರ ಪುಸ್ತಕಗಳು ವಿದ್ಯಾರ್ಥಿಗಳಿಗೆ ಮತ್ತು ಸಾಧಕರಿಗೆ ಮಾರ್ಗದರ್ಶಕ ಬೆಳಕಾದವು, ನಂಬಿಕೆ ಮತ್ತು ಸ್ಪಷ್ಟತೆಯೊಂದಿಗೆ ಜೀವನದ ಸವಾಲುಗಳನ್ನು ಎದುರಿಸಲು ಅವರಿಗೆ ಸಹಾಯ ಮಾಡಿದವು. ತಮ್ಮ ಲೇಖನಿಯ ಮೂಲಕ, ಅವರು ಶತಮಾನಗಳವರೆಗೆ ಲಕ್ಷಾಂತರ ಜನರಿಗೆ ಸ್ಫೂರ್ತಿ ನೀಡುವ ಸಂಪ್ರದಾಯಕ್ಕೆ ಭದ್ರ ಬುನಾದಿ ಹಾಕಿದರು.", "✍️"],
        ["The most famous miracle of Madhvacharya happened by the sea in Udupi. One day, while meditating on the shore, he sensed a merchant ship in great danger during a storm. With his spiritual power and a signal from his saffron cloth, he guided the ship to safety. To thank him, the captain offered him anything from the cargo. Madhvacharya chose a large lump of clay called Gopi Chandana. Inside that clay, he discovered a beautiful, ancient idol of Lord Krishna. He carried this heavy idol all the way to Udupi and established the famous Krishna Matha. This legendary event filled the hearts of people with wonder and solidified Udupi as a sacred center for devotion and learning.", "ಮಧ್ವಾಚಾರ್ಯರ ಅತ್ಯಂತ ಪ್ರಸಿದ್ಧ ಪವಾಡವು ಉಡುಪಿಯ ಸಮುದ್ರತೀರದಲ್ಲಿ ಸಂಭವಿಸಿತು. ಒಂದು ದಿನ, ತೀರದಲ್ಲಿ ಧ್ಯಾನ ಮಾಡುತ್ತಿದ್ದಾಗ, ಬಿರುಗಾಳಿಯ ಸಮಯದಲ್ಲಿ ವ್ಯಾಪಾರಿ ಹಡಗೊಂದು ದೊಡ್ಡ ಅಪಾಯದಲ್ಲಿರುವುದನ್ನು ಅವರು ಗಮನಿಸಿದರು. ತಮ್ಮ ಆಧ್ಯಾತ್ಮಿಕ ಶಕ್ತಿ ಮತ್ತು ತಮ್ಮ ಕೇಸರಿ ವಸ್ತ್ರದ ಸಂಕೇತದಿಂದ, ಅವರು ಹಡಗನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ದಡಕ್ಕೆ ತಂದರು. ಅವರಿಗೆ ಕೃತಜ್ಞತೆ ಸಲ್ಲಿಸಲು, ಕ್ಯಾಪ್ಟನ್ ಹಡಗಿನ ಸರಕಿನಿಂದ ಯಾವುದನ್ನಾದರೂ ಆರಿಸಿಕೊಳ್ಳಲು ಕೇಳಿದನು. ಮಧ್ವಾಚಾರ್ಯರು 'ಗೋಪೀ ಚಂದನ' ಎಂಬ ದೊಡ್ಡ ಮಣ್ಣಿನ ಮುದ್ದೆಯನ್ನು ಆರಿಸಿಕೊಂಡರು. ಆ ಮಣ್ಣಿನ ಒಳಗೆ, ಅವರು ಭಗವಾನ್ ಶ್ರೀಕೃಷ್ಣನ ಸುಂದರವಾದ, ಪ್ರಾಚೀನ ವಿಗ್ರಹವನ್ನು ಕಂಡುಕೊಂಡರು. ಅವರು ಈ ಭಾರವಾದ ವಿಗ್ರಹವನ್ನು ಉಡುಪಿಯವರೆಗೆ ಹೊತ್ತು ತಂದು ಪ್ರಸಿದ್ಧ ಕೃಷ್ಣ ಮಠವನ್ನು ಸ್ಥಾಪಿಸಿದರು. ಈ ಪೌರಾಣಿಕ ಘಟನೆಯು ಜನರ ಹೃದಯಗಳನ್ನು ಅದ್ಭುತದಿಂದ ತುಂಬಿತು ಮತ್ತು ಉಡುಪಿಯನ್ನು ಭಕ್ತಿ ಮತ್ತು ಕಲಿಕೆಯ ಪವಿತ್ರ ಕೇಂದ್ರವಾಗಿ ಭದ್ರಪಡಿಸಿತು.", "🚢"],
        ["To ensure that the worship of Lord Krishna continued forever, Madhvacharya established the unique Ashta Mathas system. He appointed eight monk disciples to take turns caring for the temple, a tradition that continues to this very day. In 1317, after a lifetime of teaching and service, the great saint disappeared from physical sight while teaching his disciples, leaving behind a legacy of wisdom. Today, thousands of people visit the Udupi Krishna Matha to see the beautiful idol and feel the peace Madhvacharya brought to the world. His life teaches us that through discipline, knowledge, and deep love for the divine, we can illuminate the path for others and keep the flame of culture burning brightly.", "ಶ್ರೀಕೃಷ್ಣನ ಪೂಜೆಯು ಶಾಶ್ವತವಾಗಿ ಮುಂದುವರಿಯುವುದನ್ನು ಖಚಿತಪಡಿಸಿಕೊಳ್ಳಲು, ಮಧ್ವಾಚಾರ್ಯರು ವಿಶಿಷ್ಟವಾದ 'ಅಷ್ಟಮಠ' ವ್ಯವಸ್ಥೆಯನ್ನು ಸ್ಥಾಪಿಸಿದರು. ಅವರು ದೇವಾಲಯದ ಉಸ್ತುವಾರಿಯನ್ನು ವಹಿಸಿಕೊಳ್ಳಲು ಎಂಟು ಸನ್ಯಾಸಿ ಶಿಷ್ಯರನ್ನು ನೇಮಿಸಿದರು, ಈ ಸಂಪ್ರದಾಯವು ಇಂದಿಗೂ ಮುಂದುವರಿಯುತ್ತಿದೆ. ೧೩೧೭ ರಲ್ಲಿ, ಬೋಧನೆ ಮತ್ತು ಸೇವೆಯ ಜೀವನದ ನಂತರ, ಈ ಮಹಾನ್ ಸಂತರು ತಮ್ಮ ಶಿಷ್ಯರಿಗೆ ಬೋಧನೆ ಮಾಡುವಾಗ ದೈಹಿಕ ದೃಷ್ಟಿಯಿಂದ ಕಣ್ಮರೆಯಾದರು, ಜ್ಞಾನದ ಪರಂಪರೆಯನ್ನು ಉಳಿಸಿ ಹೋದರು. ಇಂದು, ಸಾವಿರಾರು ಜನರು ಉಡುಪಿ ಕೃಷ್ಣ ಮಠಕ್ಕೆ ಭೇಟಿ ನೀಡಿ ಸುಂದರವಾದ ವಿಗ್ರಹವನ್ನು ನೋಡಲು ಮತ್ತು ಮಧ್ವಾಚಾರ್ಯರು ಜಗತ್ತಿಗೆ ನೀಡಿದ ಶಾಂತಿಯನ್ನು ಅನುಭವಿಸಲು ಬರುತ್ತಾರೆ. ಶಿಸ್ತು, ಜ್ಞಾನ ಮತ್ತು ದೈವದ ಮೇಲಿನ ಆಳವಾದ ಪ್ರೀತಿಯ ಮೂಲಕ, ನಾವು ಇತರರಿಗೆ ದಾರಿದೀಪವಾಗಬಹುದು ಮತ್ತು ಸಂಸ್ಕೃತಿಯ ಜ್ಯೋತಿಯನ್ನು ಪ್ರಕಾಶಮಾನವಾಗಿ ಬೆಳಗಿಸಬಹುದು ಎಂದು ಅವರ ಜೀವನವು ನಮಗೆ ಕಲಿಸುತ್ತದೆ.", "🛕"]
      ],
      quiz: [
        ["Which temple did he found?", "ಯಾವ ದೇವಾಲಯ?", ["Udupi Krishna", "Hampi", "Belur"], ["ಉಡುಪಿ ಕೃಷ್ಣ", "ಹಂಪಿ", "ಬೇಲೂರು"], 0],
        ["Philosophy?", "ತತ್ವ?", ["Dvaita", "Advaita", "Yoga"], ["ದ್ವೈತ", "ಅದ್ವೈತ", "ಯೋಗ"], 0],
      
        ['He founded which philosophy?', 'ತತ್ವ?', ['Dvaita', 'Advaita', 'Yoga'], ['ದ್ವೈತ', 'ಅದ್ವೈತ', 'ಯೋಗ'], 0],
        ['Famous Krishna temple at?', 'ದೇವಾಲಯ?', ['Udupi', 'Hampi', 'Belur'], ['ಉಡುಪಿ', 'ಹಂಪಿ', 'ಬೇಲೂರು'], 0],
        ['He lived in century?', 'ಶತಮಾನ?', ['13th', '18th', '20th'], ['೧೩ನೇ', '೧೮ನೇ', '೨೦ನೇ'], 0],
        ['Real name?', 'ನಿಜ ಹೆಸರು?', ['Vasudeva', 'Naranappa', 'Basava'], ['ವಾಸುದೇವ', 'ನಾರಣಪ್ಪ', 'ಬಸವ'], 0],
        ['Birthplace?', 'ಜನ್ಮಸ್ಥಳ?', ['Pajaka', 'Hampi', 'Bidar'], ['ಪಾಜಕ', 'ಹಂಪಿ', 'ಬೀದರ್'], 0],
        ['He composed in?', 'ಭಾಷೆ?', ['Sanskrit', 'Tamil', 'Persian'], ['ಸಂಸ್ಕೃತ', 'ತಮಿಳು', 'ಪರ್ಷಿಯನ್'], 0],
        ['Eight maths he set up are called?', 'ಎಂಟು ಮಠ?', ['Ashta Mathas', 'Vachanas', 'Dasaru'], ['ಅಷ್ಟ ಮಠಗಳು', 'ವಚನ', 'ದಾಸರು'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Udupi', 'Mysuru', 'Bidar'], ['ಉಡುಪಿ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
      ],
      memorial: ["Udupi Sri Krishna Temple", "ಉಡುಪಿ ಕೃಷ್ಣ ದೇವಾಲಯ", "Udupi town", "ಉಡುಪಿ", "Famous for the unique 'Kanakana Kindi' window.", "'ಕನಕನ ಕಿಂಡಿ'.", "Udupi Sri Krishna Matha"],
    })],
  },
  {
    id: "uttara-kannada", name: { en: "Uttara Kannada", kn: "ಉತ್ತರ ಕನ್ನಡ" }, emoji: "🌴",
    heroes: [mkHero({
      id: "shivaram-karanth", emoji: "📖",
      name: ["Dr. K. Shivaram Karanth", "ಡಾ. ಕೆ. ಶಿವರಾಮ ಕಾರಂತ"],
      title: ["Many-Sided Genius of Karnataka", "ಬಹುಮುಖ ಪ್ರತಿಭಾವಂತ"],
      era: "1902 – 1997",
      pages: [
        ["In the beautiful coastal village of Kota, near the crashing waves of the Arabian Sea, a curious boy named Shivaram Karanth was born in 1902. From a young age, Shivaram was not like other children; he didn't just want to play, he wanted to understand everything about the world around him. He grew up surrounded by the rich traditions of coastal Karnataka, listening to folk stories and watching the golden sun set over the palm trees. This small village was the starting point for a boy who would one day be known as the 'Walking-Talking Encyclopedia' of his land. His heart was filled with a deep love for his mother tongue, Kannada, and a burning desire to explore every corner of art, science, and nature that he could find.", "ಅರಬ್ಬಿ ಸಮುದ್ರದ ಅಲೆಗಳ ಸದ್ದಿನ ನಡುವೆ, ಕೋಟ ಎಂಬ ಸುಂದರ ಕರಾವಳಿ ಗ್ರಾಮದಲ್ಲಿ ೧೯೦೨ ರಲ್ಲಿ ಶಿವರಾಮ ಕಾರಂತರು ಜನಿಸಿದರು. ಬಾಲ್ಯದಿಂದಲೇ ಶಿವರಾಮ ಇತರ ಮಕ್ಕಳಿಗಿಂತ ಭಿನ್ನವಾಗಿದ್ದರು; ಅವರಿಗೆ ಕೇವಲ ಆಟವಾಡುವುದಷ್ಟೇ ಅಲ್ಲದೆ, ಪ್ರಪಂಚದ ಬಗ್ಗೆ ಎಲ್ಲವನ್ನೂ ತಿಳಿಯುವ ಹಂಬಲವಿತ್ತು. ಕರಾವಳಿ ಕರ್ನಾಟಕದ ಸಮೃದ್ಧ ಸಂಪ್ರದಾಯಗಳು, ಜಾನಪದ ಕಥೆಗಳು ಮತ್ತು ತಾಳೆ ಮರಗಳ ನಡುವೆ ಅವರು ಬೆಳೆದರು. ಈ ಪುಟ್ಟ ಗ್ರಾಮವು ಮುಂದೆ 'ನಡೆಯುವ ಜ್ಞಾನಕೋಶ' ಎಂದು ಕರೆಸಿಕೊಳ್ಳುವ ಬಾಲಕನ ಆರಂಭಿಕ ತಾಣವಾಗಿತ್ತು. ಅವರ ಹೃದಯದಲ್ಲಿ ಕನ್ನಡ ಭಾಷೆಯ ಬಗ್ಗೆ ಅಪಾರ ಪ್ರೀತಿ ಮತ್ತು ಕಲೆ, ವಿಜ್ಞಾನ ಹಾಗೂ ಪ್ರಕೃತಿಯನ್ನು ಅರಿಯುವ ತೀವ್ರ ಆಕಾಂಕ್ಷೆಯಿತ್ತು.", "🌊"],
        ["As Shivaram grew older, he became fascinated by the magical dance-drama of Karnataka called Yakshagana. He loved the vibrant costumes, the loud drums, and the epic stories of gods and heroes. However, he noticed that this beautiful art form was slowly being forgotten. Wishing to keep the tradition alive for future generations, he founded the Yakshagana Kendra at Saligrama. He wasn't just a spectator; he studied the dance moves, the music, and the costumes, bringing new life to the ancient stage. Through his hard work, he showed everyone that our traditional arts are treasures that must be polished and protected. He believed that to know one's culture is to know oneself, and he spent years traveling and learning about the people of his district and beyond.", "ಶಿವರಾಮರು ಬೆಳೆಯುತ್ತಾ ಹೋದಂತೆ, ಕರ್ನಾಟಕದ ಅದ್ಭುತ ಕಲೆಯಾದ ಯಕ್ಷಗಾನದ ಕಡೆಗೆ ಆಕರ್ಷಿತರಾದರು. ಅವರಿಗೆ ಅದರ ಬಣ್ಣಬಣ್ಣದ ವೇಷಭೂಷಣಗಳು, ಚಂಡೆಯ ಸದ್ದು ಮತ್ತು ಪುರಾಣ ಕಥೆಗಳು ಬಹಳ ಇಷ್ಟವಾದವು. ಆದರೆ, ಈ ಸುಂದರ ಕಲೆಯು ಮರೆಯಾಗುತ್ತಿರುವುದನ್ನು ಕಂಡು ಅವರು ಸಾಲಿಗ್ರಾಮದಲ್ಲಿ 'ಯಕ್ಷಗಾನ ಕೇಂದ್ರ'ವನ್ನು ಸ್ಥಾಪಿಸಿದರು. ಅವರು ಕೇವಲ ಪ್ರೇಕ್ಷಕರಾಗಿ ಉಳಿಯದೆ, ನೃತ್ಯದ ನಡೆಗಳು ಮತ್ತು ಸಂಗೀತವನ್ನು ಅಭ್ಯಾಸ ಮಾಡಿ ಈ ಪ್ರಾಚೀನ ಕಲೆಗೆ ಹೊಸ ಚೈತನ್ಯ ನೀಡಿದರು. ಕಠಿಣ ಪರಿಶ್ರಮದ ಮೂಲಕ ನಮ್ಮ ಸಂಪ್ರದಾಯಗಳು ನಾವು ರಕ್ಷಿಸಬೇಕಾದ ಅಮೂಲ್ಯ ನಿಧಿಗಳು ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು. ಒಬ್ಬರ ಸಂಸ್ಕೃತಿಯನ್ನು ತಿಳಿಯುವುದು ಎಂದರೆ ತಮ್ಮನ್ನು ತಾವು ಅರಿತುಕೊಳ್ಳುವುದು ಎಂಬುದು ಅವರ ನಂಬಿಕೆಯಾಗಿತ್ತು.", "🎭"],
        ["Shivaram Karanth was a man of many talents, but his greatest tool was his pen. He wrote an incredible forty-seven novels that told the stories of ordinary people and their dreams. His most famous book, 'Mookajjiya Kanasugalu', explored deep thoughts through the eyes of an elderly woman, and it won him the prestigious Jnanpith Award in 1977. Whether he was writing about the return to one’s roots in 'Marali Mannige' or creating encyclopedias for children, he wanted to share knowledge with everyone. He believed that books could open doors to new worlds. His curious mind led him to write about everything from birds and animals to science and history, proving that one person can truly become a master of many different subjects if they never stop learning.", "ಶಿವರಾಮ ಕಾರಂತರು ಬಹುಮುಖ ಪ್ರತಿಭೆಯುಳ್ಳವರು, ಆದರೆ ಅವರ ದೊಡ್ಡ ಶಕ್ತಿ ಅವರ ಲೇಖನಿಯಾಗಿತ್ತು. ಅವರು ಸಾಮಾನ್ಯ ಜನರ ಕಥೆಗಳನ್ನು ಹೇಳುವ ಸುಮಾರು ೪೭ ಕಾದಂಬರಿಗಳನ್ನು ಬರೆದರು. ಅವರ ಪ್ರಸಿದ್ಧ ಕೃತಿ 'ಮೂಕಜ್ಜಿಯ ಕನಸುಗಳು', ಒಬ್ಬ ವೃದ್ಧೆಯ ಮೂಲಕ ಆಳವಾದ ಆಲೋಚನೆಗಳನ್ನು ಹಂಚಿಕೊಂಡಿತು ಮತ್ತು ಈ ಪುಸ್ತಕಕ್ಕೆ ೧೯೭೭ ರಲ್ಲಿ ಪ್ರತಿಷ್ಠಿತ ಜ್ಞಾನಪೀಠ ಪ್ರಶಸ್ತಿ ಲಭಿಸಿತು. 'ಮರಳಿ ಮಣ್ಣಿಗೆ'ಯಂತಹ ಕೃತಿಗಳ ಮೂಲಕ ಮಣ್ಣಿನ ಗುಣವನ್ನು ಸಾರಿದ ಅವರು, ಮಕ್ಕಳಿಗಾಗಿ ಜ್ಞಾನಕೋಶಗಳನ್ನೂ ರಚಿಸಿದರು. ಪುಸ್ತಕಗಳು ಹೊಸ ಪ್ರಪಂಚಕ್ಕೆ ದಾರಿ ಮಾಡಿಕೊಡುತ್ತವೆ ಎಂದು ಅವರು ನಂಬಿದ್ದರು. ಪಕ್ಷಿಗಳಿಂದ ಹಿಡಿದು ವಿಜ್ಞಾನದವರೆಗೆ ಅವರು ಬರೆದ ವಿಷಯಗಳು ಒಬ್ಬ ವ್ಯಕ್ತಿ ನಿರಂತರವಾಗಿ ಕಲಿಯುತ್ತಿದ್ದರೆ ಏನನ್ನು ಬೇಕಾದರೂ ಸಾಧಿಸಬಹುದು ಎಂದು ನಿರೂಪಿಸಿದವು.", "✍️"],
        ["Beyond books and art, Dr. Karanth was a brave protector of the earth. He loved the green forests of the Western Ghats and knew that nature was our life support. When he saw the environment being harmed, he didn't stay quiet. He led the 'Save Western Ghats' march to teach people about the importance of trees and clean water. He even stood up against the building of the Kaiga nuclear plant because he worried about the safety of his land and its people. For him, being a hero meant standing up for what is right, even when it is difficult. He was so dedicated to his principles that he even returned his Padma Bhushan award in protest when he felt that freedom and democracy were being threatened during the Emergency period.", "ಪುಸ್ತಕ ಮತ್ತು ಕಲೆಯ ಹೊರತಾಗಿ, ಕಾರಂತರು ಭೂಮಿಯ ಧೈರ್ಯಶಾಲಿ ರಕ್ಷಕರಾಗಿದ್ದರು. ಅವರು ಪಶ್ಚಿಮ ಘಟ್ಟಗಳ ಹಸಿರು ಕಾಡುಗಳನ್ನು ಪ್ರೀತಿಸುತ್ತಿದ್ದರು ಮತ್ತು ಪ್ರಕೃತಿಯೇ ನಮ್ಮ ಜೀವಾಳ ಎಂದು ತಿಳಿದಿದ್ದರು. ಪರಿಸರಕ್ಕೆ ಹಾನಿಯಾಗುತ್ತಿರುವುದನ್ನು ಕಂಡಾಗ ಅವರು ಸುಮ್ಮನೆ ಕೂರಲಿಲ್ಲ. ಮರಗಳು ಮತ್ತು ಶುದ್ಧ ನೀರಿನ ಮಹತ್ವವನ್ನು ತಿಳಿಸಲು ಅವರು 'ಪಶ್ಚಿಮ ಘಟ್ಟ ಉಳಿಸಿ' ಅಭಿಯಾನದ ನೇತೃತ್ವ ವಹಿಸಿದರು. ಕೈಗಾ ಅಣು ವಿದ್ಯುತ್ ಸ್ಥಾವರದ ವಿರುದ್ಧವೂ ಅವರು ಧ್ವನಿ ಎತ್ತಿದರು. ತನ್ನ ನಾಡು ಮತ್ತು ಜನರ ಸುರಕ್ಷತೆಗಾಗಿ ಹೋರಾಡುವುದೇ ನಿಜವಾದ ನಾಯಕತ್ವ ಎಂದು ಅವರು ನಂಬಿದ್ದರು. ತಮ್ಮ ತತ್ವಗಳಿಗೆ ಎಷ್ಟು ಬದ್ಧರಾಗಿದ್ದರೆಂದರೆ, ತುರ್ತುಪರಿಸ್ಥಿತಿಯ ಸಮಯದಲ್ಲಿ ಸ್ವಾತಂತ್ರ್ಯಕ್ಕೆ ಧಕ್ಕೆಯಾದಾಗ ತಮಗೆ ಬಂದಿದ್ದ ಪದ್ಮಭೂಷಣ ಪ್ರಶಸ್ತಿಯನ್ನು ಪ್ರತಿಭಟನೆಯಾಗಿ ಹಿಂದಿರುಗಿಸಿದರು.", "🌳"],
        ["Dr. K. Shivaram Karanth lived a long and wonderful life until 1997, leaving behind a legacy that glows brightly in Karnataka. He showed us that a single person can be a writer, a dancer, a scientist, and a protector of nature all at once. Today, we remember him as the 'Many-Sided Genius' who taught us to be curious, brave, and deeply connected to our roots. Children in Karnataka still read his stories and learn from his encyclopedias. His life teaches us that we should never stop asking questions and that we must always work to make our world a more beautiful and knowledgeable place. Like a great lighthouse on the coast of Udupi, his wisdom continues to guide us toward a brighter future for our language and our land.", "ಡಾ. ಕೆ. ಶಿವರಾಮ ಕಾರಂತರು ೧೯೯೭ ರವರೆಗೆ ಸುದೀರ್ಘ ಮತ್ತು ಸಾರ್ಥಕ ಜೀವನ ನಡೆಸಿದರು. ಅಕ್ಷರದ ಮೂಲಕ, ಕಲೆಯ ಮೂಲಕ ಅವರು ಕರ್ನಾಟಕದಲ್ಲಿ ದೊಡ್ಡ ಪರಂಪರೆಯನ್ನೇ ಬಿಟ್ಟು ಹೋಗಿದ್ದಾರೆ. ಒಬ್ಬನೇ ವ್ಯಕ್ತಿ ಏಕಕಾಲದಲ್ಲಿ ಬರಹಗಾರ, ನರ್ತಕ, ವಿಜ್ಞಾನಿ ಮತ್ತು ಪರಿಸರ ರಕ್ಷಕನಾಗಬಹುದು ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು. ಇಂದು ನಾವು ಅವರನ್ನು ಕುತೂಹಲ, ಧೈರ್ಯ ಮತ್ತು ಮಣ್ಣಿನ ಸೆಲೆಯ ಪ್ರೇರಕಶಕ್ತಿಯಾಗಿ ನೆನೆಯುತ್ತೇವೆ. ಅವರ ಜೀವನವು ನಾವು ಪ್ರಶ್ನಿಸುವುದನ್ನು ನಿಲ್ಲಿಸಬಾರದು ಮತ್ತು ಜಗತ್ತನ್ನು ಸುಂದರವಾಗಿರಿಸಲು ಶ್ರಮಿಸಬೇಕು ಎಂದು ಕಲಿಸುತ್ತದೆ. ಉಡುಪಿಯ ಕರಾವಳಿಯ दीपಸ್ತಂಭದಂತೆ, ಅವರ ಜ್ಞಾನವು ನಮ್ಮ ಭಾಷೆ ಮತ್ತು ನಾಡಿನ ಉಜ್ವಲ ಭವಿಷ್ಯಕ್ಕೆ ಇಂದಿಗೂ ದಾರಿದೀಪವಾಗಿದೆ.", "🌟"]
      ],
      quiz: [
        ["Dance he revived?", "ನೃತ್ಯ?", ["Yakshagana", "Kathak", "Odissi"], ["ಯಕ್ಷಗಾನ", "ಕಥಕ್", "ಒಡಿಸ್ಸಿ"], 0],
        ["He won the…", "ಪ್ರಶಸ್ತಿ?", ["Jnanpith", "Oscar", "Grammy"], ["ಜ್ಞಾನಪೀಠ", "ಆಸ್ಕರ್", "ಗ್ರ್ಯಾಮಿ"], 0],
      
        ['Dance form he revived?', 'ನೃತ್ಯ?', ['Yakshagana', 'Kathak', 'Odissi'], ['ಯಕ್ಷಗಾನ', 'ಕಥಕ್', 'ಒಡಿಸ್ಸಿ'], 0],
        ['Award he won?', 'ಪ್ರಶಸ್ತಿ?', ['Jnanpith', 'Oscar', 'Grammy'], ['ಜ್ಞಾನಪೀಠ', 'ಆಸ್ಕರ್', 'ಗ್ರ್ಯಾಮಿ'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Uttara Kannada', 'Mysuru', 'Bidar'], ['ಉತ್ತರ ಕನ್ನಡ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Famous novel?', 'ಕಾದಂಬರಿ?', ['Mookajjiya Kanasugalu', 'Hamsageete', 'Both'], ['ಮೂಕಜ್ಜಿಯ ಕನಸುಗಳು', 'ಹಂಸಗೀತೆ', 'ಎರಡೂ'], 0],
        ['He was called walking…', 'ನಡೆದಾಡುವ?', ['Encyclopedia', 'King', 'Tiger'], ['ವಿಶ್ವಕೋಶ', 'ರಾಜ', 'ಹುಲಿ'], 0],
        ['Born in year?', 'ಜನ್ಮ?', ['1902', '1850', '1947'], ['೧೯೦೨', '೧೮೫೦', '೧೯೪೭'], 0],
        ['Died in year?', 'ಮರಣ?', ['1997', '1947', '2010'], ['೧೯೯೭', '೧೯೪೭', '೨೦೧೦'], 0],
        ['He wrote in language?', 'ಭಾಷೆ?', ['Kannada', 'Telugu', 'Hindi'], ['ಕನ್ನಡ', 'ತೆಲುಗು', 'ಹಿಂದಿ'], 0],
      ],
      memorial: ["Yakshagana Kendra", "ಯಕ್ಷಗಾನ ಕೇಂದ್ರ", "Saligrama, near Kundapura", "ಸಾಲಿಗ್ರಾಮ", "A folk-art centre he founded.", "ಯಕ್ಷಗಾನ ಕೇಂದ್ರ.", "Yakshagana Kendra Saligrama"],
    })],
  },
  {
    id: "vijayanagara", name: { en: "Vijayanagara", kn: "ವಿಜಯನಗರ" }, emoji: "🛕",
    heroes: [mkHero({
      id: "purandara-dasa", emoji: "🪕",
      name: ["Purandara Dasa", "ಪುರಂದರ ದಾಸ"],
      title: ["Father of Carnatic Music", "ಕರ್ನಾಟಕ ಸಂಗೀತದ ಪಿತಾಮಹ"],
      era: "1484 – 1564",
      pages: [
        ["Long ago in the land of Karnataka, there lived a very wealthy man named Srinivasa Nayaka. Born in 1484, he was a famous diamond merchant in Purandaragad who cared more for his gold coins than anything else. He was so clever at business that people called him 'Navakoti Narayana,' the master of nine crore riches. Although he was successful, his heart was closed to the beauty of music and the needs of others. He spent his days counting glittering jewels and expanding his vast fortune, never imagining that his life was about to change forever through a magical lesson in kindness that would lead him away from his diamond shop and toward a path of divine melodies.", "ಬಹಳ ಹಿಂದಿನ ಕಾಲದಲ್ಲಿ ಕರ್ನಾಟಕದ ಪುರಂದರಗಡದಲ್ಲಿ ಶ್ರೀನಿವಾಸ ನಾಯಕ ಎಂಬ ಅತ್ಯಂತ ಶ್ರೀಮಂತ ವ್ಯಕ್ತಿ ಇದ್ದನು. ಕ್ರಿ.ಶ. 1484ರಲ್ಲಿ ಜನಿಸಿದ ಈತ ಪ್ರಸಿದ್ಧ ವಜ್ರದ ವ್ಯಾಪಾರಿಯಾಗಿದ್ದನು. ಆತನಿಗೆ ತನ್ನ ಚಿನ್ನದ ನಾಣ್ಯಗಳ ಮೇಲೆ ಅತಿಯಾದ ಮೋಹವಿತ್ತು. ವ್ಯಾಪಾರದಲ್ಲಿ ಎಷ್ಟು ಚತುರನಾಗಿದ್ದನೆಂದರೆ ಜನರು ಆತನನ್ನು ಒಂಬತ್ತು ಕೋಟಿ ಸಂಪತ್ತಿನ ಒಡೆಯ 'ನವಕೋಟಿ ನಾರಾಯಣ' ಎಂದು ಕರೆಯುತ್ತಿದ್ದರು. ಆತ ಯಶಸ್ವಿಯಾಗಿದ್ದರೂ, ಆತನ ಹೃದಯವು ಸಂಗೀತದ ಸೌಂದರ್ಯಕ್ಕೆ ಮತ್ತು ಇತರರ ಸಂಕಷ್ಟಗಳಿಗೆ ಸ್ಪಂದಿಸುತ್ತಿರಲಿಲ್ಲ. ಹೊಳೆಯುವ ರತ್ನಗಳನ್ನು ಎಣಿಸುವುದರಲ್ಲೇ ದಿನ ಕಳೆಯುತ್ತಿದ್ದ ಆತ, ಮುಂದೆ ಒಂದು ದಿನ ಪ್ರೀತಿ ಮತ್ತು ಕರುಣೆಯ ಪಾಠದಿಂದ ತನ್ನ ಜೀವನವೇ ಸಂಪೂರ್ಣವಾಗಿ ಬದಲಾಗುತ್ತದೆ ಎಂದು ಕನಸಿನಲ್ಲೂ ಯೋಚಿಸಿರಲಿಲ್ಲ.", "💎"],
        ["One day, a legend tells us of a miracle involving a small nose-ring and a poor man. This event touched Srinivasa's heart deeply, making him realize that true wealth is not found in boxes of gold, but in devotion and goodness. At the age of 30, he made a brave choice to give away all his riches and live a simple life. He traveled to the glorious city of Hampi in the Vijayanagara Empire. There, he met a great teacher named Vyasaraya, who became his guru. Srinivasa was given a new name, Purandara Dasa. From a merchant of stones, he became a merchant of beautiful songs, carrying a small tamburi and tinkling bells on his ankles.", "ಒಂದು ದಂತಕಥೆಯ ಪ್ರಕಾರ, ಒಂದು ಸಣ್ಣ ಮೂಗುತಿ ಮತ್ತು ಬಡವನಿಗೆ ಸಂಬಂಧಿಸಿದ ಪವಾಡವು ಶ್ರೀನಿವಾಸನ ಹೃದಯವನ್ನು ಆಳವಾಗಿ ಸ್ಪರ್ಶಿಸಿತು. ನಿಜವಾದ ಸಂಪತ್ತು ಚಿನ್ನದ ಪೆಟ್ಟಿಗೆಗಳಲ್ಲಿಲ್ಲ, ಬದಲಾಗಿ ಭಕ್ತಿ ಮತ್ತು ಒಳ್ಳೆಯತನದಲ್ಲಿದೆ ಎಂದು ಆತನಿಗೆ ಅರಿವಾಯಿತು. ತನ್ನ 30ನೇ ವಯಸ್ಸಿನಲ್ಲಿ, ಆತ ತನ್ನೆಲ್ಲ ಸಂಪತ್ತನ್ನು ದಾನ ಮಾಡಿ ಸರಳ ಜೀವನ ನಡೆಸುವ ಕೆಚ್ಚೆದೆಯ ನಿರ್ಧಾರ ಮಾಡಿದನು. ಆತ ವಿಜಯನಗರ ಸಾಮ್ರಾಜ್ಯದ ವೈಭವದ ಹಂಪಿಗೆ ಪ್ರಯಾಣಿಸಿದನು. ಅಲ್ಲಿ ಮಹಾನ್ ಗುರುಗಳಾದ ವ್ಯಾಸರಾಯರನ್ನು ಭೇಟಿಯಾದನು. ಶ್ರೀನಿವಾಸನಿಗೆ ‘ಪುರಂದರ ದಾಸ’ ಎಂಬ ಹೊಸ ಹೆಸರು ನೀಡಲಾಯಿತು. ವಜ್ರದ ವ್ಯಾಪಾರಿಯಾಗಿದ್ದ ಆತ, ಕೈಯಲ್ಲಿ ತಂಬೂರಿ ಮತ್ತು ಕಾಲಿಗೆ ಗೆಜ್ಜೆ ಕಟ್ಟಿ ಸುಂದರ ಪದಗಳ ಗಾಯನ ಮಾಡುವ ದಾಸನಾದನು.", "✨"],
        ["In the busy courts and quiet temples of Hampi, Purandara Dasa noticed that music was very difficult for beginners to learn at that time. He wanted everyone, from little children to old people, to enjoy the magic of melody. So, he worked very hard to organize music into a perfect system. He created the 'Sarali Varase' and 'Janti Varase' exercises that act like the ABCs of music. He also composed simple songs called 'Geethams.' Because he built this wonderful foundation for everyone to follow, he is known today as the 'Pitamaha' or the Grandfather of Carnatic Music. He proved that even complex art could be shared with everyone through patience and structure.", "ಹಂಪಿಯ ಜನನಿಬಿಡ ಅರಮನೆ ಮತ್ತು ಶಾಂತ ದೇವಾಲಯಗಳಲ್ಲಿ, ಪುರಂದರ ದಾಸರು ಆ ಕಾಲದಲ್ಲಿ ಸಂಗೀತವನ್ನು ಕಲಿಯುವುದು ಆರಂಭಿಕರಿಗ ಬಹಳ ಕಷ್ಟಕರವೆಂದು ಗಮನಿಸಿದರು. ಸಣ್ಣ ಮಕ್ಕಳಿಂದ ಹಿಡಿದು ವೃದ್ಧರವರೆಗೆ ಪ್ರತಿಯೊಬ್ಬರೂ ಸಂಗೀತದ ಸೌಂದರ್ಯವನ್ನು ಆನಂದಿಸಬೇಕೆಂದು ಅವರು ಬಯಸಿದ್ದರು. ಆದ್ದರಿಂದ, ಅವರು ಸಂಗೀತವನ್ನು ಒಂದು ವ್ಯವಸ್ಥಿತ ರೂಪಕ್ಕೆ ತರಲು ಶ್ರಮಿಸಿದರು. ಸಂಗೀತದ ಅಕ್ಷರಮಾಲೆಯಂತಿರುವ 'ಸರಳೆ ವರಸೆ' ಮತ್ತು 'ಜಂಟಿ ವರಸೆ' ಕ್ರಮಗಳನ್ನು ರೂಪಿಸಿದರು. ಅವರು 'ಪಿಳ್ಳಾರಿ ಗೀತೆ'ಗಳನ್ನು ರಚಿಸಿದರು. ಪ್ರತಿಯೊಬ್ಬರೂ ಅನುಸರಿಸಲು ಈ ಅದ್ಭುತ ಅಡಿಪಾಯವನ್ನು ನಿರ್ಮಿಸಿದ್ದರಿಂದ ಅವರಿಗ ಇಂದು ಕರ್ನಾಟಕ ಸಂಗೀತದ 'ಪಿತಾಮಹ' ಎಂದು ಕರೆಯಲಾಗುತ್ತದೆ. ತಾಳ್ಮೆ ಮತ್ತು ಶಿಸ್ತಿನಿಂದ ಕಷ್ಟದ ಕಲೆಯನ್ನು ಎಲ್ಲರಿಗೂ ಹಂಚಬಹುದು ಎಂದು ಅವರು ತೋರಿಸಿಕೊಟ್ಟರು.", "🎼"],
        ["Purandara Dasa was a master storyteller and poet. It is said that he composed an unbelievable 4,75,000 devotional songs, known as Kritis or Devaranamas, in the beautiful Kannada language. He walked from village to village, singing about kindness, honesty, and love for God. Even though only about 1,000 of his songs have survived through the long centuries, each one carries a deep message. His songs were not just for the ears but for the soul, teaching people how to be better human beings while enjoying the rhythmic beats of the music. He turned the dry rules of grammar into flowing rivers of poetry that anyone could sing while working in the fields or resting at home.", "ಪುರಂದರ ದಾಸರು ಕಥೆಗಳನ್ನು ಹೇಳುವಲ್ಲಿ ಮತ್ತು ಕವಿತೆಗಳನ್ನು ರಚಿಸುವಲ್ಲಿ ನಿಪುಣರಾಗಿದ್ದರು. ಇವರು ಕನ್ನಡ ಭಾಷೆಯಲ್ಲಿ ಸುಮಾರು 4,75,000 ಕೃತಿಗಳನ್ನು ಅಥವಾ ದೇವರನಾಮಗಳನ್ನು ರಚಿಸಿದ್ದಾರೆಂದು ಹೇಳಲಾಗುತ್ತದೆ. ಅವರು ಹಳ್ಳಿ ಹಳ್ಳಿಗಳಿಗೆ ಸಂಚರಿಸಿ ಕರುಣೆ, ಪ್ರಾಮಾಣಿಕತೆ ಮತ್ತು ದೇವರ ಮೇಲಿನ ಪ್ರೀತಿಯ ಬಗ್ಗೆ ಹಾಡುತ್ತಿದ್ದರು. ಶತಮಾನಗಳ ನಂತರ ಇಂದು ಕೇವಲ ಒಂದು ಸಾವಿರದಷ್ಟು ಹಾಡುಗಳು ಮಾತ್ರ ಲಭ್ಯವಿದ್ದರೂ, ಪ್ರತಿಯೊಂದು ಹಾಡು ಆಳವಾದ ಸಂದೇಶವನ್ನು ಹೊಂದಿದೆ. ಇವರ ಹಾಡುಗಳು ಕೇವಲ ಕಿವಿಗಷ್ಟೇ ಅಲ್ಲದೆ ಆತ್ಮಕ್ಕೂ ತಲುಪುತ್ತಿದ್ದವು. ಜನರು ಉತ್ತಮ ನಾಯಕರಾಗುವುದು ಹೇಗೆಂದು ಇವರು ಸಂಗೀತದ ಮೂಲಕ ಕಲಿಸಿದರು. ವ್ಯಾಕರಣದ ನಿಯಮಗಳನ್ನು ಕಾವ್ಯದ ಹೊಳೆಯಾಗಿ ಪರಿವರ್ತಿಸಿದ ಇವರ ಹಾಡುಗಳನ್ನು ಹೊಲದಲ್ಲಿ ಕೆಲಸ ಮಾಡುವಾಗ ಅಥವಾ ಮನೆಯಲ್ಲಿ ವಿಶ್ರಾಂತಿ ಪಡೆಯುವಾಗ ಯಾರೂ ಬೇಕಾದರೂ ಹಾಡಬಹುದಾಗಿತ್ತು.", "🎶"],
        ["Today, whenever a student sits down to take their very first music lesson, they begin with the same exercises Purandara Dasa wrote hundreds of years ago. From 1484 until 1564, his life showed the world that it is never too late to change for the better. He transformed from a man who loved money into a saint who loved humanity and art. His legacy lives on in every concert hall and every school where Carnatic music is taught. Like a bright star over the ruins of Hampi, the spirit of the Pitamaha continues to inspire children everywhere to sing with joy, live with truth, and share their talents with the whole world.", "ಇಂದಿಗೂ ಯಾವುದೇ ವಿದ್ಯಾರ್ಥಿ ತನ್ನ ಮೊದಲ ಸಂಗೀತ ಪಾಠವನ್ನು ಕಲಿಯಲು ಕುಳಿತಾಗ, ನೂರಾರು ವರ್ಷಗಳ ಹಿಂದೆ ಪುರಂದರ ದಾಸರು ಬರೆದ ಅದೇ ಕ್ರಮಗಳಿಂದಲೇ ಆರಂಭಿಸುತ್ತಾರೆ. 1484 ರಿಂದ 1564 ರವರೆಗಿನ ಅವರ ಜೀವನವು, ಒಳ್ಳೆಯದಕ್ಕಾಗಿ ಬದಲಾಗಲು ಎಂದಿಗೂ ತಡವಾಗಿಲ್ಲ ಎಂದು ಜಗತ್ತಿಗೆ ತೋರಿಸಿಕೊಟ್ಟಿದೆ. ಹಣವನ್ನು ಪ್ರೀತಿಸುತ್ತಿದ್ದ ಮನುಷ್ಯನು ಮಾನವೀಯತೆ ಮತ್ತು ಕಲೆಯನ್ನು ಪ್ರೀತಿಸುವ ಸಂತನಾಗಿ ಬದಲಾದನು. ಕರ್ನಾಟಕ ಸಂಗೀತವನ್ನು ಕಲಿಸುವ ಪ್ರತಿಯೊಂದು ಶಾಲೆಯಲ್ಲಿ ಮತ್ತು ಸಭಾಂಗಣಗಳಲ್ಲಿ ಅವರ ಹೆಸರು ಅಜರಾಮರವಾಗಿದೆ. ಹಂಪಿಯ ಸ್ಮಾರಕಗಳ ಮೇಲಿರುವ ಪ್ರಕಾಶಮಾನ ನಕ್ಷತ್ರದಂತೆ, ಈ ಪಿತಾಮಹನ ನೆನಪು ಮಕ್ಕಳಿಗೆ ಸಂತೋಷದಿಂದ ಹಾಡಲು, ಸತ್ಯದಿಂದ ಬದುಕಲು ಮತ್ತು ತಮ್ಮ ಪ್ರತಿಭೆಯನ್ನು ಜಗತ್ತಿಗೆ ಹಂಚಲು ಸ್ಪೂರ್ತಿ ನೀಡುತ್ತಲೇ ಇದೆ.", "🌟"]
      ],
      quiz: [
        ["Father of…", "ಪಿತಾಮಹ?", ["Carnatic music", "Pop", "Cinema"], ["ಕರ್ನಾಟಕ ಸಂಗೀತ", "ಪಾಪ್", "ಸಿನಿಮಾ"], 0],
        ["He lived during…", "ಸಾಮ್ರಾಜ್ಯ?", ["Vijayanagara", "British rule", "Mauryan"], ["ವಿಜಯನಗರ", "ಬ್ರಿಟಿಷ್", "ಮೌರ್ಯ"], 0],
      
        ['Father of which music?', 'ಸಂಗೀತ?', ['Carnatic', 'Hindustani', 'Western'], ['ಕರ್ನಾಟಕ', 'ಹಿಂದೂಸ್ತಾನಿ', 'ಪಾಶ್ಚಾತ್ಯ'], 0],
        ['He lived during?', 'ಸಾಮ್ರಾಜ್ಯ?', ['Vijayanagara', 'British', 'Mauryan'], ['ವಿಜಯನಗರ', 'ಬ್ರಿಟಿಷ್', 'ಮೌರ್ಯ'], 0],
        ['Number of compositions (legend)?', 'ಎಷ್ಟು ರಚನೆ?', ['Lakhs', 'Tens', 'Hundreds'], ['ಲಕ್ಷಗಳು', 'ಹತ್ತಾರು', 'ನೂರಾರು'], 0],
        ['Real name?', 'ನಿಜ ಹೆಸರು?', ['Srinivasa Nayaka', 'Naranappa', 'Basava'], ['ಶ್ರೀನಿವಾಸ ನಾಯಕ', 'ನಾರಣಪ್ಪ', 'ಬಸವ'], 0],
        ['Wealthy profession before sainthood?', 'ವೃತ್ತಿ?', ['Jeweller', 'Farmer', 'Soldier'], ['ಚಿನ್ನದ ವ್ಯಾಪಾರಿ', 'ರೈತ', 'ಸೈನಿಕ'], 0],
        ['Wrote in language?', 'ಭಾಷೆ?', ['Kannada', 'Tamil', 'Persian'], ['ಕನ್ನಡ', 'ತಮಿಳು', 'ಪರ್ಷಿಯನ್'], 0],
        ['Belonged to which tradition?', 'ಪರಂಪರೆ?', ['Haridasa', 'Lingayat', 'Jain'], ['ಹರಿದಾಸ', 'ಲಿಂಗಾಯತ', 'ಜೈನ'], 0],
        ['Devotee of which deity?', 'ಭಕ್ತ?', ['Vitthala', 'Shiva', 'Surya'], ['ವಿಠ್ಠಲ', 'ಶಿವ', 'ಸೂರ್ಯ'], 0],
      ],
      memorial: ["Purandara Mantapa", "ಪುರಂದರ ಮಂಟಪ", "Hampi, Vijayanagara", "ಹಂಪಿ", "A small mantapa by the Tungabhadra.", "ತುಂಗಭದ್ರಾ ತೀರದ ಮಂಟಪ.", "Purandara Mantapa Hampi"],
    })],
  },
  {
    id: "vijayapura", name: { en: "Vijayapura", kn: "ವಿಜಯಪುರ" }, emoji: "🕌",
    heroes: [mkHero({
      id: "ibrahim-adil-shah-ii", emoji: "🎶",
      name: ["Ibrahim Adil Shah II", "ಇಬ್ರಾಹಿಮ್ ಆದಿಲ್ ಶಾ II"],
      title: ["The Music-Loving Sultan", "ಸಂಗೀತ ಪ್ರಿಯ ಸುಲ್ತಾನ"],
      era: "1571 – 1627",
      pages: [
        ["In the golden city of Bijapur, a young boy named Ibrahim Adil Shah II became a Sultan at a very tender age. Though he wore a heavy crown, his heart was filled with a deep love for the melodies of nature and the beauty of words. Growing up in the Deccan during the late 16th century, he was a curious child who wanted to understand everyone in his vast kingdom. He didn't just want to be a ruler who gave orders; he wanted to be a leader who brought people together through the magic of art and music, making the kingdom of Bijapur a place where every voice could be heard and celebrated.", "ವಿಜಯಪುರದ ಸುವರ್ಣ ನಗರಿಯಲ್ಲಿ, ಇಬ್ರಾಹಿಂ ಆದಿಲ್ ಶಾ II ಎಂಬ ಚಿಕ್ಕ ಬಾಲಕ ಅತಿ ಕಿರಿಯ ವಯಸ್ಸಿನಲ್ಲಿಯೇ ಸುಲ್ತಾನನಾದನು. ಅವನು ಭಾರವಾದ ಕಿರೀಟವನ್ನು ಧರಿಸಿದ್ದರೂ, ಅವನ ಹೃದಯವು ಪ್ರಕೃತಿಯ ಮಧುರತೆ ಮತ್ತು ಪದಗಳ ಸೌಂದರ್ಯದಿಂದ ತುಂಬಿತ್ತು. 16ನೇ ಶತಮಾನದ ಅಂತ್ಯದಲ್ಲಿ ದಕ್ಕನ್ ಪ್ರಾಂತ್ಯದಲ್ಲಿ ಬೆಳೆದ ಅವನು, ತನ್ನ ವಿಶಾಲ ಸಾಮ್ರಾಜ್ಯದ ಪ್ರತಿಯೊಬ್ಬರನ್ನು ಅರ್ಥಮಾಡಿಕೊಳ್ಳಲು ಬಯಸುವ ಕುತೂಹಲಕಾರಿ ಮಗುವಾಗಿದ್ದನು. ಅವನು ಕೇವಲ ಆಜ್ಞೆಗಳನ್ನು ನೀಡುವ ಆಡಳಿತಗಾರನಾಗಲು ಬಯಸಲಿಲ್ಲ; ಬದಲಾಗಿ ಕಲೆ ಮತ್ತು ಸಂಗೀತದ ಮೂಲಕ ಜನರನ್ನು ಒಂದುಗೂಡಿಸುವ ನಾಯಕನಾಗಲು ಬಯಸಿದನು.", "👑"],
        ["As Ibrahim grew, his mind became a treasure chest of knowledge. He was a true polymath who mastered many languages, including Persian, Dakhani, Marathi, and the ancient language of Sanskrit. He spent his days surrounded by scholars and poets, learning about different cultures and traditions. Because he respected all religions and deep wisdom, his people lovingly called him 'Jagadguru Badshah', which means the World Teacher Emperor. He believed that knowledge was like a river that should flow freely to everyone, and he worked hard to ensure that Hindu and Muslim artists worked side by side in his royal court.", "ಇಬ್ರಾಹಿಂ ಬೆಳೆಯುತ್ತಾ ಹೋದಂತೆ, ಅವನ ಮನಸ್ಸು ಜ್ಞಾನದ ನಿಧಿಯಾಯಿತು. ಅವನು ಪರ್ಷಿಯನ್, ದಖ್ಖನಿ, ಮರಾಠಿ ಮತ್ತು ಪ್ರಾಚೀನ ಸಂಸ್ಕೃತ ಸೇರಿದಂತೆ ಅನೇಕ ಭಾಷೆಗಳಲ್ಲಿ ಪಾಂಡಿತ್ಯವನ್ನು ಹೊಂದಿದ್ದನು. ಅವನು ವಿದ್ವಾಂಸರು ಮತ್ತು ಕವಿಗಳಿಂದ ಸುತ್ತುವರೆದು, ವಿಭಿನ್ನ ಸಂಸ್ಕೃತಿ ಮತ್ತು ಸಂಪ್ರದಾಯಗಳ ಬಗ್ಗೆ ಕಲಿಯುತ್ತಾ ಕಾಲ ಕಳೆದನು. ಅವನು ಎಲ್ಲಾ ಧರ್ಮಗಳನ್ನು ಮತ್ತು ಜ್ಞಾನವನ್ನು ಗೌರವಿಸುತ್ತಿದ್ದರಿಂದ, ಅವನ ಪ್ರಜೆಗಳು ಅವನನ್ನು ಪ್ರೀತಿಯಿಂದ 'ಜಗದ್ಗುರು ಬಾದಶಹ' ಎಂದು ಕರೆದರು. ಜ್ಞಾನವು ಎಲ್ಲರಿಗೂ ಮುಕ್ತವಾಗಿ ಹರಿಯುವ ನದಿಯಂತಿರಬೇಕು ಎಂದು ಅವರು ನಂಬಿದ್ದರು ಮತ್ತು ಹಿಂದು ಹಾಗೂ ಮುಸ್ಲಿಂ ಕಲಾವಿದರು ಒಟ್ಟಾಗಿ ಕೆಲಸ ಮಾಡುವಂತೆ ಮಾಡಿದರು.", "📚"],
        ["Ibrahim's greatest joy was music, which he believed was a bridge between souls. He picked up his pen and wrote a magnificent book called 'Kitab-i-Nauras', or the Book of Nine Rasas. This special book contained fifty-nine beautiful songs and seventeen couplets. In a wonderful display of unity, he wrote praises for the Hindu goddess of learning, Saraswati, and the respected Sufi saint Gesu Daraz. Through his music, he taught his people that while paths might be different, the essence of devotion and beauty is the same for everyone. His songs were sung across the land, spreading a message of peace and harmony.", "ಇಬ್ರಾಹಿಂನ ಅತ್ಯಂತ ದೊಡ್ಡ ಸಂತೋಷವೆಂದರೆ ಸಂಗೀತ, ಇದು ಆತ್ಮಗಳ ನಡುವಿನ ಸೇತುವೆ ಎಂದು ಅವರು ನಂಬಿದ್ದರು. ಅವರು 'ಕಿತಾಬ್-ಇ-ನೌರಸ್' ಅಥವಾ ಒಂಬತ್ತು ರಸಗಳ ಪುಸ್ತಕ ಎಂಬ ಭವ್ಯವಾದ ಕೃತಿಯನ್ನು ಬರೆದರು. ಈ ವಿಶೇಷ ಪುಸ್ತಕವು ಐವತ್ತೊಂಬತ್ತು ಸುಂದರ ಹಾಡುಗಳನ್ನು ಮತ್ತು ಹದಿನೇಳು ದ್ವಿಪದಿಗಳನ್ನು ಒಳಗೊಂಡಿತ್ತು. ಏಕತೆಯ ಅದ್ಭುತ ಪ್ರದರ್ಶನವಾಗಿ, ಅವರು ವಿದ್ಯಾದೇವತೆ ಸರಸ್ವತಿ ಮತ್ತು ಗೌರವಾನ್ವಿತ ಸೂಫಿ ಸಂತ ಗೇಸು ದರಾಜ್ ಅವರ ಸ್ತುತಿಗಳನ್ನು ಬರೆದರು. ಸಂಗೀತದ ಮೂಲಕ ಅವರು ತಮ್ಮ ಜನರಿಗೆ ಭಕ್ತಿಯ ಸಾರವು ಎಲ್ಲರಿಗೂ ಒಂದೇ ಎಂದು ಕಲಿಸಿದರು. ಅವರ ಹಾಡುಗಳು ನಾಡಿನಾದ್ಯಂತ ಶಾಂತಿ ಮತ್ತು ಸಾಮರಸ್ಯದ ಸಂದೇಶವನ್ನು ಹರಡಿದವು.", "🎵"],
        ["The Sultan was also a master builder who wanted to decorate his kingdom with stone wonders. He dreamed of magnificent structures that would touch the clouds. He built the grand Ibrahim Rauza, a stunning monument known for its delicate carvings and balance. He also constructed the Gagan Mahal, a palace with a massive arch where he could meet his subjects. His vision even started the foundation for the mighty Gol Gumbaz, which would one day have one of the largest domes in the world. Each building was a testament to his love for fine arts and his desire to make Bijapur a center of architectural beauty.", "ಸುಲ್ತಾನನು ತನ್ನ ಸಾಮ್ರಾಜ್ಯವನ್ನು ಕಲ್ಲಿನ ಅದ್ಭುತಗಳಿಂದ ಅಲಂಕರಿಸಲು ಬಯಸಿದ ಮಹಾನ್ ನಿರ್ಮಾಣಕಾರನೂ ಆಗಿದ್ದನು. ಅವನು ಮೋಡಗಳನ್ನು ಮುಟ್ಟುವಂತಹ ಭವ್ಯವಾದ ಕಟ್ಟಡಗಳ ಕನಸು ಕಂಡನು. ಅವನು ತನ್ನ ಸೊಗಸಾದ ಕೆತ್ತನೆಗಳಿಗೆ ಹೆಸರಾದ ಇಬ್ರಾಹಿಂ ರೌಜಾವನ್ನು ನಿರ್ಮಿಸಿದನು. ಅವನು ತನ್ನ ಪ್ರಜೆಗಳನ್ನು ಭೇಟಿ ಮಾಡಲು ಬೃಹತ್ ಕಮಾನು ಹೊಂದಿರುವ ಗಗನ್ ಮಹಲ್ ಅರಮನೆಯನ್ನು ನಿರ್ಮಿಸಿದನು. ಜಗತ್ತಿನ ಅತಿ ದೊಡ್ಡ ಗುಮ್ಮಟಗಳಲ್ಲಿ ಒಂದಾದ ಭವ್ಯ ಗೋಲ್ ಗುಂಬಜ್ ನಿರ್ಮಾಣಕ್ಕೆ ಅವನ ದೃಷ್ಟಿಕೋನವೇ ಅಡಿಪಾಯ ಹಾಕಿತು. ಪ್ರತಿಯೊಂದು ಕಟ್ಟಡವು ಲಲಿತಕಲೆಗಳ ಮೇಲಿನ ಅವನ ಪ್ರೀತಿ ಮತ್ತು ವಿಜಯಪುರವನ್ನು ವಾಸ್ತುಶಿಲ್ಪದ ಕೇಂದ್ರವನ್ನಾಗಿ ಮಾಡುವ ಅವನ ಬಯಕೆಗೆ ಸಾಕ್ಷಿಯಾಗಿದೆ.", "🏰"],
        ["Today, when we visit the historic district of Vijayapura in Karnataka, we can still feel the spirit of the music-loving Sultan. The echoes of his 'Kitab-i-Nauras' still resonate in the hearts of musicians, and the grand arches of his palaces still stand tall under the sun. Ibrahim Adil Shah II showed the world that a ruler can be powerful yet gentle, and that a kingdom thrives when it embraces diversity. His legacy reminds every child that by appreciating different cultures and celebrating the arts, we can build a world filled with harmony and wonder, just as he did centuries ago.", "ಇಂದು ನಾವು ಕರ್ನಾಟಕದ ವಿಜಯಪುರ ಜಿಲ್ಲೆಗೆ ಭೇಟಿ ನೀಡಿದಾಗ, ಸಂಗೀತ ಪ್ರೇಮಿ ಸುಲ್ತಾನನ ನೆನಪುಗಳನ್ನು ಇಂದಿಗೂ ಅನುಭವಿಸಬಹುದು. ಅವರ 'ಕಿತಾಬ್-ಇ-ನೌರಸ್' ಕೃತಿಯ ಪ್ರತಿಧ್ವನಿಗಳು ಇಂದಿಗೂ ಸಂಗೀತಗಾರರ ಹೃದಯದಲ್ಲಿ ಮೊಳಗುತ್ತಿವೆ. ಇಬ್ರಾಹಿಂ ಆದಿಲ್ ಶಾ II ಒಬ್ಬ ಆಡಳಿತಗಾರನು ಶಕ್ತಿಯುತ ಹಾಗೂ ಸೌಮ್ಯ ಸ್ವಭಾವದವನಾಗಿರಬಹುದು ಮತ್ತು ವೈವಿಧ್ಯತೆಯನ್ನು ಅಪ್ಪಿಕೊಂಡಾಗ ಸಾಮ್ರಾಜ್ಯವು ಸಮೃದ್ಧವಾಗುತ್ತದೆ ಎಂದು ಜಗತ್ತಿಗೆ ತೋರಿಸಿಕೊಟ್ಟರು. ವಿಭಿನ್ನ ಸಂಸ್ಕೃತಿಗಳನ್ನು ಗೌರವಿಸುವ ಮೂಲಕ ಮತ್ತು ಕಲೆಯನ್ನು ಆಚರಿಸುವ ಮೂಲಕ ನಾವು ಸಾಮರಸ್ಯದ ಜಗತ್ತನ್ನು ನಿರ್ಮಿಸಬಹುದು ಎಂದು ಅವರ ಪರಂಪರೆಯು ಪ್ರತಿ ಮಗುವಿಗೂ ನೆನಪಿಸುತ್ತದೆ.", "🌟"]
      ],
      quiz: [
        ["He loved most…", "ಪ್ರಿಯ?", ["Music", "War", "Hunting"], ["ಸಂಗೀತ", "ಯುದ್ಧ", "ಬೇಟೆ"], 0],
        ["He ruled…", "?", ["Bijapur", "Bidar", "Bengaluru"], ["ಬಿಜಾಪುರ", "ಬೀದರ್", "ಬೆಂಗಳೂರು"], 0],
      
        ['He ruled?', 'ಆಳ್ವಿಕೆ?', ['Bijapur', 'Bidar', 'Bengaluru'], ['ಬಿಜಾಪುರ', 'ಬೀದರ್', 'ಬೆಂಗಳೂರು'], 0],
        ['He loved most?', 'ಪ್ರಿಯ?', ['Music', 'War', 'Hunting'], ['ಸಂಗೀತ', 'ಯುದ್ಧ', 'ಬೇಟೆ'], 0],
        ['His famous book?', 'ಗ್ರಂಥ?', ['Kitab-i-Nauras', 'Vachana', 'Quran'], ['ಕಿತಾಬ್-ಇ-ನವರಸ್', 'ವಚನ', 'ಖುರಾನ್'], 0],
        ['He was nicknamed?', 'ಬಿರುದು?', ['Jagad Guru', 'Tiger', 'Lion'], ['ಜಗದ್ಗುರು', 'ಹುಲಿ', 'ಸಿಂಹ'], 0],
        ['Dynasty?', 'ವಂಶ?', ['Adil Shahi', 'Mughal', 'Tuluva'], ['ಆದಿಲ್ ಶಾಹಿ', 'ಮೊಘಲ್', 'ತುಳುವ'], 0],
        ['He respected which religions?', 'ಗೌರವ?', ['All', 'Only one', 'None'], ['ಎಲ್ಲ', 'ಒಂದೇ', 'ಯಾವುದೂ ಇಲ್ಲ'], 0],
        ['Famous monument near him?', 'ಸ್ಮಾರಕ?', ['Gol Gumbaz', 'Hampi', 'Belur'], ['ಗೋಲ್ ಗುಂಬಜ್', 'ಹಂಪಿ', 'ಬೇಲೂರು'], 0],
        ['Capital city?', 'ರಾಜಧಾನಿ?', ['Bijapur', 'Bidar', 'Hampi'], ['ಬಿಜಾಪುರ', 'ಬೀದರ್', 'ಹಂಪಿ'], 0],
      ],
      memorial: ["Gol Gumbaz", "ಗೋಲ್ ಗುಂಬಜ್", "Vijayapura", "ವಿಜಯಪುರ", "World-famous domed mausoleum.", "ವಿಶ್ವಪ್ರಸಿದ್ಧ ಗುಂಬಜ್.", "Gol Gumbaz Vijayapura"],
    })],
  },
  {
    id: "yadgir", name: { en: "Yadgir", kn: "ಯಾದಗಿರಿ" }, emoji: "🏞️",
    heroes: [mkHero({
      id: "shorapur-venkatappa-nayaka", emoji: "🐎",
      name: ["Raja Venkatappa Nayaka", "ರಾಜ ವೆಂಕಟಪ್ಪ ನಾಯಕ"],
      title: ["The Boy King of Shorapur", "ಶೋರಾಪುರದ ಬಾಲ ರಾಜ"],
      era: "1834 – 1858",
      pages: [
        ["Deep in the heart of what we now call Yadgir district, there once lived a spirited young boy named Venkatappa Nayaka. Born into the brave Bedar community, he became the Raja of the Shorapur principality when he was still very little. Because he was so young, he was known as the 'Boy King.' Venkatappa grew up in a magnificent palace surrounded by loyal warriors and the golden fields of Northern Karnataka. Though the kingdom was small, its history was mighty, and the young king learned that he had a responsibility to protect his people and their ancient traditions from any harm that might come their way.", "ಈಗಿನ ಯಾದಗಿರಿ ಜಿಲ್ಲೆಯ ಹೃದಯಭಾಗದಲ್ಲಿ, ವೆಂಕಟಪ್ಪ ನಾಯಕ ಎಂಬ ಉತ್ಸಾಹಿ ಬಾಲಕನಿದ್ದನು. ಪರಾಕ್ರಮಿ ಬೇಡರ ಸಮುದಾಯದಲ್ಲಿ ಜನಿಸಿದ ಇವನು, ಚಿಕ್ಕ ವಯಸ್ಸಿನಲ್ಲೇ ಸುರಪುರ ಸಂಸ್ಥಾನದ ರಾಜನಾದನು. ಅವನು ತುಂಬಾ ಚಿಕ್ಕವನಾಗಿದ್ದರಿಂದ ಅವನನ್ನು 'ಬಾಲ ರಾಜ' ಎಂದು ಕರೆಯಲಾಗುತ್ತಿತ್ತು. ವೆಂಕಟಪ್ಪ ಉತ್ತರ ಕರ್ನಾಟಕದ ಭವ್ಯ ಅರಮನೆ ಮತ್ತು ಬಂಗಾರದಂತಹ ಹೊಲಗದ್ದೆಗಳ ನಡುವೆ, ನಿಷ್ಠಾವಂತ ಯೋಧರ ಮಧ್ಯೆ ಬೆಳೆದನು. ಅವನ ರಾಜ್ಯವು ಚಿಕ್ಕದಾಗಿದ್ದರೂ, ಅದರ ಇತಿಹಾಸವು ಬಹಳ ಶಕ್ತಿಯುತವಾಗಿತ್ತು. ತನ್ನ ಜನರನ್ನು ಮತ್ತು ಪ್ರಾಚೀನ ಸಂಪ್ರದಾಯಗಳನ್ನು ಬರುವಂತಹ ಯಾವುದೇ ಆಪತ್ತಿನಿಂದ ರಕ್ಷಿಸುವುದು ತನ್ನ ಜವಾಬ್ದಾರಿಯೆಂದು ಈ ಯುವ ರಾಜನು ಅರಿತಿದ್ದನು.", "🏰"],
        ["As he grew, a British officer named Philip Meadows Taylor became his tutor and guardian. Taylor was very fond of the bright young prince and taught him many things about the world. They spent much time together, and Taylor even wrote about the boy affectionately in his famous book. The British thought that by teaching him, Venkatappa would grow up to be a quiet ruler who followed their every command. However, as the prince learned more about the world, he realized that he wanted his land to be truly free, and he didn't want to be a puppet moved by British strings.", "ಅವನು ಬೆಳೆಯುತ್ತಿದ್ದಂತೆ, ಫಿಲಿಪ್ ಮೆಡೋಸ್ ಟೇಲರ್ ಎಂಬ ಬ್ರಿಟಿಷ್ ಅಧಿಕಾರಿ ಅವನಿಗೆ ಶಿಕ್ಷಕ ಮತ್ತು ರಕ್ಷಕನಾದನು. ಟೇಲರ್ ಈ ಬುದ್ಧಿವಂತ ಯುವ ರಾಜನನ್ನು ತುಂಬಾ ಇಷ್ಟಪಡುತ್ತಿದ್ದನು ಮತ್ತು ಅವನಿಗೆ ಜಗತ್ತಿನ ಬಗ್ಗೆ ಅನೇಕ ವಿಷಯಗಳನ್ನು ಕಲಿಸಿದನು. ಅವರಿಬ್ಬರೂ ಒಟ್ಟಿಗೆ ಬಹಳ ಸಮಯ ಕಳೆಯುತ್ತಿದ್ದರು ಮತ್ತು ಟೇಲರ್ ತನ್ನ ಪ್ರಸಿದ್ಧ ಪುಸ್ತಕದಲ್ಲಿ ಬಾಲಕನ ಬಗ್ಗೆ ಪ್ರೀತಿಯಿಂದ ಬರೆದಿದ್ದಾನೆ. ವೆಂಕಟಪ್ಪನನ್ನು ತನ್ನ ಅಧೀನದಲ್ಲಿರಿಸಿಕೊಂಡರೆ, ಅವನು ಬ್ರಿಟಿಷರ ಪ್ರತಿ ಆಜ್ಞೆಯನ್ನು ಪಾಲಿಸುವ ಶಾಂತ ಅರಸನಾಗುತ್ತಾನೆ ಎಂದು ಬ್ರಿಟಿಷರು ಭಾವಿಸಿದ್ದರು. ಆದರೆ, ರಾಜನು ಜಗತ್ತಿನ ಬಗ್ಗೆ ಹೆಚ್ಚು ತಿಳಿಯುತ್ತಿದ್ದಂತೆ, ತನ್ನ ನಾಡು ಸಂಪೂರ್ಣವಾಗಿ ಸ್ವತಂತ್ರವಾಗಿರಬೇಕು ಎಂದು ಬಯಸಿದನು.", "📚"],
        ["When Venkatappa Nayaka became an adult, a great spark of rebellion began to spread across India in 1857. While many kings chose to stay silent, the brave Raja of Shorapur decided it was time to stand tall. He refused to listen to the British commands that he once followed as a child. Instead, he gathered his brave Bedar warriors and joined the Great Revolt. He began to organize his forces and prepared for a tough fight. He wanted to show everyone that the people of Karnataka were proud and would never accept being controlled by outsiders who took away their freedom.", "ವೆಂಕಟಪ್ಪ ನಾಯಕ ವಯಸ್ಕನಾದಾಗ, 1857ರಲ್ಲಿ ಭಾರತದಾದ್ಯಂತ ದಂಗೆಯ ಕಿಚ್ಚು ಹರಡಿತು. ಅನೇಕ ರಾಜರು ಸುಮ್ಮನಿರಲು ನಿರ್ಧರಿಸಿದಾಗ, ಧೈರ್ಯಶಾಲಿ ಸುರಪುರದ ರಾಜನು ಎದ್ದು ನಿಲ್ಲುವ ಸಮಯ ಬಂದಿದೆ ಎಂದು ನಿರ್ಧರಿಸಿದನು. ಬಾಲ್ಯದಲ್ಲಿ ತಾನು ಪಾಲಿಸುತ್ತಿದ್ದ ಬ್ರಿಟಿಷರ ಆಜ್ಞೆಗಳನ್ನು ಕೇಳಲು ಅವನು ನಿರಾಕರಿಸಿದನು. ಬದಲಾಗಿ, ಅವನು ತನ್ನ ಪರಾಕ್ರಮಿ ಬೇಡರ ಯೋಧರನ್ನು ಒಟ್ಟುಗೂಡಿಸಿ ಮಹಾ ದಂಗೆಯಲ್ಲಿ ಸೇರಿದನು. ಅವನು ತನ್ನ ಸೈನ್ಯವನ್ನು ಸಂಘಟಿಸಲು ಮತ್ತು ಕಠಿಣ ಹೋರಾಟಕ್ಕೆ ಸಿದ್ಧತೆ ನಡೆಸಲು ಪ್ರಾರಂಭಿಸಿದನು. ಕರ್ನಾಟಕದ ಜನರು ಸ್ವಾಭಿಮಾನಿಗಳು ಮತ್ತು ತಮ್ಮ ಸ್ವಾತಂತ್ರ್ಯವನ್ನು ಕಸಿದುಕೊಳ್ಳುವ ವಿದೇಶಿಯರ ನಿಯಂತ್ರಣವನ್ನು ಎಂದಿಗೂ ಒಪ್ಪುವುದಿಲ್ಲ ಎಂದು ಅವನು ತೋರಿಸಿಕೊಟ್ಟನು.", "⚔️"],
        ["The struggle was long and difficult. Venkatappa and his loyal soldiers bravely attacked the British forces, fighting with all their might to defend their home. The British, with their large armies, were very powerful, but the Raja did not give up easily. Eventually, after a fierce battle, the young king was defeated and captured by the enemy. He was sentenced to be sent away into exile, far from his beloved hills of Shorapur. It was a very sad moment for his people, who watched their young leader being taken away after he had risked everything to fight for their liberty.", "ಹೋರಾಟವು ದೀರ್ಘ ಮತ್ತು ಕಠಿಣವಾಗಿತ್ತು. ವೆಂಕಟಪ್ಪ ಮತ್ತು ಅವನ ನಿಷ್ಠಾವಂತ ಸೈನಿಕರು ಬ್ರಿಟಿಷ್ ಪಡೆಗಳ ಮೇಲೆ ಧೈರ್ಯದಿಂದ ದಾಳಿ ಮಾಡಿದರು, ತಮ್ಮ ನಾಡನ್ನು ರಕ್ಷಿಸಲು ತಮ್ಮ ಪೂರ್ಣ ಶಕ್ತಿಯಿಂದ ಹೋರಾಡಿದರು. ದೊಡ್ಡ ಸೈನ್ಯವನ್ನು ಹೊಂದಿದ್ದ ಬ್ರಿಟಿಷರು ಬಹಳ ಬಲಶಾಲಿಯಾಗಿದ್ದರು, ಆದರೆ ರಾಜನು ಸುಲಭವಾಗಿ ಸೋಲೊಪ್ಪಲಿಲ್ಲ. ಅಂತಿಮವಾಗಿ, ಭೀಕರ ಯುದ್ಧದ ನಂತರ, ಯುವ ರಾಜನನ್ನು ಶತ್ರುಗಳು ಸೋಲಿಸಿ ಸೆರೆಹಿಡಿದರು. ಅವನಿಗೆ ದೇಶಭ್ರಷ್ಟತೆಯ ಶಿಕ್ಷೆ ವಿಧಿಸಲಾಯಿತು ಮತ್ತು ಅವನ ಪ್ರೀತಿಯ ಸುರಪುರದ ಬೆಟ್ಟಗಳಿಂದ ದೂರ ಕಳುಹಿಸಲಾಯಿತು. ತಮ್ಮ ಸ್ವಾತಂತ್ರ್ಯಕ್ಕಾಗಿ ಎಲ್ಲವನ್ನೂ ಪಣಕ್ಕಿಟ್ಟು ಹೋರಾಡಿದ ತಮ್ಮ ಯುವ ನಾಯಕನನ್ನು ಕರೆದೊಯ್ಯುವುದನ್ನು ನೋಡಿದ ಅವನ ಜನರಿಗೆ ಅದು ಬಹಳ ದುಃಖದ ಕ್ಷಣವಾಗಿತ್ತು.", "🛡️"],
        ["In February 1858, while he was being moved to his place of exile, the brave king passed away at the young age of twenty-three. Many believe he chose to end his own life rather than live as a prisoner of the British. Though he died very young, Raja Venkatappa Nayaka IV became one of Karnataka's earliest and greatest martyrs of the 1857 Revolt. Today, we remember him as a hero who chose courage over comfort. His story teaches us that true bravery is standing up for what is right, no matter how young you are or how powerful your opponent might seem.", "ಫೆಬ್ರವರಿ 1858 ರಲ್ಲಿ, ಅವನನ್ನು ಗಡಿಪಾರು ಮಾಡುವ ಸ್ಥಳಕ್ಕೆ ಕರೆದೊಯ್ಯುತ್ತಿದ್ದಾಗ, ಈ ಶೂರ ರಾಜನು ಕೇವಲ ಇಪ್ಪತ್ಮೂರು ವರ್ಷ ವಯಸ್ಸಿನಲ್ಲಿ ನಿಧನನಾದನು. ಬ್ರಿಟಿಷರ ಕೈದಿಯಾಗಿ ಬದುಕುವ ಬದಲು ಅವನು ತನ್ನ ಜೀವನವನ್ನು ತಾನೇ ಅಂತ್ಯಗೊಳಿಸಲು ನಿರ್ಧರಿಸಿದನು ಎಂದು ಅನೇಕರು ನಂಬುತ್ತಾರೆ. ಅವನು ಅಲ್ಪಾಯುವಾಗಿದ್ದರೂ, ರಾಜ ನಾಲ್ಕನೇ ವೆಂಕಟಪ್ಪ ನಾಯಕ ಕರ್ನಾಟಕದ 1857ರ ದಂಗೆಯ ಅತ್ಯಂತ ಮೊದಲ ಮತ್ತು ಶ್ರೇಷ್ಠ ಹುತಾತ್ಮರಲ್ಲಿ ಒಬ್ಬನಾದನು. ಇಂದು, ನಾವು ಅವನನ್ನು ಸೌಕರ್ಯಕ್ಕಿಂತ ಧೈರ್ಯವನ್ನು ಆರಿಸಿಕೊಂಡ ವೀರನನ್ನಾಗಿ ನೆನಪಿಸಿಕೊಳ್ಳುತ್ತೇವೆ. ನಾವು ಎಷ್ಟೇ ಚಿಕ್ಕವರಿದ್ದರೂ ಅಥವಾ ಶತ್ರು ಎಷ್ಟೇ ಬಲಶಾಲಿಯಾಗಿದ್ದರೂ, ಸರಿಯಾದದ್ದಕ್ಕಾಗಿ ಧ್ವನಿ ಎತ್ತುವುದೇ ನಿಜವಾದ ಶೌರ್ಯ ಎಂದು ಅವನ ಕಥೆ ನಮಗೆ ಕಲಿಸುತ್ತದೆ.", "🌟"]
      ],
      quiz: [
        ["He ruled…", "?", ["Shorapur", "Mysuru", "Hampi"], ["ಶೋರಾಪುರ", "ಮೈಸೂರು", "ಹಂಪಿ"], 0],
        ["He fought against…", "ಯಾರ ವಿರುದ್ಧ?", ["British", "Mughals", "Marathas"], ["ಬ್ರಿಟಿಷರು", "ಮೊಘಲರು", "ಮರಾಠರು"], 0],
      
        ['He ruled?', 'ಆಳ್ವಿಕೆ?', ['Shorapur', 'Mysuru', 'Hampi'], ['ಶೋರಾಪುರ', 'ಮೈಸೂರು', 'ಹಂಪಿ'], 0],
        ['Fought against?', 'ವಿರುದ್ಧ?', ['British', 'Mughals', 'Marathas'], ['ಬ್ರಿಟಿಷರು', 'ಮೊಘಲರು', 'ಮರಾಠರು'], 0],
        ['Fort on a?', 'ಕೋಟೆ?', ['Hilltop', 'Beach', 'River'], ['ಬೆಟ್ಟ', 'ಕಡಲತೀರ', 'ನದಿ'], 0],
        ['District?', 'ಜಿಲ್ಲೆ?', ['Yadgir', 'Mysuru', 'Bidar'], ['ಯಾದಗಿರಿ', 'ಮೈಸೂರು', 'ಬೀದರ್'], 0],
        ['Mentor was?', 'ಗುರು?', ['Meadows Taylor', 'Tipu', 'Hyder'], ['ಮೆಡೋಸ್ ಟೇಲರ್', 'ಟಿಪ್ಪು', 'ಹೈದರ್'], 0],
        ['He revolted in 1857 era?', '೧೮೫೭?', ['Yes', 'No', 'Unknown'], ['ಹೌದು', 'ಇಲ್ಲ', 'ತಿಳಿದಿಲ್ಲ'], 0],
        ['Died bravely as a…', 'ಮರಣ?', ['Martyr', 'Trader', 'Saint'], ['ಹುತಾತ್ಮ', 'ವ್ಯಾಪಾರಿ', 'ಸಂತ'], 0],
        ['Region?', 'ಪ್ರದೇಶ?', ['Kalyana Karnataka', 'Coast', 'Malnad'], ['ಕಲ್ಯಾಣ ಕರ್ನಾಟಕ', 'ಕರಾವಳಿ', 'ಮಲೆನಾಡು'], 0],
      ],
      memorial: ["Shorapur Fort", "ಶೋರಾಪುರ ಕೋಟೆ", "Shorapur, Yadgir", "ಶೋರಾಪುರ", "Hilltop fort that witnessed his brave revolt.", "ಬೆಟ್ಟದ ಕೋಟೆ.", "Shorapur Fort Yadgir"],
    })],
  },
];

export const ALL_HEROES: Hero[] = DISTRICTS.flatMap((d) => d.heroes);

export function findHero(id: string): { hero: Hero; district: District } | null {
  for (const d of DISTRICTS) {
    const h = d.heroes.find((x) => x.id === id);
    if (h) return { hero: h, district: d };
  }
  return null;
}
